/**
 * background.js — Service Worker (Manifest V3)
 * 고가수집기 백그라운드 서비스
 */

const DEFAULT_SERVER_URL = "https://kohganepercentiii.com";

async function getSettings() {
  let syncData = {};
  let localData = {};
  try {
    syncData = await chrome.storage.sync.get(["serverUrl", "token"]);
  } catch (_) {}
  try {
    localData = await chrome.storage.local.get(["serverUrl", "token", "kgp_enrich_mode", "kgp_translate"]);
  } catch (_) {}
  return {
    serverUrl: syncData.serverUrl || localData.serverUrl || DEFAULT_SERVER_URL,
    token: syncData.token || localData.token || "",
    enrichMode: localData.kgp_enrich_mode || "background",   // R1: 백그라운드 탭 기본(포커스 변경 0 실측) · minimized=최소화 창
    // v83.1 STEP1: 한국어 번역 토글(기본 ON). 팝업·수집 카드가 같은 키를 읽고 쓴다(단일 소스).
    translate: !(localData.kgp_translate === false),
  };
}

// v83.1 STEP1: 번역 플래그를 전송 페이로드에 주입하는 **단일 관문**. FAB·팝업·벌크·호버·컨텍스트메뉴가
//   전부 handleCollect/handleCollectBulk를 지나므로 여기 한 곳만 지키면 경로 drift가 없다.
//   OFF일 때만 translate:false를 싣는다(서버 기본값이 true라 ON은 무전송 = 기존 페이로드 그대로).
//   ※ 원문(title·description)은 어느 쪽이든 그대로 전송된다 — 토글은 **번역 파이프라인 실행 여부**만 제어하고,
//     번역본(title_ko 등)은 파생 필드다. 구글 번역 DOM 오염(translated_dom) 판정과는 무관(v83 STEP1 유지).
function _kgpWithTranslateFlag(meta, translate) {
  if (translate !== false) return meta;
  if (!meta || typeof meta !== "object") return meta;
  return Object.assign({}, meta, { translate: false });
}

// 컨텍스트 메뉴 생성
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "kohgane-collect",
    title: "고가브릿지에 보내기",
    contexts: ["page"]
  });
});

// 컨텍스트 메뉴 클릭
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "kohgane-collect" && tab) {
    collectFromTab(tab);
  }
});

// 팝업에서 수집 요청
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "collect") {
    handleCollect(msg.meta, sendResponse);
    return true; // 비동기 응답
  }
  if (msg.action === "collectBulk") {
    handleCollectBulk(msg.items, sendResponse, sender && sender.tab && sender.tab.id);
    return true; // 비동기 응답
  }
  if (msg.action === "kgpCheckUpdate") {   // F50: 팝업이 열릴 때 — 최신 버전·규칙을 다시 본다
    kgpRefreshRemote("popup").then((st) => sendResponse(st));
    return true;
  }
  if (msg.action === "kgpBuildInfo") {   // v83.1 STEP2: 패키징 시 각인된 커밋 해시(진단 파일용)
    _kgpBuildInfo().then((info) => sendResponse(info));
    return true;
  }
  if (msg.action === "getSettings") {
    getSettings().then((data) => sendResponse(data));
    return true;
  }
  if (msg.action === "collectExists") {   // v42 E-3: 이미 수집된 URL 조회(호버 버튼 '수집됨 ✓' 선표시)
    handleExists(msg.urls, sendResponse);
    return true;
  }
  // v64 STEP1: 벌크 상세 보강 큐 제어.
  if (msg.action === "enrichStart") { handleEnrichStart(msg.targets, sendResponse); return true; }
  if (msg.action === "enrichState") { sendResponse(_kgpEnrichSnapshot()); return false; }
  if (msg.action === "enrichPause") { KgpEnrich.paused = !!msg.paused; _kgpBroadcastEnrich(); sendResponse(_kgpEnrichSnapshot()); return false; }
  if (msg.action === "enrichStop") { KgpEnrich.stopped = true; KgpEnrich.queue = []; _kgpBroadcastEnrich(); sendResponse(_kgpEnrichSnapshot()); return false; }
});

// ── F50 — 확장 갱신: 최신 버전 배너 · 사이트 규칙(데이터) ─────────────────────────────
//   ① 서버 /api/v1/collect/extension/latest의 버전이 설치 버전보다 **높으면** 툴바 배지 「NEW」 +
//      kgp_update에 기록(팝업이 배너로 보여 준다). 같거나 낮으면 배지를 지운다(가짜 알림 금지).
//   ② /api/v1/collect/rules를 받아 **해시를 다시 재서 맞을 때만** kgp_rules에 둔다(깨진 응답을 안 쓴다).
//      못 받으면 이전 캐시 그대로 — 캐시도 없으면 content script가 번들(kgp-rules.js)을 쓴다.
//   규칙은 데이터다(셀렉터 문자열·숫자) — 받은 것을 실행하지 않는다(MV3 원격 코드 금지 준수).
function kgpCmpVer(a, b) {
  const pa = String(a || "").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "").split(".").map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d > 0 ? 1 : -1;
  }
  return 0;
}
function kgpCanonical(v) {
  if (Array.isArray(v)) return "[" + v.map(kgpCanonical).join(",") + "]";
  if (v && typeof v === "object") {
    return "{" + Object.keys(v).sort().map((k) => JSON.stringify(k) + ":" + kgpCanonical(v[k])).join(",") + "}";
  }
  return JSON.stringify(v);
}
async function kgpSha256Hex(text) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
// F49-T 5부-c: 저장 쓰기 실패를 **삼키지 않는다** — 바깥 catch(「네트워크 실패」)로 흘러가면 원인이 바뀐다.
//   전부 storage.local이다(sync는 옵션 화면의 서버 주소·토큰뿐 — 계약이 지킨다). 실패는 횟수·마지막 사유를 남긴다.
const KgpStorageErr = { count: 0, last: null };
async function kgpLocalSet(obj) {
  try {
    await chrome.storage.local.set(obj);
    return true;
  } catch (e) {
    KgpStorageErr.count += 1;
    KgpStorageErr.last = { keys: Object.keys(obj || {}).join(",").slice(0, 80),
                           msg: String((e && e.message) || e).slice(0, 160), at: new Date().toISOString() };
    try { console.warn("[고가수집기] 저장 실패:", KgpStorageErr.last.keys, KgpStorageErr.last.msg); } catch (e2) {}
    return false;
  }
}

async function kgpRefreshRemote(why) {
  const settings = await getSettings();
  const base = settings.serverUrl;
  let current = "";
  try { current = chrome.runtime.getManifest().version || ""; } catch (e) {}
  const st = { current, latest: "", newer: false, rules: "", why: why || "" };
  try {
    const r = await fetch(`${base}/api/v1/collect/extension/latest`, { cache: "no-store" });
    const d = await r.json().catch(() => ({}));
    if (r.ok && d && d.ok && d.version) {
      st.latest = String(d.version);
      st.newer = kgpCmpVer(st.latest, current) > 0;
      const upd = { current, latest: st.latest, newer: st.newer, checked_at: new Date().toISOString(),
                    download_page: base + (d.download_page || "/seller/extension"),
                    zip_name: d.zip_name || "" };
      await kgpLocalSet({ kgp_update: upd });
      try {
        await chrome.action.setBadgeText({ text: st.newer ? "NEW" : "" });
        if (st.newer) {
          await chrome.action.setBadgeBackgroundColor({ color: "#f5821f" });
          await chrome.action.setTitle({ title: `고가수집기 — 새 버전 ${st.latest}이 있어요(설치된 버전 ${current})` });
        } else {
          await chrome.action.setTitle({ title: "고가수집기" });
        }
      } catch (e) { /* action API 없는 환경 */ }
    }
  } catch (e) { /* 네트워크 실패 — 이전 기록 그대로(없는 새 버전을 말하지 않는다) */ }
  try {
    const r = await fetch(`${base}/api/v1/collect/rules`, { cache: "no-store" });
    const d = await r.json().catch(() => ({}));
    if (r.ok && d && d.ok && d.rules && typeof d.rules === "object" && d.version && d.hash) {
      const h = await kgpSha256Hex(kgpCanonical(d.rules));
      if (h === d.hash) {
        await kgpLocalSet({ kgp_rules: { version: String(d.version), hash: d.hash, rules: d.rules,
                                         fetched_at: new Date().toISOString() } });
        st.rules = String(d.version);
      } else {
        st.rules = "hash-mismatch";
        console.warn("[고가수집기] 규칙 해시 불일치 — 받은 규칙을 쓰지 않음", d.hash, h);
      }
    }
  } catch (e) { /* 번들·이전 캐시로 동작 */ }
  return st;
}
try {
  chrome.runtime.onStartup && chrome.runtime.onStartup.addListener(() => kgpRefreshRemote("startup"));
  chrome.runtime.onInstalled && chrome.runtime.onInstalled.addListener(() => kgpRefreshRemote("installed"));
  if (chrome.alarms && chrome.alarms.create) {
    chrome.alarms.create("kgp-remote-refresh", { periodInMinutes: 360 });
    chrome.alarms.onAlarm.addListener((a) => { if (a && a.name === "kgp-remote-refresh") kgpRefreshRemote("alarm"); });
  }
} catch (e) { /* noop */ }

// v83.1 STEP2: ZIP 패키징 시 심어진 build-info.json(commit·built_at·branch)을 읽는다.
//   소스 폴더를 그대로 로드한 개발 설치엔 파일이 없다 → {commit:"", source:"unpacked-dev"}로 **정직 표기**
//   (가짜 해시 금지). 채팅 채점이 "브랜치 빌드인지"를 버전 문자열이 아니라 커밋으로 즉판한다.
let _kgpBuildInfoCache = null;
async function _kgpBuildInfo() {
  if (_kgpBuildInfoCache) return _kgpBuildInfoCache;
  let version = "";
  try { version = chrome.runtime.getManifest().version || ""; } catch (e) {}
  let info = { version: version, commit: "", commit_short: "", branch: "", source: "unpacked-dev", built_at: "" };
  try {
    const r = await fetch(chrome.runtime.getURL("build-info.json"));
    if (r && r.ok) {
      const d = await r.json();
      if (d && typeof d === "object") info = Object.assign(info, d);
    }
  } catch (e) { /* 파일 없음 = 개발 설치(정직) */ }
  _kgpBuildInfoCache = info;
  return info;
}

async function handleExists(urls, sendResponse) {
  const settings = await getSettings();
  if (!settings.token) { if (sendResponse) sendResponse({ ok: false, collected: [] }); return; }
  try {
    const r = await fetch(`${settings.serverUrl}/api/v1/collect/exists`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${settings.token}` },
      body: JSON.stringify({ urls: Array.isArray(urls) ? urls : [] }),
    });
    const d = await r.json().catch(() => ({}));
    if (sendResponse) sendResponse({ ok: !!(d && d.ok), collected: (d && d.collected) || [] });
  } catch (e) {
    if (sendResponse) sendResponse({ ok: false, collected: [] });
  }
}

// ── v64 STEP1: 벌크 2단 수집 — 상세 보강 큐 ──────────────────────────────────
//   1단(목록 데이터)은 이미 저장됨. 2단: 확장이 백그라운드 탭으로 각 상품 상세를 순차 방문해
//   옵션·상세·리뷰·갤러리를 읽어 서버 /enrich로 기존 항목에 병합(fill-only). 사용자 브라우저
//   컨텍스트라 차단 리스크 최소. 동시 1탭·항목당 3~6초 랜덤 간격·실패 1회 재시도·일시정지/중단.
const KgpEnrich = {
  queue: [], done: 0, total: 0, failed: 0, ok: 0, blocked: 0,
  paused: false, stopped: false, running: false, current: "",
  queued: new Set(),                        // 같은 항목을 두 번 큐에 넣지 않게(폴링이 반복되므로)
  failures: [],                             // F49-T 5부: 실패 항목과 사유(툴바 「다시」 버튼이 쓴다)
};
function _kgpEnrichSnapshot() {
  return { queued: KgpEnrich.queue.length, done: KgpEnrich.done, total: KgpEnrich.total, failed: KgpEnrich.failed,
    ok: KgpEnrich.ok, blocked: KgpEnrich.blocked, paused: KgpEnrich.paused,
    stopped: KgpEnrich.stopped, running: KgpEnrich.running, current: KgpEnrich.current,
    failures: KgpEnrich.failures.slice(-30) };
}
// 항목당 대기(3~8초 랜덤 · 오너 지정). rng 주입 가능(테스트).
//   봇 판정 회피는 **상식 범위**다 — 사람이 상세를 넘겨보는 속도. 그 이상의 우회는 하지 않는다.
const KGP_ENRICH_MAX_RETRIES = 3;          // 서버 상한(ENRICH_MAX_ATTEMPTS)과 같은 수
// F49-T 5부(오너 2026-09-27): 간격 **2~3초**(동시 1탭). 예전 3~8초는 30장 전체 수집이 10분을 넘겨 MV3 워커가
//   중간에 내려가며 큐가 사라지는 일이 잦았다(남은 항목은 서버 대기열 폴링이 다시 집는다 — 아래 폴러).
function _kgpEnrichDelayMs(rng) {
  const r = (typeof rng === "function") ? rng() : Math.random();
  return 2000 + Math.floor(r * 1000);
}
function _kgpSleep(ms) { return new Promise((res) => setTimeout(res, ms)); }
function _kgpWaitTabComplete(tabId, timeoutMs) {
  return new Promise((resolve) => {
    let done = false;
    const to = setTimeout(() => { if (!done) { done = true; try { chrome.tabs.onUpdated.removeListener(li); } catch (e) {} resolve(false); } }, timeoutMs || 20000);
    function li(id, info) {
      if (id === tabId && info.status === "complete" && !done) {
        done = true; clearTimeout(to);
        try { chrome.tabs.onUpdated.removeListener(li); } catch (e) {}
        resolve(true);
      }
    }
    chrome.tabs.onUpdated.addListener(li);
  });
}
function _kgpSendTab(tabId, msg) {
  return new Promise((resolve) => {
    try {
      chrome.tabs.sendMessage(tabId, msg, (resp) => {
        if (chrome.runtime && chrome.runtime.lastError) return resolve(null);
        resolve(resp || null);
      });
    } catch (e) { resolve(null); }
  });
}
function _kgpBroadcastEnrich() {
  const snap = _kgpEnrichSnapshot();
  try { chrome.runtime.sendMessage({ action: "enrichProgress", state: snap }); } catch (e) {}
}
// v67 STEP2: 테무 렌더 성공 기준(백그라운드 탭 스로틀로 lazy 미출현 방지) — 가격 실가 + 갤러리 자기 상품 ≥3장.
function _kgpEnrichVerdict(item, meta) {
  const gallery = (meta && (meta.gallery_images || meta.images)) || [];
  const galN = Array.isArray(gallery) ? gallery.length : 0;
  const priceOk = !!(meta && meta.price && String(meta.price).trim());
  const isTemu = /(^|\.)temu\.com/i.test(item.url || "");
  if (meta && meta.interstitial) return { ok: false, reason: "테무 로그인/게이트로 보강 불가(인터스티셜)" };
  if (isTemu && (!priceOk || galN < 3)) {
    return { ok: false, reason: "테무 렌더 미완 — " + (!priceOk ? "가격 노드 미출현 " : "") + (galN < 3 ? "갤러리 " + galN + "장(3장 미만)" : "") };
  }
  return { ok: true, reason: "" };
}
// R1(오너 2026-10-01 「컴터에 자꾸 고가브릿지 수집 창이 계속 뜬다」) — 실측: 기본 모드가 `window`라 보강 1건마다
//   480×640 popup 창이 화면에 떴다(focused:false여도 **보인다**). 트리거는 5분 알람 + 콘솔 탭 로드마다 폴링,
//   대기 21건(운영 실측 — 시도 0회로 굳음)이 2~3초 간격으로 차례로 창을 띄웠다.
//   이제: 기본 = **백그라운드 탭**(active:false). 실브라우저 하네스 실측(확장 로드 · 작업 탭 연 채 보강 2건):
//     백그라운드 탭 = 창 포커스 변경 0 · 탭 활성 변경 0 / 최소화 창(state:"minimized", focused:false) = 만들 때마다
//     작업 창 포커스가 빠졌다 돌아옴(2건 6창에 12회). 그래서 최소화 창은 **고르는 사람만**(팝업에 그 사실 표기).
//   추출이 끝나면 **즉시 닫는다**(서버 저장 전). 동시 1탭(KgpEnrich.running).
//   옛 설정값 `window`·`tab-activate`(화면에 뜨거나 포커스를 뺏는 방식)는 백그라운드 탭으로 읽는다.
function _kgpEnrichModeOf(settings) {
  const m = (settings && settings.enrichMode) || "background";
  return m === "minimized" ? "minimized" : "background";
}
async function _kgpOpenHidden(url, mode) {
  if (mode === "minimized") {
    let win = null;
    try {
      if (!(chrome.windows && chrome.windows.create)) throw new Error("chrome.windows 미가용");
      win = await chrome.windows.create({ url: url, state: "minimized", focused: false });
      let tabId = win && win.tabs && win.tabs[0] && win.tabs[0].id;
      if (win && win.id != null && tabId == null) {
        try { const ts = await chrome.tabs.query({ windowId: win.id }); tabId = ts && ts[0] && ts[0].id; } catch (e) {}
      }
      if (tabId == null) throw new Error("최소화 창 탭 없음");
      return { winId: win.id, tabId: tabId };
    } catch (e) {
      try { console.warn("[고가수집기 보강] 최소화 창 실패 → 백그라운드 탭:", e && e.message); } catch (e2) {}
      if (win && win.id != null) { try { await chrome.windows.remove(win.id); } catch (e3) {} }
    }
  }
  const tab = await chrome.tabs.create({ url: url, active: false });
  return { winId: null, tabId: tab && tab.id };
}
async function _kgpCloseHidden(h) {
  if (!h) return;
  if (h.winId != null) { try { await chrome.windows.remove(h.winId); } catch (e) {} }
  else if (h.tabId != null) { try { await chrome.tabs.remove(h.tabId); } catch (e) {} }
}
async function _kgpEnrichOne(item, settings) {
  const mode = _kgpEnrichModeOf(settings);
  let h = null, meta = null;
  try {
    h = await _kgpOpenHidden(item.url, mode);
    KgpEnrich.current = item.url;
    _kgpBroadcastEnrich();
    if (h.tabId != null) await _kgpWaitTabComplete(h.tabId, 22000);
    // 렌더 완료 대기 후 추출(자동스크롤·인터스티셜·12초 — content_script extractMetaWait).
    meta = (h.tabId != null) ? await _kgpSendTab(h.tabId, { action: "extractMetaWait" }) : null;
  } finally {
    await _kgpCloseHidden(h);          // R1: 읽었으면 바로 닫는다(서버 저장을 기다리며 열어 두지 않는다)
  }
  if (!meta) throw new Error("상세 추출 실패(빈 응답)");
  // v67 STEP2: 렌더 미보장 상태로 '보강 완료' 금지 — 테무 성공 기준 미달이면 정직 실패(재시도/보강 실패).
  const verdict = _kgpEnrichVerdict(item, meta);
  if (!verdict.ok) throw new Error(verdict.reason);
  // C-F13-2b: 로그인 벽·확인 절차를 만났으면 **보강이 아니라 막힘**이다. 뚫지 않는다.
  if (meta.wall) { const e = new Error(meta.wall); e.kgpWall = true; throw e; }
  const body = _kgpEnrichBody(item.item_id, meta);
  const r = await fetch(`${settings.serverUrl}/api/v1/collect/enrich`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "Authorization": `Bearer ${settings.token}` },
    body: JSON.stringify(body),
  });
  const d = await r.json().catch(() => ({}));
  // F22: 사유 문장에 **상태코드를 넣지 않는다** — 이 글이 서랍·목록에 그대로 실려
  //   셀러가 「HTTP 502」를 읽게 된다. 셀러가 그 숫자로 할 수 있는 일은 없다.
  //   숫자는 여기 콘솔과 서버 로그에 남으니 부검에는 지장이 없다.
  if (!r.ok || !d || !d.ok) {
    try { console.warn("[고가수집기 보강] 서버 응답", r.status, d); } catch (e) {}
    throw new Error(r.ok ? "서버가 저장하지 못했어요" : "서버가 받지 못했어요");
  }
  return true;
}
// R1: 「보강 잠시 멈춤(1시간)」 — 팝업 토글이 kgp_enrich_pause_until(ms)을 쓴다. 멈춘 동안은 폴링도·큐도 안 돈다.
const KGP_ENRICH_PAUSE_MS = 60 * 60 * 1000;
async function _kgpPausedUntil() {
  try {
    const r = await chrome.storage.local.get("kgp_enrich_pause_until");
    const t = Number((r && r.kgp_enrich_pause_until) || 0);
    return t > Date.now() ? t : 0;
  } catch (e) { return 0; }
}
async function _kgpEnrichLoop() {
  if (KgpEnrich.running) return;
  KgpEnrich.running = true;
  const settings = await getSettings();
  while (KgpEnrich.queue.length && !KgpEnrich.stopped) {
    if (KgpEnrich.paused) { await _kgpSleep(600); continue; }
    if (await _kgpPausedUntil()) break;      // R1: 1시간 멈춤 — 남은 큐는 그대로 두고 손 뗀다(창 0)
    const item = KgpEnrich.queue.shift();
    try {
      await _kgpEnrichOne(item, settings);
      KgpEnrich.ok++;
    } catch (e) {
      // C-F13-2b: 벽에 막힌 건 **다시 시도해도 같다** — 서버에 사유를 적고 다음 항목으로 간다.
      //   나머지 실패는 상한(3회)까지 재시도. 상한을 넘기면 그 사실도 서버에 적는다.
      const wall = !!(e && e.kgpWall);
      const reason = (e && e.message) || "알 수 없는 오류";
      if (wall) {
        await _kgpReportBlocked(item, reason, settings);
        KgpEnrich.blocked++;
        KgpEnrich.failures.push({ item_id: item.item_id, url: item.url, reason: reason });
      } else {
        // R1 실측: 예전엔 3번째 실패에서야 서버에 적었다 → MV3 워커가 그 전에 내려가면 **시도 0회**로 남아
        //   5분마다 같은 항목을 다시 열었다(운영 대기 21건 전부 attempts 0). 이제 **실패마다** 적는다 —
        //   서버가 횟수를 세고 상한(3)에 닿으면 `blocked`로 대기 목록에서 뺀다. 재시도는 서버 답을 따른다.
        const rep = await _kgpReportBlocked(item, reason, settings);
        const again = rep && rep.state === "pending" && !KgpEnrich.stopped
          && (item.retries || 0) + 1 < KGP_ENRICH_MAX_RETRIES;     // 서버가 틀려도 이 확장 안에선 3번까지
        if (again) {
          item.retries = (item.retries || 0) + 1;
          KgpEnrich.queue.push(item);
          KgpEnrich.done++; _kgpBroadcastEnrich();
          if (!KgpEnrich.stopped) await _kgpSleep(_kgpEnrichDelayMs());
          continue;
        }
        KgpEnrich.failed++;                     // 상한 도달(또는 서버 답 없음) → '보강 실패' 정직 집계
        KgpEnrich.failures.push({ item_id: item.item_id, url: item.url, reason: reason });
      }
    }
    KgpEnrich.done++;
    KgpEnrich.current = "";
    _kgpBroadcastEnrich();
    if (KgpEnrich.queue.length && !KgpEnrich.stopped) await _kgpSleep(_kgpEnrichDelayMs());
  }
  KgpEnrich.running = false;
  KgpEnrich.current = "";
  _kgpBroadcastEnrich();
}
// ── C-F13-2a: 보강 대기 폴러 ────────────────────────────────────────────────
//   실측(F9-2)이 찾은 세 겹 막힘 중 마지막 하나 — `/enrich/pending`을 **아무도 안 집어갔다.**
//   만들어 둔 큐에 소비자가 없으면 그건 기능이 아니라 장식이다.
//
//   왜 확장이 하나: 타오바오 상세는 **로그인된 브라우저에서만** 열린다(오너 실측). 서버는 못 한다.
//   언제: 콘솔 탭을 열 때 + 5분마다(MV3 서비스워커는 잠들므로 `setInterval`이 아니라 `alarms`).
//   어떻게: 동시 1탭 · 항목 간 3~8초 · 재시도 3회 · 벽을 만나면 사유를 적고 다음으로.
const KGP_ENRICH_ALARM = "kgpEnrichPoll";
const KGP_ENRICH_POLL_MIN = 5;

async function _kgpReportBlocked(item, reason, settings) {
  // 막힘을 **서버에 적는다.** 안 적으면 다음 순회가 같은 벽에 또 박고, 화면은 이유를 모른다.
  try {
    const r = await fetch(`${settings.serverUrl}/api/v1/collect/enrich/blocked`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${settings.token}` },
      body: JSON.stringify({ item_id: item.item_id, reason: String(reason || "").slice(0, 200) }),
    });
    return await r.json().catch(() => null);      // R1: {attempts, state} — 루프가 재시도 여부를 서버 답으로 정한다
  } catch (e) {
    try { console.warn("[고가수집기 보강] 막힘 보고 실패:", e && e.message); } catch (e2) {}
    return null;
  }
}

let _kgpLastPollAt = 0;
const KGP_ENRICH_POLL_GAP_MS = 60 * 1000;   // R1: 콘솔 페이지를 옮길 때마다 폴링하던 것 — 1분에 한 번만
async function _kgpPollPending(reason) {
  const settings = await getSettings();
  if (!settings.token) return { ok: false, error: "토큰 미설정" };
  if (await _kgpPausedUntil()) return { ok: true, added: 0, paused: true };
  if (Date.now() - _kgpLastPollAt < KGP_ENRICH_POLL_GAP_MS) return { ok: true, added: 0, throttled: true };
  _kgpLastPollAt = Date.now();
  let items = [];
  try {
    const r = await fetch(`${settings.serverUrl}/api/v1/collect/enrich/pending?limit=25`, {
      headers: { "Authorization": `Bearer ${settings.token}`, "X-KGP-Ext-Version": _kgpExtVersion() },
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok || !d || !d.ok) return { ok: false, error: "대기 목록 조회 실패 HTTP " + r.status };
    items = Array.isArray(d.items) ? d.items : [];
  } catch (e) {
    return { ok: false, error: (e && e.message) || "네트워크 오류" };
  }
  // 이미 큐에 있는 항목은 다시 넣지 않는다 — 폴링이 5분마다 도는데 중복을 넣으면 같은 상품을
  //   여러 번 열게 되고, 그건 봇 신호다.
  const fresh = items.filter((it) => it && it.item_id && it.url && !KgpEnrich.queued.has(it.item_id));
  if (!fresh.length) return { ok: true, added: 0, pending: items.length };
  fresh.forEach((it) => KgpEnrich.queued.add(it.item_id));
  try { console.log(`[고가수집기 보강] ${reason}: 대기 ${items.length}건 중 ${fresh.length}건 큐 투입`); } catch (e) {}
  handleEnrichStart(fresh.map((it) => ({ item_id: it.item_id, url: it.url })), null);
  return { ok: true, added: fresh.length, pending: items.length };
}

function _kgpIsConsoleUrl(url, serverUrl) {
  if (!url || !serverUrl) return false;
  try {
    return new URL(url).host === new URL(serverUrl).host && /\/seller(\/|$)/.test(new URL(url).pathname);
  } catch (e) { return false; }
}

try {
  if (chrome.alarms && chrome.alarms.create) {
    chrome.alarms.create(KGP_ENRICH_ALARM, { periodInMinutes: KGP_ENRICH_POLL_MIN });
    chrome.alarms.onAlarm.addListener((a) => {
      if (a && a.name === KGP_ENRICH_ALARM) _kgpPollPending(`${KGP_ENRICH_POLL_MIN}분 주기`);
    });
  }
} catch (e) { /* alarms 미가용 환경은 탭 열림만으로 돈다 */ }

// Y12-D 7: heartbeat — 콘솔 탭이 열려 있으면 1분마다 「살아 있다」 + 버전을 서버에 적는다(대시보드 「PC 수집기 · 연결 HH:MM」).
//   탭이 없으면 보내지 않는다(PC는 켜져 있어도 재수집은 콘솔 탭이 있어야 돈다 — 그 사실을 그대로 보여 준다).
const KGP_BEAT_ALARM = "kgpBeat";
function _kgpExtVersion() {
  try { return String((chrome.runtime.getManifest() || {}).version || ""); } catch (e) { return ""; }
}
async function _kgpBeat() {
  const settings = await getSettings();
  if (!settings.token || !settings.serverUrl) return;
  let open = false;
  try {
    const tabs = await chrome.tabs.query({});
    open = (tabs || []).some((t) => t && _kgpIsConsoleUrl(t.url, settings.serverUrl));
  } catch (e) { return; }
  if (!open) return;
  try {
    await fetch(`${settings.serverUrl}/api/v1/collect/ext/beat`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${settings.token}`, "X-KGP-Ext-Version": _kgpExtVersion() },
      body: JSON.stringify({ version: _kgpExtVersion() }),
    });
  } catch (e) { /* 신호 실패는 조용히 — 다음 분에 다시 */ }
}
try {
  if (chrome.alarms && chrome.alarms.create) {
    chrome.alarms.create(KGP_BEAT_ALARM, { periodInMinutes: 1 });
    chrome.alarms.onAlarm.addListener((a) => { if (a && a.name === KGP_BEAT_ALARM) _kgpBeat(); });
  }
} catch (e) { /* noop */ }

// 콘솔 탭이 열리면 즉시 한 번 — 오너가 화면을 열어 둔 그 순간이 가장 좋은 시점이다.
try {
  chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
    if (!info || info.status !== "complete" || !tab || !tab.url) return;
    const settings = await getSettings();
    if (_kgpIsConsoleUrl(tab.url, settings.serverUrl)) { _kgpPollPending("콘솔 탭 열림"); _kgpBeat(); }
  });
} catch (e) { /* noop */ }

// R1: 1시간 멈춤을 풀면(토글 끔·시간 경과 뒤 알람) 남은 큐를 이어서 돈다.
try {
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== "local" || !ch || !ch.kgp_enrich_pause_until) return;
    const v = Number(ch.kgp_enrich_pause_until.newValue || 0);
    if (v <= Date.now() && KgpEnrich.queue.length && !KgpEnrich.running) _kgpEnrichLoop();
    _kgpBroadcastEnrich();
  });
} catch (e) { /* noop */ }

function handleEnrichStart(targets, sendResponse) {
  const items = (Array.isArray(targets) ? targets : [])
    .filter((t) => t && t.item_id && t.url)
    .map((t) => ({ item_id: String(t.item_id), url: String(t.url), retries: 0 }));
  if (!items.length) { if (sendResponse) sendResponse({ ok: false, error: "보강할 항목이 없습니다." }); return; }
  // 새 배치: 카운터 초기화(진행 중이면 이어붙임).
  if (!KgpEnrich.running) { KgpEnrich.done = 0; KgpEnrich.failed = 0; KgpEnrich.ok = 0; KgpEnrich.stopped = false; KgpEnrich.paused = false; KgpEnrich.total = 0; KgpEnrich.failures = []; }
  KgpEnrich.queue.push(...items);
  KgpEnrich.total += items.length;
  if (sendResponse) sendResponse({ ok: true, total: KgpEnrich.total });
  _kgpEnrichLoop();
}

async function collectFromTab(tab) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: extractMeta
    });
    if (results && results[0] && results[0].result) {
      const meta = results[0].result;
      await handleCollect(meta, null);
    }
  } catch (err) {
    console.error("수집 실패:", err);
    chrome.notifications.create({
      type: "basic",
      iconUrl: "icons/48.png",
      title: "고가브릿지",
      message: "수집 실패: " + (err.message || "알 수 없는 오류")
    });
  }
}

// 보강 본문 — **한 곳**에서 만든다(대기열 보강 · F49-T 초안 채우기가 같이 쓴다).
function _kgpEnrichBody(itemId, meta) {
  return {
    item_id: itemId,
    options: meta.options || [],
    description: meta.description || "",
    detail_images: meta.detail_images || [],
    gallery: meta.gallery_images || meta.images || [],
    reviews: meta.reviews || [],
    rating: meta.rating || "",
    review_count: meta.review_count || "",
    // C-F13-2a: 타오바오 가격 두 개를 **따로** 올린다(优惠前/补贴后). 서버가 섞지 않고 담는다.
    price: meta.price || "",
    price_list: meta.price_list || "",
    price_final: meta.price_final || "",
    currency: meta.currency || "",
    // F49-T: 왜 못 읽었나 — 페이지 진단도 같이(서버가 필드별 사유를 이걸로만 말한다).
    page_diag: meta.page_diag || null,
    // F49-T 3부: 목록 카드 → 상세(ICE) 보강 경로에도 SKU가 실려야 한다. 전엔 보강 본문에 skus가 없어
    //   목록에서 누른 수집은 상세를 열고도 SKU 0으로 끝났다(2부는 상세 페이지 직접 수집만 담았다).
    skus: meta.skus || [],
    field_sources: meta.field_sources || null,
    // F49-T 5부: 원본 갤러리 장 수(ICE item.images) — 서버가 「갤러리 ≥ 원본」 완료 기준을 잰다.
    gallery_expected: (meta.field_sources && meta.field_sources.images === "ice_context")
      ? (meta.gallery_images || meta.images || []).length : 0,
  };
}

// F49-T — 서버가 「채우기를 기다리는 초안」이라고 답하면(`draft_pending`) **보강으로 채운다.**
//   예전엔 「이미 수집한 상품」으로 끝나서, 사람이 페이지를 열고 눌러도 초안이 비어 있었다.
async function _kgpFillDraft(settings, data, meta) {
  if (meta && meta.page_diag && meta.page_diag.wall) {
    return { ...data, ok: false, error: `로그인·확인 화면이라 채우지 못했어요 — ${meta.page_diag.wall}` };
  }
  try {
    const r = await fetch(`${settings.serverUrl}/api/v1/collect/enrich`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${settings.token}` },
      body: JSON.stringify(_kgpEnrichBody(data.item_id, meta || {})),
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok || !d || !d.ok) {
      try { console.warn("[고가수집기] 초안 채우기 서버 응답", r.status, d); } catch (e) {}
      return { ...data, ok: false, error: "초안을 채우지 못했어요(서버가 저장하지 못함)" };
    }
    const n = Object.keys(d.changed || {}).length;
    return { ...data, ok: true, duplicate: false, enriched: true, filled: d.filled, total: d.total,
             message: n ? `담아 둔 초안을 채웠어요 (${d.filled}/${d.total} 필드)`
                        : "이 페이지에서 새로 채울 값이 없었어요" };
  } catch (e) {
    return { ...data, ok: false, error: "초안을 채우지 못했어요(네트워크)" };
  }
}

async function handleCollect(meta, sendResponse) {
  const settings = await getSettings();
  const serverUrl = settings.serverUrl;
  const token = settings.token;

  if (!token) {
    // v42 E-1: 미인증 자동 토스트 남발 금지 — 알림 만들지 않고 호출부(FAB 클릭)에만 안내 반환.
    const result = { ok: false, authRequired: true,
                     error: "토큰이 설정되지 않았습니다. 확장 옵션에서 토큰을 설정해주세요." };
    if (sendResponse) sendResponse(result);
    return;
  }

  const endpoint = `${serverUrl}/api/v1/collect/extension`;
  // P0 진단: 요청에 인증 토큰이 실렸는지 콘솔에 노출(값은 마스킹). 미인증(HTML 로그인 응답) 원인 규명용.
  console.log(`[고가수집기] 인증 토큰 ${token ? "첨부됨(Bearer …" + String(token).slice(-4) + ")" : "없음 — 확장 옵션에서 토큰을 설정하세요"} → POST ${endpoint}`);
  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${token}` },
      body: JSON.stringify(_kgpWithTranslateFlag(meta, settings.translate))   // v83.1 STEP1
    });
    // P0 진단: 엔드포인트·HTTP 상태·응답 본문(원문)을 확장 콘솔에 로그 → 원인 1줄(401/404/500/CORS).
    const raw = await response.text();
    let data = {};
    try { data = JSON.parse(raw); } catch (e) { data = {}; }
    console.log(`[고가수집기] POST ${endpoint} → ${response.status} ${response.statusText}`,
                "\n응답:", raw.slice(0, 400));
    if (response.status === 401) data.authRequired = true;
    // 서버가 JSON을 못 준 경우(로그인 리다이렉트·HTML 오류 페이지 등)도 조용한 실패 금지.
    const _looksHtml = /^\s*<(!doctype|html)/i.test(raw);
    if (!data || (typeof data.ok === "undefined")) {
      data = { ok: false,
               error: _looksHtml ? `서버 응답 오류(로그인 확인이 필요할 수 있어요). HTTP ${response.status}`
                                 : `서버 오류 (HTTP ${response.status}). 잠시 후 다시 시도하세요.`,
               httpStatus: response.status };
    }
    if (!data.error && !data.ok) data.error = `수집 실패 (HTTP ${response.status})`;
    if (data.httpStatus === undefined) data.httpStatus = response.status;
    if (data.ok && data.draft_pending && data.item_id) {
      data = await _kgpFillDraft(settings, data, meta);
    }

    if (sendResponse) sendResponse(data);
    // 알럿 중복 방지: content_script가 인페이지 토스트로 결과를 보여주는 경로(sendResponse 있음)에서는
    //   OS 알림을 만들지 않는다(토스트+OS알림 이중 알럿 제거). 컨텍스트 메뉴 등 토스트 없는 경로만 OS 알림.
    if (!sendResponse) {
      chrome.notifications.create({
        type: "basic", iconUrl: "icons/48.png", title: "고가브릿지",
        message: data.ok ? `수집 완료: ${meta.title || meta.url}`
                         : `수집 실패 (${response.status}): ${data.error || ""}`.slice(0, 180)
      });
    }
  } catch (err) {
    // 네트워크/CORS 실패 등 — 엔드포인트와 함께 로그.
    console.error(`[고가수집기] 수집 요청 실패 POST ${endpoint}:`, err);
    const result = { ok: false, error: `네트워크 오류: ${err.message || "서버에 연결하지 못했습니다"}`, networkError: true };
    if (sendResponse) sendResponse(result);
    chrome.notifications.create({
      type: "basic", iconUrl: "icons/48.png", title: "고가브릿지", message: result.error
    });
  }
}

// 리스팅 다중 상품 일괄 수집 (Phase 221)
// content_script가 보낸 상품 카드 메타 배열을 토큰으로 순차 전송한다.
// background fetch라 페이지 CSP의 영향을 받지 않는다.
async function handleCollectBulk(items, sendResponse, tabId) {
  const settings = await getSettings();
  const serverUrl = settings.serverUrl;
  const token = settings.token;
  items = Array.isArray(items) ? items : [];

  if (!token) {
    if (sendResponse) sendResponse({ ok: false, authRequired: true,
      error: "토큰이 설정되지 않았습니다. 확장 옵션에서 토큰을 설정하세요." });
    return;
  }
  if (!items.length) {
    if (sendResponse) sendResponse({ ok: false, error: "수집할 상품이 없습니다." });
    return;
  }

  // v42 E-5: 항목별 서버 커밋(+ID 회신) 후에만 성공 카운트. 중복/실패 분리 집계 + 실패 항목 반환(재시도).
  //   순차 처리(동시 폭주로 인한 유실 방지) + 1건마다 진행률을 탭에 전송(bulkProgress).
  let success = 0, failed = 0, duplicate = 0;
  const failedItems = [];
  const enrichTargets = [];   // v64 STEP1: 2단 보강 대상(서버가 회신한 item_id + 상세 URL)
  let _extVer = ""; try { _extVer = chrome.runtime.getManifest().version; } catch (e) {}
  // P0 진단: 벌크도 인증 토큰 첨부 여부를 콘솔에 노출(마스킹).
  console.log(`[고가수집기] 벌크 ${items.length}건 · 인증 토큰 ${token ? "첨부됨(Bearer …" + String(token).slice(-4) + ")" : "없음"}`);
  for (let i = 0; i < items.length; i++) {
    const meta = items[i];
    if (meta && !meta.ext_version) meta.ext_version = _extVer;   // P0 하위호환·진단
    try {
      const r = await fetch(`${serverUrl}/api/v1/collect/extension`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": `Bearer ${token}` },
        body: JSON.stringify(_kgpWithTranslateFlag(meta, settings.translate)),   // v83.1 STEP1
      });
      const raw = await r.text();
      let d = {}; try { d = JSON.parse(raw); } catch (e) { d = {}; }
      if (!r.ok || typeof d.ok === "undefined") {   // P0 진단: 실패 1건 상태·본문 로그(첫 실패만 상세)
        if (failed === 0) console.log(`[고가수집기] 벌크 실패 HTTP ${r.status}:`, raw.slice(0, 300));
      }
      if (d && d.ok && d.duplicate) duplicate++;      // 이미 수집(중복) — '완료'로 부풀리지 않음
      else if (d && d.ok) success++;                  // 서버 커밋 성공(STEP 1-0 write-then-verify)
      else { failed++; failedItems.push(meta); }      // 502 등 정직 실패 → 재시도 대상
      // v64 STEP1: 성공·중복 항목은 상세 보강 대상(item_id + 상세 URL). 실패는 제외.
      if (d && d.ok && d.item_id && meta && meta.url) enrichTargets.push({ item_id: d.item_id, url: meta.url });
    } catch (e) {
      if (failed === 0) console.error("[고가수집기] 벌크 네트워크 오류:", e);
      failed++; failedItems.push(meta);
    }
    if (tabId != null) {
      try { chrome.tabs.sendMessage(tabId, { action: "bulkProgress", done: i + 1, total: items.length }); } catch (_) {}
    }
  }

  const parts = [`완료 ${success}`];
  if (duplicate) parts.push(`중복 ${duplicate}`);
  if (failed) parts.push(`실패 ${failed}`);
  // 알럿 중복 방지: content가 인페이지 요약을 보여주는 경로(sendResponse)에선 OS 알림 생략.
  if (!sendResponse) {
    chrome.notifications.create({
      type: "basic", iconUrl: "icons/48.png", title: "고가브릿지",
      message: `일괄 수집 (총 ${items.length}): ${parts.join(" · ")}`,
    });
  }
  if (sendResponse) sendResponse({ ok: true, success, failed, duplicate, total: items.length, failedItems, enrichTargets });
}

// content_script에서 호출할 메타 추출 함수 (executeScript용)
function extractMeta() {
  const getMeta = (prop) => {
    const el = document.querySelector(`meta[property="${prop}"], meta[name="${prop}"]`);
    return el ? el.getAttribute("content") : null;
  };

  const jsonldScripts = [...document.querySelectorAll('script[type="application/ld+json"]')]
    .map(s => { try { return JSON.parse(s.innerText || s.textContent); } catch { return null; } })
    .filter(Boolean);

  const ogImage = getMeta("og:image") || getMeta("og:image:url") || "";

  return {
    url: location.href,
    title: getMeta("og:title") || document.title,
    image: ogImage,
    images: ogImage ? [ogImage] : [],
    price: getMeta("product:price:amount"),
    // v86-I: 빈 통화에 USD 기본값 주입 금지 — 빈 값은 빈 값으로 보내고 서버가 '통화 미수신'으로 정직 표기한다.
    //   임의 USD는 원화 상품을 달러로 둔갑시켜 가격 검증·마진 계산을 통째로 오염시킨다(v42 1-1 계보).
    currency: getMeta("product:price:currency") || "",
    description: getMeta("og:description") || getMeta("description"),
    brand: getMeta("og:brand") || "",
    jsonld: jsonldScripts,
    collected_at: new Date().toISOString()
  };
}
