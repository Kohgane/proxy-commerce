/**
 * content_script.js — 페이지 컨텍스트에서 메타 추출 + 인페이지 '수집' 버튼 (Phase 202+)
 * 고가수집기
 *
 * 1) 백그라운드/팝업에서 "extractMeta" 메시지 요청 시 메타 응답.
 * 2) v10: '지정 소싱처' 도메인에서만 수집 UI(FAB/리스팅 바)를 주입한다(그 외 사이트엔 아무것도 안 그림).
 *    소싱처는 기본셋 + 사용자 지정(chrome.storage.local의 kgp_sources)로 관리, 런타임 즉시 반영.
 * 3) 리스팅은 사이트 어댑터(아마존 등) + 엄격 휴리스틱으로 '실제 제품 카드만' 감지(추천/푸터/썸네일 제외).
 */

// v39-E2 #1: PDP 가격 노드에서 '현재가(판매가)'를 읽는다(취소선·추천/리뷰 영역 제외).
//   서버 스코프 추출(_extract_scoped_price)과 동일 취지의 인페이지 판.
const _KGP_ORIG_PRICE_RE = /(original|was[-_ ]?price|strike|line[-_]?through|regular|list[-_]?price|old[-_]?price|compare[-_]?at|정가|원가|할인전)/i;
const _KGP_NONPROD_RE = /(recommend|related|similar|also[-_ ]?(bought|viewed)|sponsored|advert|ranking|recently[-_ ]?viewed|carousel|cross[-_ ]?sell|up[-_ ]?sell|footer|review|comment)/i;
function _kgpPriceIsOriginal(el) {
  let cur = el, depth = 0;
  while (cur && depth < 4) {
    const tag = (cur.tagName || "").toLowerCase();
    if (tag === "del" || tag === "s" || tag === "strike") return true;
    const tok = ((cur.className && cur.className.baseVal !== undefined ? cur.className.baseVal : (cur.className || "")) + " " + (cur.id || ""));
    if (tok && _KGP_ORIG_PRICE_RE.test(tok)) return true;
    try { if ((getComputedStyle(cur).textDecorationLine || "").indexOf("line-through") >= 0) return true; } catch (e) { /* noop */ }
    cur = cur.parentElement; depth++;
  }
  return false;
}
function _kgpInNonProd(el) {
  let cur = el && el.parentElement, depth = 0;
  while (cur && depth < 6) {
    const tok = ((cur.className && cur.className.baseVal !== undefined ? cur.className.baseVal : (cur.className || "")) + " " + (cur.id || ""));
    if (tok && _KGP_NONPROD_RE.test(tok)) return true;
    cur = cur.parentElement; depth++;
  }
  return false;
}
// v42 1-1: 통화 감지에 한국어/일본어/중국어 접미어(원·엔·위안·元) 포함 — Temu KR은 '₩' 또는 '61,144원'.
const _KGP_SYM_MAP = { "$": "USD", "＄": "USD", "€": "EUR", "£": "GBP", "¥": "JPY", "￥": "JPY", "₩": "KRW", "￦": "KRW" };
const _KGP_CODE_MAP = {
  "USD": "USD", "EUR": "EUR", "GBP": "GBP", "JPY": "JPY", "KRW": "KRW", "CNY": "CNY",
  "원": "KRW", "엔": "JPY", "円": "JPY", "위안": "CNY", "元": "CNY",   // v87-#597: 円(엔 한자)→JPY
};
const _KGP_PRICE_RE = /([\$＄€£¥￥₩￦])\s*([\d,]+(?:\.\d{1,2})?)|([\d,]+(?:\.\d{1,2})?)\s*(USD|EUR|GBP|JPY|KRW|CNY|원|엔|円|위안|元)/i;
function _kgpParsePrice(raw) {
  const m = (raw || "").match(_KGP_PRICE_RE);
  if (!m) return null;
  const sym = m[1] || "", num = (m[2] || m[3] || "").replace(/,/g, ""), code = m[4] || "";
  if (!num) return null;
  const cur = code ? (_KGP_CODE_MAP[code] || _KGP_CODE_MAP[code.toUpperCase()] || code.toUpperCase())
                   : (_KGP_SYM_MAP[sym] || "");
  return { price: num, currency: cur };
}
// 가격이 아닌 숫자(재고 '9개 남음'·쿠폰·수량·배송·평점·판매수)를 걸러 Temu '9 KRW' 오추출을 막는다.
const _KGP_NONPRICE_RE = /(재고|남음|남았|개\s*남|수량|qty|quantity|stock|left|in\s*cart|장바구니|쿠폰|coupon|적립|포인트|point|리뷰|review|평점|rating|판매|sold|명이|배송비|shipping\s*fee|무료배송|free\s*shipping|할인율|% ?off|퍼센트)/i;
function _kgpNonPriceCtx(el) {
  // 노드 자신·근접 조상(4단계) 텍스트/클래스에 재고·쿠폰·수량 신호가 있으면 가격 후보에서 제외.
  let cur = el, depth = 0;
  while (cur && depth < 4) {
    const tok = ((cur.className && cur.className.baseVal !== undefined ? cur.className.baseVal : (cur.className || "")) + " " + (cur.id || ""));
    if (tok && _KGP_NONPRICE_RE.test(tok)) return true;
    cur = cur.parentElement; depth++;
  }
  // 노드 자신 텍스트가 '9개 남음'처럼 재고/수량 문구면 제외(가격 숫자와 혼동 방지).
  const own = (el.textContent || "").slice(0, 40);
  if (_KGP_NONPRICE_RE.test(own)) return true;
  return false;
}
function _kgpNodePath(el) {
  var parts = [], cur = el, n = 0;
  while (cur && n < 4) {
    var t = (cur.tagName || "").toLowerCase();
    var c = (cur.className && cur.className.baseVal !== undefined ? cur.className.baseVal : (cur.className || ""));
    parts.unshift(t + (c ? "." + String(c).trim().split(/\s+/).slice(0, 2).join(".") : ""));
    cur = cur.parentElement; n++;
  }
  return parts.join(" > ");
}
function _kgpScopedPrice() {
  // P0(오너): Temu 실가 20,605원인데 9 KRW 저장 = 재고 '9개 남음'/쿠폰 숫자를 가격으로 오인.
  //   수리: ①재고·쿠폰·수량·평점 문맥 제외 ②원가(취소선)·추천/리뷰 제외 ③**메인 가격은 화면에서
  //   가장 큰 글씨** → 후보를 폰트 크기로 스코어(동률이면 큰 값). 후보·채택 노드경로를 콘솔 로그.
  let nodes = [];
  try {
    nodes = Array.from(document.querySelectorAll('[class*="price" i],[class*="Price"],[itemprop="price"],[data-price],[class*="amount" i],[aria-label*="price" i]'));
  } catch (e) { nodes = []; }
  const cands = [];
  for (const el of nodes) {
    if (_kgpInNonProd(el) || _kgpPriceIsOriginal(el) || _kgpNonPriceCtx(el)) continue;
    const raw = el.getAttribute("content") || el.getAttribute("data-price") || (el.textContent || "").trim();
    const p = _kgpParsePrice(raw);
    if (!p) continue;
    let fs = 0;
    try { fs = parseFloat(getComputedStyle(el).fontSize) || 0; } catch (e) { fs = 0; }
    cands.push({ price: p.price, currency: p.currency, val: parseFloat(p.price) || 0, fs: fs, path: _kgpNodePath(el) });
  }
  // 메인 가격 = 가장 큰 글씨(시각적 프로미넌스). 폰트 정보 없으면 큰 값으로.
  cands.sort((a, b) => (b.fs - a.fs) || (b.val - a.val));
  const best = cands[0] || null;
  try {
    console.log("[고가수집기] 가격 후보(" + cands.length + "):",
      cands.slice(0, 8).map(c => c.price + " " + c.currency + " @" + c.fs + "px [" + c.path + "]"));
    if (best) console.log("[고가수집기] 채택 가격:", best.price, best.currency, "| node:", best.path);
  } catch (e) {}
  return best ? { price: best.price, currency: best.currency } : { price: "", currency: "" };
}

// v45(5): 클릭 시점 옵션(색상/사이즈/수량/변형) 추출 — payload.options로 전송(서버가 편집 프리필).
//   보수적: <select> + 라벨 붙은 스와치 그룹(값 2개 이상)만. 추천/리뷰 영역·과다 그룹 제외.
const _KGP_OPT_LABEL = /(색상|색깔|컬러|사이즈|크기|규격|수량|종류|옵션|타입|스타일|모델|용량|color|colour|size|variant|option|type|style|qty|quantity|model|capacity)/i;
function _kgpOptName(around) {
  const m = (around || "").match(_KGP_OPT_LABEL);
  return m ? m[0] : "옵션";
}
function _kgpCollectOptions() {
  const out = [], seen = new Set();
  try {
    // 1) <select> 드롭다운
    document.querySelectorAll("select").forEach((sel) => {
      if (_kgpInNonProd(sel)) return;
      const opts = Array.from(sel.options || []).map((o) => (o.textContent || "").trim())
        .filter((t) => t && !/^(선택|선택하세요|choose|select|please)/i.test(t));
      const uniq = Array.from(new Set(opts));
      if (uniq.length >= 2) {
        const lbl = sel.getAttribute("aria-label") || (sel.labels && sel.labels[0] && sel.labels[0].textContent) || "";
        out.push({ name: _kgpOptName(lbl), values: uniq.slice(0, 50) });
      }
    });
    // 2) 스와치/변형 그룹
    document.querySelectorAll('[class*="sku" i],[class*="variant" i],[class*="option" i],[class*="attr" i],[role="radiogroup"],[class*="spec" i]').forEach((grp) => {
      if (_kgpInNonProd(grp)) return;
      const vals = [];
      grp.querySelectorAll('button,[role="radio"],li,span[aria-label],img[alt],[class*="item" i]').forEach((el) => {
        let t = (el.getAttribute("aria-label") || el.getAttribute("title") || el.getAttribute("alt") || el.textContent || "").replace(/\s+/g, " ").trim();
        if (t && t.length >= 1 && t.length <= 40 && !_KGP_OPT_LABEL.test(t) && vals.indexOf(t) < 0) vals.push(t);
      });
      if (vals.length >= 2 && vals.length <= 60) {
        const lblEl = grp.querySelector('[class*="label" i],[class*="title" i],dt,legend');
        const around = ((lblEl && lblEl.textContent) || "") + " " + ((grp.previousElementSibling && grp.previousElementSibling.textContent) || "") + " " + (grp.getAttribute("aria-label") || "");
        const name = _kgpOptName(around);
        const key = name + "|" + vals.slice(0, 4).join(",");
        if (!seen.has(key)) { seen.add(key); out.push({ name: name, values: vals.slice(0, 50) }); }
      }
    });
  } catch (e) { /* noop */ }
  return out.slice(0, 8);
}

// v44: 사이트별 PDP 추출 — 서버 사후 크롤(봇 차단 영구실패) 대신 클릭 시점 렌더 DOM에서 직접 읽기.
//   아마존: #imgTagWrapperId(고해상)·#altImages 썸네일→원본 · #feature-bullets·#productDescription·#aplus.
//   Temu: 메인 캐러셀 컨테이너 · 상세 영역. 갤러리/상세 2버킷.
function _kgpAmazonHiRes(u) {
  if (!u) return u;
  // 아마존 이미지 URL의 크기/포맷 수식자(._AC_SX466_ · ._SS40_ 등) 제거 → 원본 고해상.
  return u.replace(/\._[A-Za-z0-9,_-]+_\.(jpg|jpeg|png|gif|webp)/i, ".$1");
}
// C-F13-2b: 로그인 벽·확인 절차(캡차) **감지만** 한다. 뚫는 코드는 우회이고 금지다.
//   감지 근거는 화면에 실제로 보이는 것뿐 — 주소·제목·본문의 로그인/검증 표시.
function _kgpDetectWall() {
  try {
    const host = (location.hostname || "").toLowerCase();
    const path = (location.pathname || "").toLowerCase();
    if (/login|passport|sec\.|verify|punish/.test(host + path)) return "로그인·확인 페이지로 이동됨";
    const t = (document.title || "");
    if (/登录|登陆|请登录|验证|安全验证|滑动验证|Sign in|Log in/i.test(t)) return "제목이 로그인·검증 화면";
    if (document.querySelector(
      "#login, .login-box, [class*='loginWrap'], [id*='nc_1_wrapper'], [class*='nc-container'], " +
      "[class*='captcha'], [id*='captcha'], [class*='SlideVerify']")) return "로그인·검증 요소 발견";
    return "";
  } catch (e) { return ""; }
}

function _kgpSitePdp() {
  const host = (location.hostname || "").toLowerCase();
  const out = { gallery: [], detail: [], description: "" };
  const _add = (arr, u) => { u = (u || "").trim(); if (u && u.indexOf("data:") !== 0 && arr.indexOf(u) < 0) arr.push(u); };
  try {
    // C-F13-2a: 타오바오·티몰 상세. **로그인된 크롬에서만** 열린다(실측) — 그래서 이 코드는
    //   확장 안에서만 의미가 있다. 서버는 이 페이지를 못 읽는다.
    //   가격은 두 개다: 优惠前(할인 전)과 补贴后(보조금 후). **둘 다 따로** 담는다 —
    //   하나로 합치면 어느 쪽인지 영영 모르고, 마진의 분모가 흔들린다.
    if (/(^|\.)(taobao|tmall)\.com$/.test(host)) {
      // 큰 이미지 전체 — 썸네일 크기 토큰(_50x50, _q90 등)을 떼서 원본을 노린다.
      const _tbHi = (u) => (u || "").replace(/_\d+x\d+(xz)?(\.jpg|\.png|\.webp)?(_\.webp)?$/i, "")
                                    .replace(/_[qQ]\d+(\.jpg|\.webp)?$/i, "");
      document.querySelectorAll(
        "#J_UlThumb img, .tb-thumb img, [class*='thumbnail'] img, [class*='PicGallery'] img, " +
        "[class*='mainPic'] img, [class*='MainPic'] img, [class*='preview'] img"
      ).forEach((im) => _add(out.gallery, _tbHi(im.getAttribute("data-src") || im.currentSrc || im.src || "")));
      // 상세 이미지(描述) — 지연 로딩이라 data-ks-lazyload를 함께 본다.
      document.querySelectorAll(
        "#description img, #J_DivItemDesc img, [class*='desc'] img, [class*='Detail'] img"
      ).forEach((im) => _add(out.detail,
        _tbHi(im.getAttribute("data-ks-lazyload") || im.getAttribute("data-src")
              || im.currentSrc || im.src || "")));
      // 옵션 — 颜色分类·尺码 등. 라벨과 값을 짝지어 담는다(값만 담으면 무슨 축인지 모른다).
      out.options = [];
      document.querySelectorAll("#J_isku .tb-prop, [class*='SkuContent'] [class*='valueItemWrapper'], [class*='skuItem']").forEach((grp) => {
        const label = ((grp.querySelector(".tb-property-type, [class*='labelText'], dt") || {}).innerText || "").trim();
        const vals = [];
        grp.querySelectorAll("li a, [class*='valueItem'], [class*='valueItemText']").forEach((li) => {
          const t = (li.getAttribute("title") || li.innerText || "").trim();
          if (t && vals.indexOf(t) < 0) vals.push(t);
        });
        if (vals.length) out.options.push({ name: label || "옵션", values: vals });
      });
      // 가격 2종. 클래스명이 자주 바뀌므로 **텍스트 라벨**도 함께 본다(구조 변경 내성).
      const _num = (t) => {
        const m = String(t || "").replace(/,/g, "").match(/(\d+(?:\.\d+)?)/);
        return m ? m[1] : "";
      };
      const _byText = (needle) => {
        const els = Array.from(document.querySelectorAll("span,div,em,strong"));
        for (const el of els) {
          const t = (el.innerText || "").trim();
          if (t && t.length < 40 && t.indexOf(needle) >= 0) {
            const n = _num(t);
            if (n) return n;
          }
        }
        return "";
      };
      out.price_final = _num((document.querySelector("[class*='subsidy'] [class*='text'], [class*='Subsidy']") || {}).innerText)
                        || _byText("补贴后");
      out.price_list = _num((document.querySelector("[class*='originPrice'], [class*='OriginPrice'], .tb-rmb-num") || {}).innerText)
                       || _byText("优惠前");
      // 어느 쪽도 라벨로 못 찾으면 현재 표시가(단일)만 담는다 — 라벨을 지어내지 않는다.
      out.currency = "CNY";
    } else if (/(^|\.)amazon\.[a-z.]+$/.test(host)) {
      const main = document.querySelector("#imgTagWrapperId img, #landingImage, #imgBlkFront, #main-image");
      if (main) {
        _add(out.gallery, main.getAttribute("data-old-hires") || "");
        const dyn = main.getAttribute("data-a-dynamic-image");
        if (dyn) { try { Object.keys(JSON.parse(dyn)).forEach(u => _add(out.gallery, u)); } catch (e) { /* noop */ } }
        _add(out.gallery, _kgpAmazonHiRes(main.currentSrc || main.src || ""));
      }
      document.querySelectorAll("#altImages img, #imageBlockThumbs img, li.imageThumbnail img").forEach(im => {
        _add(out.gallery, _kgpAmazonHiRes(im.currentSrc || im.src || ""));
      });
      document.querySelectorAll("#aplus img, #aplus_feature_div img, #productDescription img").forEach(im => {
        _add(out.detail, _kgpAmazonHiRes(im.getAttribute("data-src") || im.currentSrc || im.src || ""));
      });
      const bullets = [];
      document.querySelectorAll("#feature-bullets li span.a-list-item, #feature-bullets li").forEach(li => {
        const t = (li.innerText || li.textContent || "").trim();
        if (t && t.length > 2 && bullets.indexOf(t) < 0) bullets.push("· " + t);
      });
      const pd = document.querySelector("#productDescription");
      const pdText = pd ? (pd.innerText || "").trim() : "";
      out.description = [bullets.join("\n"), pdText].filter(Boolean).join("\n\n").slice(0, 4000);
    } else if (/(^|\.)temu\.[a-z.]+$/.test(host)) {
      const gal = document.querySelector('[class*="gallery" i],[class*="Gallery" i],[class*="mainImage" i],[class*="swiper" i]');
      if (gal) gal.querySelectorAll("img").forEach(im => _add(out.gallery, im.currentSrc || im.src || im.getAttribute("data-src") || ""));
      const det = document.querySelector('[class*="detail" i],[class*="Description" i],[class*="goods-desc" i]');
      if (det) {
        det.querySelectorAll("img").forEach(im => _add(out.detail, im.currentSrc || im.src || im.getAttribute("data-src") || ""));
        // v44: Temu 상세 영역 텍스트 + 스펙표(속성표) — 본문 innerText가 스펙표 셀도 포함.
        const specRows = [];
        det.querySelectorAll("table tr, dl > dt, dl > dd, [class*='spec' i] li, [class*='attribute' i] li, [class*='param' i] li").forEach(el => {
          const t = (el.innerText || el.textContent || "").replace(/\s+/g, " ").trim();
          if (t && t.length >= 2 && specRows.indexOf(t) < 0) specRows.push(t);
        });
        const bodyText = (det.innerText || "").trim();
        out.description = [bodyText, specRows.length ? ("· " + specRows.slice(0, 40).join("\n· ")) : ""]
          .filter(Boolean).join("\n\n").slice(0, 4000);
      }
    }
  } catch (e) { /* noop */ }
  return out;
}

// ── F49-T 실측 도구 — 「왜 못 읽었나」를 **추출과 따로** 잰다 ─────────────────────────
//   추출 로직은 건드리지 않는다(kgp-extractor.js 무변경). 여기서 재는 것은 페이지의 **상태**다:
//   로그인 벽 · 내비게이션(HTTP 상태·리다이렉트) · 아직 안 불러온(lazy) 이미지 · 알려진 셀렉터 적중 수 ·
//   주입 뒤 페이지 오류. 서버는 이 값으로만 필드별 실패 사유를 말한다(없으면 「사유 미상」).
const _KGP_PAGE_ERRORS = [];
// F50: 사이트 규칙(데이터) — 서버에서 받은 캐시 → 번들(kgp-rules.js) → 여기 기본값 순. 재설치 없이 고친다.
function _kgpRule(path, dflt) {
  try { return (typeof KGPRules !== "undefined" && KGPRules) ? KGPRules.get(path, dflt) : dflt; } catch (e) { return dflt; }
}
function _kgpRulesInfo() {
  try { return (typeof KGPRules !== "undefined" && KGPRules) ? KGPRules.info() : { version: "", hash: "", source: "none" }; }
  catch (e) { return { version: "", hash: "", source: "none" }; }
}
// F49-T 3부: 예전엔 message가 비면 「error」 한 단어만 남았다(world.taobao 진단 errors 전부 "error").
//   캡처 단계 리스너라 **리소스 로드 실패**(img·script 404 — message 없음)도 같이 잡히는데, 그걸 가르지
//   않았던 것이다. 이제 한 줄에 종류·메시지·위치·스택을 담는다(서버는 문자열 목록으로 받는다).
// SEC-1: 진단에 싣는 주소·문장은 kgp-scrub.js로 비밀을 지운다(주소는 경로까지만). 미로드면 쿼리만 잘라 낸다.
function _kgpSafeUrl(u) {
  try { if (typeof kgpScrubUrl === "function") return kgpScrubUrl(u); } catch (e) { /* noop */ }
  // 폴백도 kgp-scrub.js와 같은 규칙 — 경로 + 상품 id 계열 키만(어느 상품이었는지는 남긴다).
  const s = String(u || "").split("#")[0], q = s.indexOf("?");
  if (q < 0) return s;
  const keep = s.slice(q + 1).split("&").filter((p) => /^(id|itemid|item_id|goods_id|offerid|asin)=/i.test(p));
  return s.slice(0, q) + (keep.length ? "?" + keep.join("&") : "");
}
function _kgpSafeLine(s) {
  try { if (typeof kgpScrubLine === "function") return kgpScrubLine(s); } catch (e) { /* noop */ }
  return String(s || "").replace(/(https?:\/\/[^\s?#"'<>]+)[?#][^\s"'<>]*/g, "$1");
}
function _kgpSafeHtml(h) {
  try { if (typeof kgpScrubText === "function") return kgpScrubText(h); } catch (e) { /* noop */ }
  return h;
}
function _kgpErrLine(ev) {
  try {
    const t = ev && ev.target;
    if (t && t !== window && t.tagName) {
      return "resource: <" + String(t.tagName).toLowerCase() + "> " + _kgpSafeUrl(t.currentSrc || t.src || t.href || "(주소 없음)").slice(0, 200);
    }
    const er = ev && (ev.error || ev.reason);
    let msg = String((ev && ev.message) || (er && er.message) || (typeof er === "string" ? er : "") || "").trim();
    if (!msg) msg = "(메시지 없음 — 교차 출처 스크립트는 브라우저가 내용을 가린다)";
    const kind = (ev && ev.type === "unhandledrejection") ? "rejection" : "script";
    const at = (ev && ev.filename) ? " @ " + _kgpSafeUrl(ev.filename).slice(0, 160) + ":" + (ev.lineno || 0) + ":" + (ev.colno || 0) : "";
    const stack = (er && er.stack) ? " | stack: " + String(er.stack).replace(/\s+/g, " ").slice(0, 300) : "";
    return _kgpSafeLine(kind + ": " + msg.slice(0, 200) + at + stack);
  } catch (e) { return "unknown: " + String(e).slice(0, 100); }
}
try {
  const _kgpOnErr = (ev) => { if (_KGP_PAGE_ERRORS.length < 5) _KGP_PAGE_ERRORS.push(_kgpErrLine(ev)); };
  window.addEventListener("error", _kgpOnErr, true);
  window.addEventListener("unhandledrejection", _kgpOnErr, true);
} catch (e) { /* noop */ }

//: 타오바오·티몰 셀렉터 — **이 레포에 이미 있던 것만**(새로 지어낸 것 0): 갤러리·상세·옵션은
//:   이 파일 `_kgpSitePdp` 타오바오 갈래, 제목은 `kgp-extractor.js` `_adapterTitle` 타오바오 줄.
//:   추출에 쓰지 않는다 — 「이 페이지에 그 자리가 있었나」를 세는 데만 쓴다.
const _KGP_TB_SELECTORS_DEFAULT = {
  gallery: "#J_UlThumb img, .tb-thumb img, [class*='thumbnail'] img, [class*='PicGallery'] img, [class*='mainPic'] img, [class*='MainPic'] img, [class*='preview'] img",
  detail: "#description img, #J_DivItemDesc img, [class*='desc'] img, [class*='Detail'] img",
  options: "#J_isku .tb-prop, [class*='SkuContent'] [class*='valueItemWrapper'], [class*='skuItem']",
  title: "[class*='mainTitle'], [class*='ItemTitle'], h1",
};
// F50: 진단 셀렉터도 규칙에서(키마다 폴백). 규칙 캐시가 늦게 와도 읽는 시점 값을 쓴다.
const _KGP_TB_SELECTORS = new Proxy(_KGP_TB_SELECTORS_DEFAULT, {
  get: function (t, k) { return (typeof k === "string" && k in t) ? _kgpRule("diag_selectors.taobao." + k, t[k]) : t[k]; },
});

// F49-T 5부-c(오너 캡처 2026-09-28 · `kQuotaBytesPerItem`): 확장 저장소 쓰기는 **전부 local**이다
//   (sync는 옵션 화면의 서버 주소·토큰 두 값뿐 — 계약이 지킨다). local엔 항목당 한도가 없지만, 쓰기 실패를
//   `lastError`로 잡지 않으면 콘솔에 「Unchecked」로만 뜨고 진단엔 남지 않는다 → 잡아서 진단에 싣는다.
const KGP_STORAGE_ERR = { count: 0, last: null };
function kgpStoreLocal(obj) {
  try {
    if (!(chrome && chrome.storage && chrome.storage.local)) return;
    chrome.storage.local.set(obj, () => {
      const err = chrome.runtime && chrome.runtime.lastError;
      if (!err) return;
      KGP_STORAGE_ERR.count += 1;
      KGP_STORAGE_ERR.last = { keys: Object.keys(obj || {}).join(",").slice(0, 80),
                               msg: String(err.message || err).slice(0, 160), at: new Date().toISOString() };
      try { console.warn("[고가수집기] 저장 실패:", KGP_STORAGE_ERR.last.keys, KGP_STORAGE_ERR.last.msg); } catch (e) {}
    });
  } catch (e) { /* noop */ }
}
function kgpPageDiag() {
  const out = { at: new Date().toISOString(), url: _kgpSafeUrl(location.href), wall: "", nav: {}, lazy: {}, sel: {}, errors: [] };
  try { out.wall = _kgpDetectWall(); } catch (e) { /* noop */ }
  try {
    const nav = (performance.getEntriesByType && performance.getEntriesByType("navigation") || [])[0];
    if (nav) {
      out.nav = {
        // responseStatus는 크롬 109+에만 있다 — 없으면 **비워 둔다**(200이라 지어내지 않는다).
        status: (typeof nav.responseStatus === "number") ? nav.responseStatus : null,
        redirects: nav.redirectCount || 0,
        type: nav.type || "",
        requested: _kgpSafeUrl(nav.name || "").slice(0, 300),
      };
    }
  } catch (e) { /* noop */ }
  try {
    let pending = 0, total = 0;
    document.querySelectorAll("img").forEach((im) => {
      const lazy = im.getAttribute("data-src") || im.getAttribute("data-ks-lazyload") || im.getAttribute("data-lazy");
      if (!lazy) return;
      total += 1;
      const cur = im.currentSrc || im.getAttribute("src") || "";
      if (!cur || /^data:|blank|spacer|placeholder|1x1/i.test(cur) || !im.naturalWidth) pending += 1;
    });
    out.lazy = { total, pending };
  } catch (e) { /* noop */ }
  try {
    const host = (location.hostname || "").toLowerCase();
    if (/(^|\.)(taobao|tmall)\.com$/.test(host)) {
      Object.keys(_KGP_TB_SELECTORS).forEach((k) => {
        try { out.sel[k] = document.querySelectorAll(_KGP_TB_SELECTORS[k]).length; } catch (e) { out.sel[k] = -1; }
      });
    }
  } catch (e) { /* noop */ }
  out.errors = _KGP_PAGE_ERRORS.slice(0, 5).map(_kgpSafeLine);
  // F49-T 4부: 목록 감시 상태 — 「이 페이지 수집이 이상해요」가 **스크롤 뒤** 상태를 담는다.
  try {
    if (typeof KGP_WATCH === "object" && KGP_WATCH.scan_count) {
      out.watch = Object.assign({}, KGP_WATCH, { cards_tiled: document.querySelectorAll(".kgp-card-quick").length });
    }
  } catch (e) { /* noop */ }
  if (KGP_STORAGE_ERR.count) out.storage_err = { count: KGP_STORAGE_ERR.count, last: KGP_STORAGE_ERR.last };
  out.rules = (typeof _kgpRulesInfo === "function") ? _kgpRulesInfo()   // F50: 어느 규칙 버전으로 읽었나(remote/bundled)
    : { version: "", hash: "", source: "none" };
  return out;
}

function extractProductMeta() {
  // F49-T: 어느 갈래로 뽑든 **페이지 진단**을 붙인다(추출 결과는 그대로).
  const meta = _extractProductMetaInner();
  try {
    if (meta && typeof meta === "object") {
      meta.page_diag = kgpPageDiag();
      // F49-T 2부-b: ICE가 있는데 못 읽었으면 그 덩어리 앞 200자(+사유)를 진단에 싣는다.
      if (meta.ice_error) meta.page_diag.ice_error = String(meta.ice_error).slice(0, 300);
    }
  } catch (e) { /* noop */ }
  return meta;
}

function _extractProductMetaInner() {
  // 공유 추출기(kgp-extractor.js) 우선 — 확장·북마클릿 동일 코드(JSON우선·DOM폴백·부분수집·가격 sanity).
  //   manifest가 이 스크립트보다 먼저 로드. 만약 미로드면 아래 레거시 DOM 폴백으로 정직 동작.
  if (typeof window.kgpExtractProduct === "function") {
    // v86-H: 권위 판정(카드 수까지 반영)을 추출기에 넘겨 목록 갈래 억제를 켠다 — 추출기 자체 판정은 폴백.
    try { return window.kgpExtractProduct({ pageType: kgpPageType() }); } catch (e) { try { console.error("[고가수집기] 공유 추출기 오류, 레거시 폴백:", e); } catch (_) {} }
  }
  const getMeta = (prop) => {
    const el = document.querySelector(
      `meta[property="${prop}"], meta[name="${prop}"]`
    );
    return el ? el.getAttribute("content") || "" : "";
  };

  // JSON-LD 추출
  const jsonldScripts = [...document.querySelectorAll('script[type="application/ld+json"]')]
    .map(s => {
      try {
        return JSON.parse(s.innerText || s.textContent || "");
      } catch {
        return null;
      }
    })
    .filter(Boolean);

  // 이미지: og:image 우선 + 페이지의 모든 상품 이미지(로고/배너/아이콘/작은 이미지 제외)
  const ogImage = getMeta("og:image") || getMeta("og:image:url") || "";
  // v11 P0: 무관 이미지(플래그·태그·픽셀·문서아이콘·화살표 등) 제외 — 서버 블랙리스트와 동일.
  const _isProductImg = (s) =>
    s && s.indexOf("data:") !== 0 &&
    !/(logo|sprite|icon|favicon|avatar|placeholder|loading|blank|pixel|spinner|banner|badge|button|arrow|chevron|caret|rating|star_|flags?|emoji|openingemail|supplier-public-tag|public-tag|\.slim\.|tracking|beacon|watermark|qr[-_]?code|coupon|nav_|\/pdf|pdf[-_]|\.pdf|\.doc|doc[-_]icon|\/doc\/|1x1|transparent\.|spacer)/i.test(s);
  const images = [];
  const _seenImg = new Set();
  const _pushImg = (s) => { if (_isProductImg(s) && !_seenImg.has(s)) { _seenImg.add(s); images.push(s); } };
  // v16 P0: 추천/연관/함께 본/스폰서/푸터 등 '다른 상품' 영역의 이미지는 제외(PDD 스코프, 혼입 방지).
  const _kgpNonProductRe = /(recommend|related|similar|also[-_ ]?(bought|viewed|like)|you[-_ ]?may|frequently[-_ ]?bought|sponsored|advert|promotion|ranking|best[-_ ]?seller|recently[-_ ]?viewed|carousel|slider|cross[-_ ]?sell|up[-_ ]?sell|comparison|footer|navbar|breadcrumb|other[-_ ]?products|popular|trending|review|comment|reply|qna|feedback|testimonial)/i;
  const _kgpInNonProductRegion = (el) => {
    let cur = el && el.parentElement, depth = 0;
    while (cur && depth < 8) {
      const tok = (cur.className && cur.className.baseVal !== undefined ? cur.className.baseVal : (cur.className || "")) + " " + (cur.id || "");
      if (tok && _kgpNonProductRe.test(tok)) return true;
      cur = cur.parentElement; depth++;
    }
    return false;
  };
  // v43-3: 판매자/브랜드 로고는 상품 이미지 아님 — src뿐 아니라 alt/class/조상영역으로도 배제('ALL IN HOME' 등).
  const _kgpSellerLogoRe = /(logo|brand|seller|merchant|store[-_ ]?(logo|name)|shop[-_ ]?(logo|name)|mall[-_ ]?name|판매자|브랜드관)/i;
  const _kgpIsSellerLogo = (im) => {
    try {
      const cls = (im.className && im.className.baseVal !== undefined ? im.className.baseVal : (im.className || ""));
      if (_kgpSellerLogoRe.test((im.getAttribute("alt") || "") + " " + cls + " " + (im.id || ""))) return true;
      let cur = im.parentElement, depth = 0;
      while (cur && depth < 5) {   // 판매자 정보 영역 안이면 로고로 간주
        const tok = (cur.className && cur.className.baseVal !== undefined ? cur.className.baseVal : (cur.className || "")) + " " + (cur.id || "");
        if (/(seller|merchant|store[-_ ]?info|shop[-_ ]?info|vendor|brand[-_ ]?header)/i.test(tok)) return true;
        cur = cur.parentElement; depth++;
      }
    } catch (e) { /* noop */ }
    return false;
  };
  // v43-3: PDP 갤러리(대표) ↔ 상세 본문 이미지 2버킷 스코프.
  const _KGP_GALLERY_SEL = '[class*="gallery" i],[class*="product-image" i],[class*="productImage" i],[class*="main-image" i],[class*="mainImage" i],[id*="imgTagWrapper" i],#imageBlock,[data-testid*="gallery" i]';
  const _KGP_DETAIL_SEL = '#productDescription,#feature-bullets,[class*="product-detail" i],[class*="description" i],[id*="description" i]';
  const _kgpInside = (im, sel) => { try { return !!(im.closest && im.closest(sel)); } catch (e) { return false; } };
  const gallery = [], detail = [];
  if (ogImage) { _pushImg(ogImage); gallery.push(ogImage); }
  // v44: 사이트별 PDP 추출을 최우선(아마존 고해상·A+·불릿 / Temu 캐러셀·상세) — 갤러리 대표는 여기서.
  const _site = _kgpSitePdp();
  _site.gallery.forEach((u) => { if (_isProductImg(u)) { _pushImg(u); if (gallery.indexOf(u) < 0) gallery.push(u); } });
  _site.detail.forEach((u) => { if (_isProductImg(u)) { _pushImg(u); if (detail.indexOf(u) < 0) detail.push(u); } });
  try {
    document.querySelectorAll("img").forEach((im) => {
      let src = im.currentSrc || im.src || im.getAttribute("data-src") || im.getAttribute("data-original") || "";
      if (!src && im.getAttribute("srcset")) {
        const parts = im.getAttribute("srcset").split(",");
        src = (parts[parts.length - 1] || "").trim().split(" ")[0];
      }
      const w = im.naturalWidth || im.width || 0;
      const h = im.naturalHeight || im.height || 0;
      if (!src || w < 250 || h < 250) return;
      if (_kgpInNonProductRegion(im) || _kgpIsSellerLogo(im) || !_isProductImg(src)) return;  // 추천·판매자로고·무관 제외
      _pushImg(src);
      if (_kgpInside(im, _KGP_DETAIL_SEL)) { if (detail.indexOf(src) < 0) detail.push(src); }
      else if (_kgpInside(im, _KGP_GALLERY_SEL)) { if (gallery.indexOf(src) < 0) gallery.push(src); }
    });
  } catch (e) { /* noop */ }

  // v42 1-1: 클릭 시점 렌더된 DOM의 '현재가'를 최우선으로 읽는다.
  //   SPA(Temu 등)의 og:price는 스테일하거나 USD 오값이 흔함 → 화면에 렌더된 판매가가 진실.
  //   순서: ①스코프 DOM 현재가(취소선·추천/리뷰 제외) → ②og:price 메타 → ③본문 텍스트 휴리스틱.
  //   통화 못 얻으면 빈 값(기본값 USD 금지) → 서버가 '가격 확인 필요' 정직 처리.
  let heuristicPrice = "";
  let heuristicCurrency = "";
  const _scoped = _kgpScopedPrice();
  if (_scoped.price) {
    heuristicPrice = _scoped.price;
    heuristicCurrency = _scoped.currency || "";
  }
  if (!heuristicPrice) {
    const metaAmt = getMeta("product:price:amount");
    if (metaAmt) {
      heuristicPrice = String(metaAmt).replace(/[^\d.,]/g, "").replace(/,/g, "");
      heuristicCurrency = (getMeta("product:price:currency") || "").toUpperCase();
    }
  }
  if (!heuristicPrice) {
    // 본문 텍스트 폴백 — 원/₩/¥/$/€ (Temu KR '61,144원' 포함).
    const bodyText = document.body ? document.body.innerText.slice(0, 4000) : "";
    const _bp = _kgpParsePrice(bodyText);
    if (_bp) { heuristicPrice = _bp.price; heuristicCurrency = _bp.currency || ""; }
  }

  // 봇 차단(403) 사이트도 수집되도록 페이지 HTML을 함께 전송 → 서버가 파싱(가격/이미지/옵션 보강).
  // 대용량 방지를 위해 상한(600KB)으로 자른다.
  let pageHtml = "";
  try {
    pageHtml = (document.documentElement ? document.documentElement.outerHTML : "").slice(0, 600000);
  } catch (e) {
    pageHtml = "";
  }

  // v16 P0: 사이트 공통 마케팅 필러(상품 설명 아님)는 보내지 않는다 — 서버 필러 가드와 동일 취지.
  const _kgpFiller = /(절약을\s*시작|쇼핑하여\s*절약|에서\s*쇼핑하여|최저가로\s*쇼핑|지금\s*쇼핑하세요|여기를\s*눌러|링크를\s*확인하세요|smarter\s+shopping|start\s+saving|save\s+big|free\s+shipping\s+on\s+(all\s+)?orders)/i;
  // 실제 상품 설명 우선: 설명 섹션 요소 텍스트 → 없으면 필러 아닌 og:description.
  function _kgpRealDescription() {
    // v44: 사이트별 상세(아마존 불릿+상세, Temu 본문)를 최우선 — 필러 아니면 그대로.
    if (_site && _site.description && _site.description.length >= 20 && !_kgpFiller.test(_site.description)) {
      return _site.description.slice(0, 4000);
    }
    const sel = ["#productDescription", "#feature-bullets", "#description",
      ".product-description", "[class*='product-detail']", "[class*='description']",
      "[id*='description']"];
    for (const s of sel) {
      try {
        const el = document.querySelector(s);
        const txt = el && (el.innerText || el.textContent || "").trim();
        if (txt && txt.length >= 30 && !_kgpFiller.test(txt)) return txt.slice(0, 4000);
      } catch (e) { /* noop */ }
    }
    const og = getMeta("og:description") || getMeta("description") || "";
    return _kgpFiller.test(og) ? "" : og;
  }

  return {
    url: location.href,
    title: getMeta("og:title") || document.title || "",
    image: (gallery[0] || images[0] || ogImage),   // v43-3: 대표=갤러리 첫 장(로고 배제)
    images: images,
    gallery_images: gallery,               // v43-3: 갤러리(대표) / 상세 2버킷 — 서버가 스코프 반영
    detail_images: detail,
    // C-F13-2a: 사이트 전용 추출(타오바오 颜色分类 등)이 옵션을 찾았으면 그쪽이 정확하다.
    options: ((_site.options && _site.options.length) ? _site.options : _kgpCollectOptions()),
    price: heuristicPrice,                 // v42 1-1: 렌더 DOM 현재가 우선(위에서 scoped→meta→본문 순 해결)
    currency: (_site.currency || heuristicCurrency),   // 기본값 USD 금지 — 못 얻으면 빈 값
    // 타오바오는 가격이 둘이다(优惠前/补贴后). **둘 다 따로** 올린다 — 서버가 섞지 않고 담는다.
    price_list: (_site.price_list || ""),
    price_final: (_site.price_final || ""),
    // 로그인 벽·확인 절차를 **만났다는 사실**만 올린다. 뚫지 않는다(우회 금지).
    wall: _kgpDetectWall(),
    description: _kgpRealDescription(),
    brand: getMeta("og:brand") || "",
    jsonld: jsonldScripts,
    html: pageHtml,
    ext_version: (function () { try { return chrome.runtime.getManifest().version; } catch (e) { return ""; } })(),  // P0 진단·하위호환
    collected_at: new Date().toISOString()
  };
}

// 백그라운드 서비스 워커 메시지 리스너
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "extractMeta") {
    // v82 STEP3: 페이지타입 게이트(방어선) — single이 아니면 단일 추출 결과를 내지 않는다(저장 불가).
    //   팝업이 선차단하지만, executeScript 우회·미래 호출자 대비 content_script에서도 봉인.
    let _pt = "unknown";
    try { _pt = kgpPageType(); } catch (e) {}
    const _allowed = (typeof KGPDetect !== "undefined" && KGPDetect.singleExtractAllowed)
      ? KGPDetect.singleExtractAllowed(_pt) : (_pt === "single");
    if (!_allowed) { sendResponse({ gated: true, pageType: _pt }); return true; }
    sendResponse(extractProductMeta());
    return true;
  }
  // v86-L2: 팝업 [수집]도 in-page 정본 경로로 강제한다. 종전 팝업(popup.js)은 executeScript(og/jsonld를
  //   ISOLATED로 읽음) + extractMeta 폴백으로 전송해 **MAIN 월드 tier1(테무 네트워크 캡처)을 아예 안 읽고**,
  //   echo도 안 남겼다 → 네트워크 전달 테무에서 title만 전송(서버 1/5) + payload_echo=null(오너 실기기 결함).
  //   이 핸들러가 팝업 전송을 FAB와 **같은 코드**(kgpAcquireMeta=클릭 시점 재독출+tier1 병합/대기, _kgpRecordEcho)
  //   로 통과시킨다. path="popup". extractMeta 봉인과 동일하게 single 게이트도 방어선으로 둔다(우회 대비).
  if (msg.action === "kgpCollectNow") {
    let _pt2 = "unknown";
    try { _pt2 = kgpPageType(); } catch (e) {}
    const _ok2 = (typeof KGPDetect !== "undefined" && KGPDetect.singleExtractAllowed)
      ? KGPDetect.singleExtractAllowed(_pt2) : (_pt2 === "single");
    if (!_ok2) { sendResponse({ ok: false, gated: true, pageType: _pt2 }); return true; }
    kgpAcquireMeta(function (meta) {
      meta = meta || {};
      meta.corr_id = kgpNewCorr();
      if (msg.force) meta.force = true;
      _kgpRecordEcho(meta, "popup");
      kgpSendMessage({ action: "collect", meta }, function (resp) {
        resp = resp || { ok: false, error: "no-response" };
        _kgpEchoServer(resp);
        // 팝업 UI가 성공 문구에 쓸 제목/URL 동봉(팝업은 meta를 직접 안 만든다).
        try { resp.collected_title = meta.title || ""; resp.collected_url = meta.url || location.href; } catch (e) {}
        try { sendResponse(resp); } catch (e) {}
      });
    });
    return true;   // 비동기 응답
  }
  // v65 STEP1: 렌더 완료 대기 후 추출(정본 경로) — 보강 큐가 백그라운드 탭에서 사용.
  //   가격+메인이미지 로드 감지(최대 8초) → 접힘 상세 펼침 → 렌더된 DOM 추출. 부분이면 partial 표기.
  if (msg.action === "extractMetaWait") {
    // v67 STEP2: 렌더 보장 — 자동 스크롤(상→하 lazy 트리거) → 인터스티셜(앱유도·지역게이트) 닫기 시도 →
    //   가격+갤러리 셀렉터 충족 대기(최대 12초). 타임아웃 시 어느 조건 미충족인지 로그(가격/이미지).
    const _extract = () => {
      const interstitial = (typeof _kgpDismissInterstitial === "function") ? _kgpDismissInterstitial() : false;
      const _wait = (typeof window.kgpWaitRendered === "function") ? window.kgpWaitRendered : (cb) => cb({ partial: false });
      _wait((res) => {
        const _finish = () => {
          let meta = {};
          try { meta = extractProductMeta() || {}; } catch (e) { meta = {}; }
          meta.partial = !!(res && res.partial);
          meta.interstitial = !!interstitial;
          if (res && res.partial) {   // 타임아웃 원인 로그(가격 노드 미출현/이미지 0장 + 탭 hidden 여부)
            try {
              const rr = (typeof window._kgpRenderReady === "function") ? window._kgpRenderReady() : {};
              console.log("[고가수집기 보강] 렌더 타임아웃 — priceOk=" + rr.priceOk + " imgOk=" + rr.imgOk + " hidden=" + document.hidden + " interstitial=" + interstitial);
            } catch (e) {}
          }
          sendResponse(meta);
        };
        try { if (typeof window.kgpRevealDetailFolds === "function") window.kgpRevealDetailFolds(_finish); else _finish(); }
        catch (e) { _finish(); }
      }, 12000);
    };
    if (typeof _kgpAutoScroll === "function") _kgpAutoScroll(_extract); else _extract();
    return true;   // 비동기 응답
  }
  // v42 E-5: 벌크 수집 진행률 실시간 갱신(background가 1건마다 전송).
  if (msg.action === "bulkProgress") {
    kgpSetStatus(`수집 중… (${msg.done}/${msg.total})`);
    return false;
  }
  // v63 STEP1: 감지 디버그 패널 — 팝업이 조회. 지금 이 페이지의 실측 상태를 반환('왜 안 떠?'를 캡처 한 장으로).
  if (msg.action === "kgpDetectState") {
    let pt = "unknown", allowed = false, cards = 0, btn = "none";
    try { allowed = kgpHostAllowed() || kgpEntrySession(); } catch (e) {}
    try { pt = kgpPageType(); } catch (e) {}
    try { kgpFindCards(); cards = _kgpLastDetect.merged; } catch (e) {}
    try {
      if (document.getElementById(KGP_TOOLBAR_ID)) btn = "bulkbar";
      else if (document.getElementById(KGP_REOPEN_ID)) btn = "reopen";
      else if (document.getElementById(KGP_BTN_ID)) btn = "fab";
    } catch (e) {}
    sendResponse({
      ok: true, host: (location.hostname || ""), allowed: allowed, pageType: pt,
      cards: cards, generic: _kgpLastDetect.generic, adapter: _kgpLastDetect.adapter,
      adapterMatched: _kgpLastDetect.adapterMatched, scanned: _kgpScannedCount || 0, button: btn,
      excl: _kgpExcl, skipStats: _kgpSkipStats,   // v65/v77: 제외 사유 분해 + 타일 스킵 사유별 카운트
      // v84 STEP1: 스타일 주입·FAB 실측 위치(팝업 감지 진단에서 즉시 확인).
      styleInjected: !!document.getElementById("kgp-style"),
      fabPosition: (function () { try { var f = document.getElementById(KGP_BTN_ID); return f ? getComputedStyle(f).position : ""; } catch (e) { return ""; } })(),
    });
    return true;
  }
  // v70 STEP5: 진단 스냅샷 저장 — 현재 렌더된 페이지 DOM(outerHTML)을 반환. 팝업이 파일로 내려받아
  //   실페이지 하네스 픽스처로 커밋(오너 1회). 서버측 직접 크롤 없이 렌더된 DOM 그대로.
  if (msg.action === "kgpSnapshot") {
    let html = "";
    try { html = _kgpSafeHtml("<!doctype html>\n" + document.documentElement.outerHTML); } catch (e) { html = ""; }
    sendResponse({ ok: !!html, html: html, host: (location.hostname || ""), url: (location.href || ""), title: (document.title || "") });
    return true;
  }
  // v75 STEP3: '이 페이지 수집이 이상해요' — 스냅샷 HTML + 추출 결과 + 감지 로그를 하나로 묶어 반환.
  //   오너/유저가 파일 하나만 전달하면 하네스가 그대로 재현(HTML=픽스처, extracted=실제 추출 결과 대조).
  if (msg.action === "kgpDiagBundle") {
    let html = "", extracted = null, detection = null, extVer = "";
    try { html = _kgpSafeHtml("<!doctype html>\n" + document.documentElement.outerHTML); } catch (e) { html = ""; }
    // v86-I: 진단 export와 수집 payload는 **같은 권위 스토어**를 읽는다(별도 스냅샷 경로 금지).
    //   아래 kgpAcquireMeta 콜백에서 extracted가 채워진다 — 여기서 따로 추출하지 않는다.
    try {
      kgpFindCards();
      detection = { pageType: (typeof kgpPageType === "function" ? kgpPageType() : ""),
        generic: _kgpLastDetect.generic, adapter: _kgpLastDetect.adapter, merged: _kgpLastDetect.merged,
        adapterMatched: _kgpLastDetect.adapterMatched, scanned: _kgpScannedCount || 0,
        bar: !!document.getElementById(KGP_TOOLBAR_ID), fab: !!document.getElementById(KGP_BTN_ID),
        excl: _kgpExcl, skipStats: _kgpSkipStats };   // v77 STEP2: 미부착 타일 사유별 집계
    } catch (e) { detection = { __err: String(e) }; }
    try { extVer = chrome.runtime.getManifest().version; } catch (e) {}
    // v83.1 STEP2: 빌드 각인(커밋 해시) — ext_version과 별개로 **어느 빌드인지** 커밋 단위 즉판용.
    //   background가 ZIP에 심어진 build-info.json을 읽어 준다. 개발 설치면 commit=""·source="unpacked-dev"(정직).
    kgpAcquireMeta(function (_authMeta) {
      extracted = _authMeta;
      try {
        // v86-I 계측 동봉(읽기 전용): tier1 카운터를 진단 본문에서 바로 읽는다.
        var _t1 = (_authMeta && _authMeta.tier1_diag) || {};
        if (detection && !detection.__err) detection.tier1 = {
          seen: _t1.tier1_seen || 0, hits: _t1.tier1_hits || 0,
          goods_ids_n: _t1.goods_ids_n || 0, pending: !!_authMeta.tier1_pending,
          reads: (_kgpMetaStore && _kgpMetaStore.tries) || 0 };
      } catch (e) {}
    kgpSendMessage({ action: "kgpBuildInfo" }, (bi) => {
      // v84 STEP1: 채점 즉판 필드 — 스타일 주입 여부 + FAB **computed** 위치 실측 + 번역 DOM 플래그.
      //   "값은 맞는데 화면엔 없음"을 진단 파일 하나로 판정하기 위한 최소 사실들(추측 제거).
      var _ui = { style_injected: false, fab_exists: false, fab_position: "", fab_z: "", fab_parent: "",
                  bar_exists: false, pinned: false,
                  // v86 STEP3: 타일 2종·툴바 실측. 스냅샷 HTML은 shadow 안을 담지 못하므로,
                  //   '라이트 DOM에 .kgp-card-quick이 보인다'만으로는 shadow 여부를 알 수 없다.
                  //   in_shadow(=호스트에 shadowRoot가 붙었는지)를 여기서 직접 재서 그 착시를 끝낸다.
                  tile_quick_n: 0, tile_chk_n: 0, tile_first: null, toolbar_first: null };
      try {
        _ui.style_injected = !!document.getElementById("kgp-style");
        var _f = document.getElementById(KGP_BTN_ID);
        _ui.fab_exists = !!_f;
        _ui.bar_exists = !!document.getElementById(KGP_TOOLBAR_ID);
        if (_f) {
          var _cs = null; try { _cs = getComputedStyle(_f); } catch (e) {}
          _ui.fab_position = _cs ? _cs.position : "";        // 'static'이면 화면에서 사라진 상태(오너 증상)
          _ui.fab_z = _cs ? _cs.zIndex : "";
          _ui.fab_parent = (_f.parentElement && _f.parentElement.tagName) || "";
          // 인라인에 !important로 박혔는지(= _kgpPinFixed 발현 여부) — 로드된 빌드에 핀이 있는지 즉판.
          try { _ui.pinned = _f.style.getPropertyPriority("position") === "important"; } catch (e) {}
        }
        // 타일 계측: 개수 + 첫 타일의 **보이는 요소**(shadow면 알약 .p, 폴백이면 호스트) 실측.
        var _qs = document.querySelectorAll(".kgp-card-quick");
        var _ks = document.querySelectorAll(".kgp-card-chk");
        _ui.tile_quick_n = _qs.length;
        _ui.tile_chk_n = _ks.length;
        if (_qs.length) _ui.tile_first = _kgpMeasureVisible(_qs[0], ".p");
        // v86 STEP4.1: **계측 사각 3호** — "호버하면 켜지는가"를 실기기에서 판정할 방법이 없었다.
        //   첫 카드에 synthetic mouseenter를 쏘고 전이(.12s) 여유를 둔 뒤 다시 재서 {before, after}로 남긴다.
        //   리스너가 안 붙었거나 죽었으면 after가 before와 같게 나와 **즉시 드러난다**(추측 불필요).
        // v86-D: 첫 타일만 재면 "첫 타일은 되는데 나머지는?"을 못 본다 → 첫·중간·마지막 3표본.
        if (_qs.length) {
          // v86-G: 사이트별 rest 판정을 **전수 집계**로 남긴다. 표본 3개는 어느 게 수집됨 타일인지에 따라
          //   사이트 전체 결론이 뒤집힌다(아마존 홈에서 첫 타일이 '수집됨 ✓'이면 rest=1이 정상인데 위반처럼 읽힌다).
          //   rest_violations = 수집 안 된 타일인데 rest에서 보이는 수 → 이 값만 0이면 호버 은닉 계약 충족.
          //   ★반드시 호버 프로브 **이전에** 잰다 — 프로브가 synthetic mouseenter로 opacity를 1로 올린다.
          try {
            var _rv = 0, _rc = 0;
            for (var _r = 0; _r < _qs.length; _r++) {
              var _q = _qs[_r];
              if (_q.dataset && _q.dataset.collected === "1") { _rc++; continue; }
              // F49-T 3부: rest가 0이 아닌 사이트(타오바오 계열)는 **그 값보다 진할 때만** 위반이다.
              if (parseFloat(getComputedStyle(_q).opacity || "0") > _kgpQuickRestOpacity() + 0.01) _rv++;
            }
            _ui.rest_state = { n: _qs.length, collected: _rc, rest_violations: _rv, rest_opacity: _kgpQuickRestOpacity() };
          } catch (e) {}
          _ui.hover_test = _kgpHoverProbe(_qs[0]);            // 하위호환(기존 판독 스크립트 유지)
          var _idx = [0, Math.floor(_qs.length / 2), _qs.length - 1];
          var _seen = {}, _samples = [];
          for (var _i = 0; _i < _idx.length; _i++) {
            var _n = _idx[_i];
            if (_seen[_n]) continue;
            _seen[_n] = 1;
            _samples.push({ i: _n, probe: _kgpHoverProbe(_qs[_n]) });
          }
          _ui.hover_test_samples = _samples;
        }
        // v86-D: **커버리지** — merged 대비 실제 부착률과 미부착 사유별 수.
        //   종전 계측은 tile_quick_n(절대 수)만 줘서 "68 스캔에 35개면 나머지 33은 왜?"를 못 읽었다.
        //   부착률과 사유를 같이 남겨야 회귀인지 정상 제외인지 로그 한 줄로 갈린다.
        try {
          var _cards = (typeof kgpFindCards === "function") ? kgpFindCards() : [];
          var _att = 0, _miss = 0, _missBy = {};
          for (var _c = 0; _c < _cards.length; _c++) {
            var _el = _cards[_c] && _cards[_c].el;
            if (_el && _el.querySelector && _el.querySelector(".kgp-card-quick")) { _att++; continue; }
            _miss++;
            var _r = (_el && _el.getAttribute && _el.getAttribute("data-kgp-skip")) || "(표식없음)";
            _missBy[_r] = (_missBy[_r] || 0) + 1;
          }
          _ui.tile_coverage = {
            merged: _cards.length,
            attached: _att,
            missing: _miss,
            rate: _cards.length ? Math.round((_att / _cards.length) * 1000) / 10 : null,   // %
            missing_by: _missBy,
            scanned: _kgpScannedCount,
            sponsored: _cards.filter(function (c) { return c && c.sponsored; }).length,
            dup_instances: _cards.filter(function (c) { return c && c.dup_instance; }).length,
          };
        } catch (e) { _ui.tile_coverage = { error: String((e && e.message) || e) }; }
        var _bar = document.getElementById(KGP_TOOLBAR_ID);
        if (_bar) _ui.toolbar_first = _kgpMeasureVisible(_bar, ".bar");
        // v86-I 계측 동봉(읽기 전용·로직 변경 0): 벌크바가 **접힘**이라 없는 것인지,
        //   아예 안 붙은 것인지 스냅샷만으로 가른다. bar_exists=false의 두 원인을 분리하는 유일한 근거.
        _ui.bar_collapsed = !!_kgpClosed;
        try { _ui.bar_auto = kgpLSget("kgp_bar_auto", "1") !== "0"; } catch (e) { _ui.bar_auto = null; }
      } catch (e) {}
      sendResponse({ ok: !!html, html: html, host: (location.hostname || ""), url: (location.href || ""),
        title: (document.title || ""), extracted: extracted, detection: detection, ext_version: extVer,
        build: bi || { commit: "", source: "unknown" },
        git_commit: (bi && bi.commit) || "",
        style_injected: _ui.style_injected,
        translated_dom: !!(extracted && extracted.translated_dom),
        ui: _ui,
        // v86-I: 마지막 **전송** payload 요약(읽기 전용) — 추출 결과(extracted)와 나란히 놓고
        //   "추출은 됐는데 전송이 빔" 갈래를 진단 파일 하나로 판독한다.
        payload_echo: (_kgpMetaStore && _kgpMetaStore.echo) || null,
        collected_at: new Date().toISOString() });
    });
    });
    return true;
  }
  return false;
});

// v67 STEP2: 자동 스크롤(상→하)로 lazy 이미지·가격 트리거 후 원위치 → cb. 최대 4초.
function _kgpAutoScroll(cb) {
  let done = false;
  const fin = () => { if (done) return; done = true; try { window.scrollTo(0, 0); } catch (e) {} setTimeout(cb, 150); };
  try {
    const h = Math.max(document.body ? document.body.scrollHeight : 0, document.documentElement ? document.documentElement.scrollHeight : 0);
    const step = Math.max(400, Math.floor((window.innerHeight || 600) * 0.85));
    let y = 0;
    const iv = setInterval(() => {
      y += step; try { window.scrollTo(0, y); } catch (e) {}
      if (y >= h) { clearInterval(iv); fin(); }
    }, 140);
    setTimeout(() => { try { clearInterval(iv); } catch (e) {} fin(); }, 4000);
  } catch (e) { fin(); }
}
// v67 STEP2: 인터스티셜(앱 유도·지역 게이트·큰 모달) 감지 → 닫기 시도. 닫아도 남으면 true(보강 불가 신호).
function _kgpDismissInterstitial() {
  let blocked = false;
  try {
    const vw = (window.innerWidth || 1), vh = (window.innerHeight || 1), area = vw * vh;
    const ov = document.querySelectorAll('[class*="modal" i],[class*="popup" i],[class*="overlay" i],[class*="interstitial" i],[class*="app-download" i],[class*="app-banner" i],[class*="region" i],[class*="gate" i],[role="dialog"]');
    for (let i = 0; i < ov.length && i < 40; i++) {
      const el = ov[i];
      let cs; try { cs = getComputedStyle(el); } catch (e) { continue; }
      if (cs.display === "none" || cs.visibility === "hidden") continue;
      if (cs.position !== "fixed" && cs.position !== "absolute") continue;
      let r; try { r = el.getBoundingClientRect(); } catch (e) { continue; }
      if (r.width * r.height < area * 0.4) continue;    // 뷰포트 40%↑ 덮는 것만
      const close = el.querySelector('[class*="close" i],[aria-label*="close" i],[aria-label*="닫기"],[class*="dismiss" i],button');
      if (close) { try { close.click(); } catch (e) {} }
      try { r = el.getBoundingClientRect(); cs = getComputedStyle(el); } catch (e) {}
      if (cs.display !== "none" && r.width * r.height >= area * 0.4) blocked = true;   // 닫아도 남음
    }
  } catch (e) {}
  return blocked;
}

// v16 P0: MV3 — 확장이 업데이트/재로딩되면 기존 탭의 content script는 chrome.runtime이 끊겨
// (extension context invalidated) sendMessage가 "Cannot read properties of undefined (reading 'sendMessage')"
// 를 던진다. 컨텍스트 유효성(chrome.runtime.id)을 먼저 확인하고, 끊겼으면 raw 에러 대신 새로고침 안내로 정직 처리.
function kgpExtAlive() {
  try { return !!(chrome && chrome.runtime && chrome.runtime.id); } catch (e) { return false; }
}
function kgpSendMessage(msg, cb) {
  if (!kgpExtAlive()) {
    cb && cb({ ok: false, error: "확장이 업데이트되었어요. 페이지를 새로고침(F5)한 뒤 다시 시도하세요.", _invalidated: true });
    return;
  }
  try {
    chrome.runtime.sendMessage(msg, (resp) => {
      const err = (chrome.runtime && chrome.runtime.lastError) ? chrome.runtime.lastError.message : "";
      if (err) { cb && cb({ ok: false, error: err }); return; }
      cb && cb(resp);
    });
  } catch (e) {
    cb && cb({ ok: false, error: (e && e.message) || "확장 연결 실패", _invalidated: true });
  }
}

// ---------------------------------------------------------------------------
// 인페이지 '수집' 버튼 (Phase 202)
// ---------------------------------------------------------------------------

const KGP_BTN_ID = "kgp-collect-fab";

// v86 STEP2: 옛 `_KGP_RESET`(all:initial !important 인라인)은 **폐기**됐다. 사이트 상속 오염 차단이라는
//   목적은 같지만, 인라인 all:initial은 Chrome이 250여 롱핸드로 전개해 배경·크기·색까지 초기화하고
//   인라인 !important라 시트로 복원조차 불가능해 '위치는 맞는데 안 보이는' 유령을 만들었다(v86 STEP1 실측).
//   이제 모든 가시 UI는 Shadow DOM 안에서 그리고, 격리는 shadow 경계가 담당한다.
//   → 가시 UI에 all:initial 인라인 잔존 0. 허용되는 유일한 형태는 shadow 스타일시트의 `:host{all:initial}`.

/** 상품 페이지로 보이는지 휴리스틱 판단. */
function looksLikeProductPage() {
  const getMeta = (p) =>
    document.querySelector(`meta[property="${p}"], meta[name="${p}"]`)?.getAttribute("content") || "";
  if (getMeta("og:type").toLowerCase() === "product") return true;
  if (getMeta("product:price:amount")) return true;
  if (getMeta("og:image") && getMeta("og:title")) return true;
  // JSON-LD Product
  for (const s of document.querySelectorAll('script[type="application/ld+json"]')) {
    try {
      const data = JSON.parse(s.innerText || s.textContent || "");
      const arr = Array.isArray(data) ? data : [data];
      if (arr.some(x => x && String(x["@type"] || "").toLowerCase().includes("product"))) return true;
    } catch { /* noop */ }
  }
  return false;
}

// 알럿 중복 방지(오너): 수집 요청마다 corr-id를 부여하고, 그 corr-id의 완료 알럿은 '건당 1회'만.
//   (콜백 이중 발화·경로 중복 등 어떤 원인이든 같은 건은 한 번만 토스트/축하한다.)
let _kgpCorrSeq = 0;
const _kgpCorrDone = new Set();
function kgpNewCorr() { return "c" + Date.now() + "-" + (++_kgpCorrSeq); }
function kgpAlertOnce(corr, fn) {
  if (!corr) { fn(); return; }
  if (_kgpCorrDone.has(corr)) return;   // 같은 요청은 이미 알럿함 → 중복 억제
  _kgpCorrDone.add(corr);
  if (_kgpCorrDone.size > 300) {        // 메모리 상한(오래된 corr 정리)
    const it = _kgpCorrDone.values();
    for (let i = 0; i < 100; i++) { const v = it.next(); if (v.done) break; _kgpCorrDone.delete(v.value); }
  }
  fn();
}

function kgpToast(message, ok) {
  let t = document.getElementById("kgp-collect-toast");
  if (!t) {
    t = document.createElement("div");
    t.id = "kgp-collect-toast";
    t.style.cssText = [
      "position:fixed", "right:20px", "top:88px", "z-index:2147483647",
      "max-width:280px", "padding:10px 14px", "border-radius:10px",
      "font:13px/1.4 -apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif",
      "color:#fff", "box-shadow:0 4px 16px rgba(0,0,0,.25)", "white-space:pre-wrap"
    ].join(";");
    document.body.appendChild(t);
  }
  t.style.background = ok ? "#16a34a" : "#dc2626";
  t.textContent = message;
  t.style.opacity = "1";
  clearTimeout(t._hideTimer);
  t._hideTimer = setTimeout(() => { t.style.opacity = "0"; }, 4000);
}

// 결과 토스트(단일 메시지 + 액션 버튼). 신규/중복을 '하나씩' 명확히 — 완료·중복 동시 출력 금지.
let _kgpServerUrl = "";
try { kgpSendMessage({ action: "getSettings" }, (s) => { if (s && s.serverUrl) _kgpServerUrl = s.serverUrl; }); } catch (e) {}
function _kgpEsc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])); }
// F49-T 3부: 수집한 초안(편집 화면)으로 바로 — 서버가 준 item_id만 쓴다.
function kgpOpenDraft(itemId) {
  const base = _kgpServerUrl || "https://kohganepercentiii.com";
  window.open(base + "/seller/collect/preview/" + encodeURIComponent(String(itemId || "")), "_blank", "noopener");
}
function kgpOpenHistory() {
  const base = _kgpServerUrl || "https://kohganepercentiii.com";
  window.open(base + "/seller/collect/history", "_blank", "noopener");
}
function kgpResultToast(message, ok, actions) {
  // actions: [{label, fn}] — 토스트 안 작은 버튼(이력 열기 / 다시 수집)
  let t = document.getElementById("kgp-collect-toast");
  if (!t) {
    t = document.createElement("div");
    t.id = "kgp-collect-toast";
    t.style.cssText = [
      "position:fixed", "right:20px", "top:88px", "z-index:2147483647",
      "max-width:300px", "padding:11px 14px", "border-radius:10px",
      "font:13px/1.4 -apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif",
      "color:#fff", "box-shadow:0 4px 16px rgba(0,0,0,.25)"
    ].join(";");
    document.body.appendChild(t);
  }
  t.style.background = ok ? "#16a34a" : "#dc2626";
  t.innerHTML = '<div style="white-space:pre-wrap">' + _kgpEsc(message) + "</div>";
  (actions || []).forEach((a, i) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.textContent = a.label;
    btn.style.cssText = "margin:8px 6px 0 0;padding:5px 10px;border-radius:8px;border:1px solid rgba(255,255,255,.6);background:rgba(255,255,255,.14);color:#fff;font:600 12px/1 inherit;cursor:pointer";
    btn.addEventListener("click", (e) => { e.stopPropagation(); try { a.fn(); } catch (err) {} });
    t.appendChild(btn);
  });
  t.style.opacity = "1";
  clearTimeout(t._hideTimer);
  // 액션 버튼이 있으면 오래 유지(클릭 기회), 없으면 4초.
  t._hideTimer = setTimeout(() => { t.style.opacity = "0"; }, (actions && actions.length) ? 9000 : 4000);
}

// ── v82 STEP4: 수집 카드(부유 미리보기) ────────────────────────────────────────
//   우하단 고정 폐기(상점 かごに追加/장바구니 버튼 가림 근치) → 우측 상단 1/3 앵커.
//   접힘 pill 기본(필드 요약만) · 클릭 확장(Pop in 200ms ease-out) · reduced-motion 존중.
//   사이트 고정요소(fixed/sticky)와 충돌 시 세로 오프셋 회피. gogabridj 토큰은 스코프 CSS 변수 단일 소스.
function kgpEnsureCardStyles() {
  if (document.getElementById("kgp-card-style")) return;
  const st = document.createElement("style");
  st.id = "kgp-card-style";
  st.textContent =
    '#kgp-collect-card{--kgp-ink:#1A1714;--kgp-hanji:#F5EFE3;--kgp-gold:#C9A24B;--kgp-teal:#119A8E;--kgp-red:#DC2626;--kgp-line:#E6DECB;' +
    'position:fixed;right:16px;z-index:2147483647;max-width:300px;' +
    'font:13px/1.45 -apple-system,BlinkMacSystemFont,"Segoe UI",Pretendard,sans-serif;color:var(--kgp-hanji)}' +
    '#kgp-collect-card .kgp-cc-pill{display:flex;align-items:center;gap:8px;cursor:pointer;padding:9px 14px;' +
    'border-radius:999px;background:var(--kgp-ink);border:1.5px solid var(--kgp-gold);box-shadow:0 8px 24px rgba(26,23,20,.38);user-select:none}' +
    '#kgp-collect-card .kgp-cc-glyph{display:inline-flex;width:20px;height:20px;flex-shrink:0}' +
    '#kgp-collect-card .kgp-cc-dot{width:8px;height:8px;border-radius:999px;background:var(--kgp-teal);flex-shrink:0}' +
    '#kgp-collect-card .kgp-cc-title{font-weight:700;white-space:nowrap}' +
    '#kgp-collect-card .kgp-cc-caret{margin-left:2px;opacity:.6;font-size:11px;transition:transform .2s ease}' +
    '#kgp-collect-card[data-collapsed="0"] .kgp-cc-caret{transform:rotate(180deg)}' +
    '#kgp-collect-card .kgp-cc-body{margin-top:8px;padding:12px 14px;border-radius:14px;background:var(--kgp-ink);' +
    'border:1px solid var(--kgp-line);box-shadow:0 8px 24px rgba(26,23,20,.38);transform-origin:top right}' +
    '#kgp-collect-card[data-collapsed="1"] .kgp-cc-body{display:none}' +
    '#kgp-collect-card .kgp-cc-msg{white-space:pre-wrap}' +
    '#kgp-collect-card .kgp-cc-actions{display:flex;flex-wrap:wrap;gap:8px;margin-top:10px}' +
    '#kgp-collect-card .kgp-cc-actions:empty{display:none}' +
    '#kgp-collect-card .kgp-cc-btn{padding:6px 12px;border-radius:999px;border:1px solid var(--kgp-teal);' +
    'background:transparent;color:var(--kgp-teal);font:600 12px/1 inherit;cursor:pointer}' +
    '#kgp-collect-card .kgp-cc-btn:hover{background:rgba(17,154,142,.14)}' +
    // v83.1 STEP1: 카드 안 한국어 번역 토글(팝업과 같은 설정). 금 헤어라인으로 결과 문구와 구분.
    '#kgp-collect-card .kgp-cc-opt{display:flex;align-items:center;justify-content:space-between;gap:10px;' +
    'margin-top:10px;padding-top:10px;border-top:1px solid color-mix(in srgb, var(--kgp-gold) 34%, transparent);cursor:pointer}' +
    '#kgp-collect-card .kgp-cc-opt span{font-size:12px;color:var(--kgp-hanji)}' +
    '#kgp-collect-card .kgp-cc-opt input{width:34px;height:19px;cursor:pointer;accent-color:var(--kgp-teal);flex-shrink:0}' +
    '#kgp-collect-card[data-err="1"] .kgp-cc-pill{border-color:var(--kgp-red)}' +
    '#kgp-collect-card[data-err="1"] .kgp-cc-dot{background:var(--kgp-red)}' +
    '@keyframes kgpCardPop{from{opacity:0;transform:scale(.82)}to{opacity:1;transform:scale(1)}}' +
    '#kgp-collect-card .kgp-cc-pop{animation:kgpCardPop .2s ease-out both}' +
    '@media (prefers-reduced-motion: reduce){#kgp-collect-card .kgp-cc-pop{animation:none}}';
  (document.head || document.documentElement).appendChild(st);
}
// 우측 상단 1/3 배치 + 사이트 고정요소 충돌 회피(세로 오프셋). elementsFromPoint로 fixed/sticky 겹침 탐지.
function _kgpPlaceCard(card) {
  const vh = window.innerHeight || 800;
  let top = Math.round(vh * 0.30);   // 상단 약 1/3
  card.style.right = "16px";
  card.style.top = top + "px";
  for (let i = 0; i < 8; i++) {
    const r = card.getBoundingClientRect();
    const probes = [[r.left + 8, r.top + 8], [r.right - 8, r.top + 8], [r.left + 8, r.bottom - 8]];
    let hit = false;
    card.style.visibility = "hidden";   // 자기 자신 제외하고 그 자리의 실제 요소 조회
    try {
      for (const p of probes) {
        const els = document.elementsFromPoint(p[0], p[1]) || [];
        for (const e of els) {
          if (e === card || card.contains(e)) continue;
          let pos = ""; try { pos = getComputedStyle(e).position; } catch (x) {}
          if (pos === "fixed" || pos === "sticky") { hit = true; break; }
        }
        if (hit) break;
      }
    } catch (e) {}
    card.style.visibility = "";
    if (!hit) break;
    top += 64; card.style.top = top + "px";
    if (top > vh - r.height - 16) { card.style.top = "16px"; break; }   // 바닥 도달 → 최상단 복귀
  }
}
// v83.1 STEP1: 수집 카드의 번역 토글 상태·안내 문구 반영. 카드가 없으면 아무 것도 하지 않는다.
function kgpRenderCardTranslate(card) {
  const c = card || document.getElementById("kgp-collect-card");
  if (!c) return;
  const input = c.querySelector(".kgp-cc-translate");
  const note = c.querySelector(".kgp-cc-opt-note");
  if (input) input.checked = !!KGP_TRANSLATE;
  // 정직: 이 토글은 **다음 수집부터** 적용된다(이미 저장된 항목을 되돌리지 않는다).
  if (note) note.textContent = KGP_TRANSLATE ? "· 다음 수집부터 적용" : "· 원문 그대로 저장돼요";
}

// 단일 수집 결과를 카드로. 등장 시 확장(Pop in) → 3초 후 pill로 수렴(토스트·카드 중복 노출 금지).
function kgpCollectCard(message, ok, actions) {
  kgpEnsureCardStyles();
  let card = document.getElementById("kgp-collect-card");
  if (!card) {
    card = document.createElement("div");
    card.id = "kgp-collect-card";
    card.setAttribute("data-collapsed", "1");
    card.innerHTML =
      '<div class="kgp-cc-pill" role="button" tabindex="0" aria-label="수집 카드 펼치기/접기">' +
        '<span class="kgp-cc-glyph">' + KGP_BRIDGE_SVG + '</span>' +
        '<span class="kgp-cc-dot"></span>' +
        '<span class="kgp-cc-title"></span>' +
        '<span class="kgp-cc-caret">▾</span>' +
      '</div>' +
      '<div class="kgp-cc-body"><div class="kgp-cc-msg"></div><div class="kgp-cc-actions"></div>' +
        // v83.1 STEP1: 다음 수집부터 적용되는 번역 설정(팝업 토글과 같은 값). 이번 결과는 위 문구가 말한다.
        '<label class="kgp-cc-opt"><span>한국어 번역 <span class="kgp-cc-opt-note"></span></span>' +
        '<input type="checkbox" class="kgp-cc-translate"></label>' +
      '</div>';
    (document.body || document.documentElement).appendChild(card);
    const pill = card.querySelector(".kgp-cc-pill");
    const toggle = () => {
      const collapsed = card.getAttribute("data-collapsed") === "1";
      card.setAttribute("data-collapsed", collapsed ? "0" : "1");
      clearTimeout(card._kgpConverge);   // 수동 조작하면 자동 수렴 취소
      if (collapsed) {
        const b = card.querySelector(".kgp-cc-body");
        b.classList.remove("kgp-cc-pop"); void b.offsetWidth; b.classList.add("kgp-cc-pop");
        _kgpPlaceCard(card);
      }
    };
    pill.addEventListener("click", toggle);
    pill.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); toggle(); } });
    // v83.1 STEP1: 카드 안 번역 토글 — 팝업과 같은 storage 키에 쓴다(양방향 동기는 onChanged가 담당).
    //   카드 클릭이 접힘 토글로 새지 않도록 stopPropagation.
    const optRow = card.querySelector(".kgp-cc-opt");
    const optInput = card.querySelector(".kgp-cc-translate");
    if (optRow) optRow.addEventListener("click", (e) => { e.stopPropagation(); clearTimeout(card._kgpConverge); });
    if (optInput) {
      optInput.addEventListener("change", () => {
        KGP_TRANSLATE = !!optInput.checked;
        kgpStoreLocal({ kgp_translate: KGP_TRANSLATE });
        kgpApplyTranslateCopy();
        kgpRenderCardTranslate();
      });
    }
  }
  kgpRenderCardTranslate(card);
  card.setAttribute("data-err", ok ? "0" : "1");
  const first = String(message || "").split("\n")[0];
  card.querySelector(".kgp-cc-title").textContent = first.length > 22 ? first.slice(0, 21) + "…" : first;
  card.querySelector(".kgp-cc-msg").textContent = message || "";
  const act = card.querySelector(".kgp-cc-actions");
  act.textContent = "";
  (actions || []).forEach((a) => {
    const b = document.createElement("button");
    b.type = "button"; b.className = "kgp-cc-btn"; b.textContent = a.label;
    b.addEventListener("click", (e) => { e.stopPropagation(); try { a.fn(); } catch (err) {} });
    act.appendChild(b);
  });
  // 등장: 확장 + Pop in → 3초 후 pill 수렴.
  card.setAttribute("data-collapsed", "0");
  _kgpPlaceCard(card);
  const body = card.querySelector(".kgp-cc-body");
  body.classList.remove("kgp-cc-pop"); void body.offsetWidth; body.classList.add("kgp-cc-pop");
  clearTimeout(card._kgpConverge);
  card._kgpConverge = setTimeout(() => { card.setAttribute("data-collapsed", "1"); }, 3000);
  return card;
}

// v83.1 STEP1: FAB 부제·title을 번역 토글 상태에 동기화. 버튼이 하는 일을 라벨이 정확히 말하게 한다
//   ("번역까지 한 번에"인데 실제로는 원문 저장 = 거짓 라벨). 인자 없으면 현재 FAB를 찾아 갱신.
function kgpApplyTranslateCopy(btn) {
  const el = btn || document.getElementById(KGP_BTN_ID);
  if (!el) return;
  el.title = KGP_TRANSLATE ? "고가브릿지로 수집 (한국어 번역 포함)" : "고가브릿지로 수집 (원문 그대로)";
  const sub = _kgpFabQuery(el, ".kgp-fab-sub");
  if (sub) sub.textContent = KGP_TRANSLATE ? "번역까지 한 번에" : "원문 그대로 수집";
}

function setFabState(btn, state) {
  if (state === "loading") {
    btn.dataset.busy = "1";
    btn.style.opacity = "0.7";
    { const _l = _kgpFabQuery(btn, ".kgp-fab-label"); if (_l) _l.textContent = "수집 중..."; }
  } else {
    btn.dataset.busy = "";
    btn.style.opacity = "1";
    { const _l = _kgpFabQuery(btn, ".kgp-fab-label"); if (_l) _l.textContent = "고가수집기"; }
  }
}

// 고가브릿지 게이트웨이(B) 마크 — 공식 브랜드 자산과 동일(금 아치 + 청록 다리 + 주황 키스톤).
// v21/v22/v38: 옛 마크·이모지 폐기 — 확정 브릿지 마크 단독(어두운 원형 배지 위 스트로크 아치).
// v39 신규 브릿지 마크 — 흰 배경 + 검정 라운드 보더 + 금 게이트 링(아치) + 주황 키스톤 + 청록 데크 2줄 + 금 타이.
// 파비콘/확장/PWA 아이콘과 동일 디자인(단일 소스). 소형 표시에 맞춰 스트로크 굵게.
const KGP_BRIDGE_SVG =
  '<svg width="22" height="22" viewBox="0 0 512 512" aria-hidden="true" style="display:block">' +
  '<rect x="23" y="23" width="466" height="466" rx="112" fill="#ffffff" stroke="#111111" stroke-width="26"/>' +
  '<circle cx="256" cy="205" r="92" fill="none" stroke="#c9a24b" stroke-width="40"/>' +
  '<line x1="67" y1="338" x2="445" y2="338" stroke="#119a8e" stroke-width="40" stroke-linecap="round"/>' +
  '<line x1="67" y1="381" x2="445" y2="381" stroke="#119a8e" stroke-width="40" stroke-linecap="round"/>' +
  '<line x1="130" y1="338" x2="130" y2="381" stroke="#c9a24b" stroke-width="16"/>' +
  '<line x1="256" y1="338" x2="256" y2="381" stroke="#c9a24b" stroke-width="16"/>' +
  '<line x1="382" y1="338" x2="382" y2="381" stroke="#c9a24b" stroke-width="16"/>' +
  '<circle cx="256" cy="113" r="44" fill="#f5821f"/>' +
  '</svg>';

// ---------------------------------------------------------------------------
// v7 공통 유틸 — 위치 기억(localStorage)·드래그·등장모션·수집 누적/축하(따라하기 재미).
//   prefers-reduced-motion 존중. 일부 사이트에서 localStorage가 막힐 수 있어 전부 try/catch.
// ---------------------------------------------------------------------------
const KGP_RM = !!(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);
function kgpLSget(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } }
function kgpLSset(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* noop */ } }

function kgpEnsureStyles() {
  if (KGP_RM || document.getElementById("kgp-style")) return;
  const st = document.createElement("style");
  st.id = "kgp-style";
  st.textContent =
    "@keyframes kgpPulse{0%,100%{box-shadow:0 4px 14px rgba(0,0,0,.4),0 0 0 0 rgba(17,154,142,.55)}50%{box-shadow:0 4px 14px rgba(0,0,0,.4),0 0 0 8px rgba(17,154,142,0)}}" +
    "@keyframes kgpStampIn{0%{transform:scale(.4) rotate(-16deg);opacity:0}60%{transform:scale(1.14) rotate(-7deg);opacity:1}100%{transform:scale(1) rotate(-7deg);opacity:1}}";
  (document.head || document.documentElement).appendChild(st);
}

// 드래그로 위치 이동 + 마지막 위치를 localStorage에 기억. opts.handle/opts.ignore 지원.
// 드래그 직후 click을 억제하도록 el._kgpDragged 플래그를 잠깐 세운다.
// v73 STEP1: all:initial !important(v72 격리)가 우리 위치 오프셋(top/left/right/transform)을 auto로
//   !important 덮어써 벌크바·FAB·호버버튼이 정적 흐름(긴 페이지 최하단=화면 밖)으로 떨어지던 회귀 수리.
//   동적 위치(드래그·클램프)도 반드시 !important로 설정해 격리 리셋을 이긴다. (크기 격리는 유지.)
function _kgpPos(el, prop, val) { try { el.style.setProperty(prop, val, "important"); } catch (e) { el.style[prop] = val; } }

// v84 STEP1(P0-A): 위치 재확정 — `all:initial !important` 격리와 **같은 선언 블록**에 위치를 넣으면,
//   브라우저가 all 숏핸드를 확장하는 방식/순서에 따라 position이 static(=initial)으로 먹히는 사고가 난다
//   (오너 실기기 증상: FAB computed position=initial → 화면에서 사라짐). cssText 배정 **후** 위치 롱핸드를
//   setProperty(...,'important')로 다시 박아 넣으면 숏핸드 확장과 무관하게 항상 이긴다(v73 _kgpPos와 동일 수법).
//   기존 cssText 선언은 그대로 둔다 — 이중 안전장치(하나가 통해도 결과 동일).
function _kgpPinFixed(el, pos) {
  if (!el) return;
  pos = pos || {};
  _kgpPos(el, "position", "fixed");
  _kgpPos(el, "z-index", "2147483647");
  Object.keys(pos).forEach(function (k) { _kgpPos(el, k, pos[k]); });
}

// ── v86 STEP1: Shadow DOM 격리(all:initial 폐기) ────────────────────────────
//   근원: `all:initial !important`를 **인라인**에 걸면 Chrome이 250여 롱핸드로 전개해 배경·크기·색까지 전부
//   초기화한다. 인라인 !important라 우리 kgp-style 시트로도 복원 불가(우선순위상 원천 봉쇄) → 요소는 fixed로
//   존재하지만 **투명·0크기로 안 보인다**(오너 실측: width/height/transform initial).
//   해결: 호스트에는 **위치 계열만** 인라인으로 두고, 실제 모양은 shadowRoot 안에서 그린다.
//   페이지 CSS 격리는 shadow 경계가 대신한다(v80 체크박스에서 이미 검증된 패턴).
// v86 STEP3: 진단 계측 단일 소스 — 호스트가 shadow를 가졌으면 **shadow 안 가시 요소**를, 아니면 호스트를 잰다.
//   `in_shadow`가 이 계층의 핵심 사실: 스냅샷 HTML로는 절대 알 수 없다(shadow 내용은 outerHTML에 없다).
//   계측 없는 컴포넌트 신설 금지 — 새 오버레이를 만들면 여기서 잴 수 있게 host+셀렉터를 넘긴다.
function _kgpMeasureVisible(host, innerSel) {
  var out = { in_shadow: false, w: 0, h: 0, bg: "", visibility: "", opacity: "",
              // v86 STEP4: **호스트 자체**도 잰다. 종전엔 shadow 안 알약만 재서, 호스트가 opacity:0이어도
              //   "배경 먹·80×34"로 그린이 나왔다(계측이 유령을 못 봄 = 그린 착시). 그 구멍을 메운다.
              host_opacity: "", host_important: false, center_hit: false };
  try {
    var root = host._kgpShadow || host.shadowRoot || null;
    out.in_shadow = !!root;
    var el = root ? (root.querySelector(innerSel) || host) : host;
    var cs = null; try { cs = getComputedStyle(el); } catch (e) {}
    out.w = el.offsetWidth || 0;
    out.h = el.offsetHeight || 0;
    out.bg = cs ? cs.backgroundColor : "";
    out.visibility = cs ? cs.visibility : "";
    out.opacity = cs ? cs.opacity : "";
    var hcs = null; try { hcs = getComputedStyle(host); } catch (e) {}
    out.host_opacity = hcs ? hcs.opacity : "";
    // 호스트 인라인 !important 잔존 감시(신설 원칙 위반 즉시 적발).
    try {
      out.host_important = ["opacity", "display", "visibility"].some(function (p) {
        return host.style.getPropertyPriority(p) === "important";
      });
    } catch (e) {}
    // **최종 판정은 히트테스트로.** computed 값 단독 판정은 이번 착시의 원인 — 실제로 그 좌표를 눌렀을 때
    // 우리 요소가 잡히는지가 유일하게 믿을 수 있는 '보인다'의 정의다(가림·투명·표류를 한 번에 잡는다).
    try {
      var r = host.getBoundingClientRect();
      var hit = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
      out.center_hit = !!(hit && (hit === host || host.contains(hit) || (hit.getRootNode && hit.getRootNode().host === host)));
    } catch (e) {}
  } catch (e) {}
  return out;
}
// v86 STEP3: 잔존(구버전) 타일 일소 — shadow 없이 만들어진 [수집]/선택 뱃지는 **유령**이므로 걷어낸다.
//   판정 근거: 현재 빌더(_kgpBuildQuick/_kgpBuildCheckbox)는 항상 `_kgpShadow`를 세운다(미지원 브라우저면 null).
//   따라서 `_kgpShadow === undefined`인 요소는 **우리 현재 코드가 만들지 않은 것** — 확장 업데이트 직후 열려
//   있던 탭, SPA 복원, 저장된 스냅샷의 잔재뿐이다. 타일 재주입은 멱등이라 지우면 곧바로 shadow 판으로 재생성된다.
function _kgpSweepStaleTiles() {
  try {
    var stale = document.querySelectorAll(".kgp-card-quick, .kgp-card-chk");
    var n = 0;
    for (var i = 0; i < stale.length; i++) {
      if (stale[i]._kgpShadow === undefined) { try { stale[i].remove(); n++; } catch (e) {} }
    }
    // v86-D: **툴바·재오픈 배지도 같은 잔재가 된다.** STEP3에서 타일만 쓸고 바를 빼먹었다.
    //   shadow 내용은 페이지 저장·복원에 직렬화되지 않으므로 남는 건 **빈 껍데기**인데,
    //   kgpInjectListing은 `if (!getElementById(KGP_TOOLBAR_ID))`로만 만들어 그 껍데기가
    //   재생성을 영영 막는다 → 벌크바가 DOM엔 있고 내용은 0인 유령(버튼·닫기 전부 없음).
    //   확장 업데이트/SPA 복원/저장 스냅샷에서 그대로 재현된다(실측: 아마존 스냅샷에 host 1개 잔존).
    //   판정은 타일과 동일하게 `_kgpShadow === undefined`(현행 빌더는 성공·실패 무관하게 값을 넣는다).
    var hostIds = [KGP_TOOLBAR_ID, KGP_REOPEN_ID];
    for (var h = 0; h < hostIds.length; h++) {
      var el = document.getElementById(hostIds[h]);
      if (el && el._kgpShadow === undefined) {
        try { el.remove(); n++; } catch (e) {}
        try { console.warn("[고가수집기] 구버전 오버레이 잔재 정리", hostIds[h]); } catch (e) {}
      }
    }
    if (n) { try { console.warn("[고가수집기] 구버전 잔재 정리", n); } catch (e) {} }
  } catch (e) {}
}
var _KGP_SHEETS = {};
function _kgpShadowHost(host, css, html) {
  var root = host._kgpShadow;
  if (root === undefined) {
    try { root = host.attachShadow({ mode: "open" }); } catch (e) { root = null; }
    host._kgpShadow = root;
  }
  if (!root) return null;                       // 구형 폴백: 호출측이 라이트 DOM으로 처리
  var full = ":host{all:initial}" + css;        // :host에만 initial — 내부 요소엔 영향 없음
  var adopted = false;
  try {
    if (("adoptedStyleSheets" in root) && typeof CSSStyleSheet === "function") {
      // F49-T 4부(성능): 같은 CSS면 **시트 하나를 공유**한다 — 타일마다 새로 파싱하던 것이 300장 첫 스캔
      //   230ms의 큰 몫이었다(측정). 내용이 같으므로 공유해도 격리는 그대로다(shadow 경계는 root마다).
      var sh = _KGP_SHEETS[full];
      if (!sh) { sh = new CSSStyleSheet(); sh.replaceSync(full); _KGP_SHEETS[full] = sh; }
      root.adoptedStyleSheets = [sh]; adopted = true;
    }
  } catch (e) { adopted = false; }
  var st = document.createElement("style"); st.textContent = full; root.appendChild(st);   // 인라인 폴백 항상
  if (!adopted) { try { console.warn("[고가수집기] adoptedStyleSheets 미지원 — <style> 폴백"); } catch (e) {} }
  // ShadowRoot에는 insertAdjacentHTML이 없다(DocumentFragment 계열) → 래퍼 div로 파싱해 옮긴다.
  var wrap = document.createElement("div");
  wrap.innerHTML = html;
  while (wrap.firstChild) root.appendChild(wrap.firstChild);
  return root;
}
// v86 STEP2: 벌크바 내부 조회는 shadowRoot를 통해야 한다(document.getElementById는 shadow를 못 뚫는다).
//   구형 폴백(shadow 미지원)에서는 라이트 DOM이므로 document로 떨어진다.
function _kgpTbRoot() {
  var bar = document.getElementById(KGP_TOOLBAR_ID);
  if (!bar) return null;
  return bar._kgpShadow || bar;
}
function _kgpTbQ(sel) {
  var r = _kgpTbRoot();
  try { return r ? r.querySelector(sel) : null; } catch (e) { return null; }
}
function _kgpTbAll(sel) {
  var r = _kgpTbRoot();
  try { return r ? r.querySelectorAll(sel) : []; } catch (e) { return []; }
}
// FAB 내부(shadow) 요소 조회 — 라이트 DOM 폴백도 함께 본다.
function _kgpFabQuery(el, sel) {
  if (!el) return null;
  try { if (el._kgpShadow) return el._kgpShadow.querySelector(sel); } catch (e) {}
  try { return el.querySelector(sel); } catch (e) { return null; }
}


function kgpMakeDraggable(el, storeKey, opts) {
  opts = opts || {};
  const saved = kgpLSget(storeKey, "");
  if (saved) {
    try {
      const p = JSON.parse(saved);
      if (p && typeof p.left === "number") {
        _kgpPos(el, "left", Math.max(4, Math.min(window.innerWidth - 40, p.left)) + "px");
        _kgpPos(el, "top", Math.max(4, Math.min(window.innerHeight - 40, p.top)) + "px");
        _kgpPos(el, "right", "auto"); _kgpPos(el, "bottom", "auto"); _kgpPos(el, "transform", "none");
      }
    } catch (e) { /* noop */ }
  }
  const handle = opts.handle || el;
  handle.style.cursor = "grab";
  let down = false, moved = false, sx = 0, sy = 0, ox = 0, oy = 0;
  handle.addEventListener("mousedown", (e) => {
    if (e.button !== 0) return;
    // v86 STEP2: shadow 안 버튼을 눌러도 host로 retarget돼 e.target이 호스트가 된다 → ignore가 무력화되고
    //   버튼 클릭이 드래그로 먹힌다. composedPath()[0]로 **실제** 눌린 요소를 본다(라이트 DOM도 동일 동작).
    var _t = e.target;
    try { var _p = e.composedPath && e.composedPath(); if (_p && _p.length) _t = _p[0]; } catch (e2) {}
    if (opts.ignore && _t && _t.closest && _t.closest(opts.ignore)) return;
    down = true; moved = false; sx = e.clientX; sy = e.clientY;
    const r = el.getBoundingClientRect(); ox = r.left; oy = r.top;
    e.preventDefault();
  });
  window.addEventListener("mousemove", (e) => {
    if (!down) return;
    const dx = e.clientX - sx, dy = e.clientY - sy;
    if (Math.abs(dx) + Math.abs(dy) > 4) moved = true;
    if (moved) {
      const nl = Math.max(4, Math.min(window.innerWidth - el.offsetWidth - 4, ox + dx));
      const nt = Math.max(4, Math.min(window.innerHeight - el.offsetHeight - 4, oy + dy));
      _kgpPos(el, "left", nl + "px"); _kgpPos(el, "top", nt + "px");
      _kgpPos(el, "right", "auto"); _kgpPos(el, "bottom", "auto"); _kgpPos(el, "transform", "none");
    }
  });
  window.addEventListener("mouseup", () => {
    if (down && moved) {
      const r = el.getBoundingClientRect();
      kgpLSset(storeKey, JSON.stringify({ left: Math.round(r.left), top: Math.round(r.top) }));
      el._kgpDragged = true;
      setTimeout(() => { el._kgpDragged = false; }, 60);
    }
    down = false;
  });
  kgpRegisterFixed(el);   // v15: 줌/리사이즈 시 화면 안으로 재보정
}

// v15 P0: 페이지 줌(Ctrl+휠)·창 리사이즈 시 고정 오버레이가 화면 밖으로 나가거나
// 가장자리에서 겹치지 않도록 뷰포트 안으로 다시 끌어들인다. (left/top으로 배치된 요소만 보정 —
// right/bottom 앵커는 본래 뷰포트 상대라 안전.) 카운트업/배지 등 일회성 요소는 등록하지 않는다.
const KGP_FIXED_ELS = [];
function kgpRegisterFixed(el) { if (el && KGP_FIXED_ELS.indexOf(el) < 0) KGP_FIXED_ELS.push(el); }
function kgpClampFixed(el) {
  if (!el || !el.isConnected) return;
  if (!el.style.left || el.style.left === "auto") return;
  const w = el.offsetWidth, h = el.offsetHeight;
  const l = parseFloat(el.style.left) || 0, t = parseFloat(el.style.top) || 0;
  _kgpPos(el, "left", Math.max(4, Math.min(Math.max(4, window.innerWidth - w - 4), l)) + "px");
  _kgpPos(el, "top", Math.max(4, Math.min(Math.max(4, window.innerHeight - h - 4), t)) + "px");
}
let _kgpResizeT = null;
function kgpOnViewportChange() {
  if (_kgpResizeT) return;
  _kgpResizeT = setTimeout(() => {
    _kgpResizeT = null;
    for (let i = KGP_FIXED_ELS.length - 1; i >= 0; i--) {
      if (!KGP_FIXED_ELS[i].isConnected) { KGP_FIXED_ELS.splice(i, 1); continue; }
      kgpClampFixed(KGP_FIXED_ELS[i]);
    }
  }, 120);
}
if (!window.__kgpViewportBound) {
  window.addEventListener("resize", kgpOnViewportChange);
  window.__kgpViewportBound = true;
}

// v64 STEP4: 벌크바 스크롤 추적 sticky 하드닝. 바는 position:fixed(뷰포트 상단 고정)라 원래 스크롤을
//   따라오지만, 일부 사이트는 <html>/<body> 조상에 transform/filter를 걸어 position:fixed의 기준을
//   바꿔 바가 콘텐츠와 함께 스크롤돼 버린다(고전적 'fixed inside transform' 버그). 스크롤 시 바의 실제
//   top이 의도한 값에서 밀렸으면 translateY로 보정해 항상 뷰포트 상단에 고정한다. 사용자가 드래그해
//   위치를 저장했으면(kgp_bar_pos) 존중(자동 재핀 안 함). z-index는 최상위(2147483647)라 사이트 헤더 위.
const _KGP_BAR_TOP = 12;
let _kgpBarPinT = null;
function _kgpKeepBarPinned() {
  const bar = document.getElementById(KGP_TOOLBAR_ID);
  if (!bar || !bar.isConnected) return;
  if (kgpLSget("kgp_bar_pos", "")) return;          // 사용자가 옮긴 위치는 존중
  bar.style.transform = "translateX(-50%)";          // 기준 복원 후 실제 top 측정
  let top;
  try { top = bar.getBoundingClientRect().top; } catch (e) { return; }
  const drift = top - _KGP_BAR_TOP;                   // 변형 조상 때문에 밀린 양(정상 사이트=≈0)
  if (Math.abs(drift) > 1) bar.style.transform = "translateX(-50%) translateY(" + (-drift) + "px)";
}
function _kgpBarScroll() {
  if (_kgpBarPinT) return;                            // 스크롤 스로틀(리플로우 최소화)
  _kgpBarPinT = setTimeout(() => { _kgpBarPinT = null; _kgpKeepBarPinned(); }, 120);
}
if (!window.__kgpBarScrollBound) {
  window.addEventListener("scroll", _kgpBarScroll, { passive: true });
  window.__kgpBarScrollBound = true;
}

// v45 P4·P5: 지속 오버레이(FAB·벌크바·구석 배지)를 <body>가 아니라 **documentElement(<html>) 직속**에
//   붙인다. 이유: ①SPA가 <body> 전체를 갈아끼워도 오버레이가 살아남음(P5 깜빡임 방지) ②<body>에 걸린
//   transform/filter가 position:fixed 기준을 바꿔 '좌상단 처박힘'을 유발하는 것을 회피(P4 상단중앙 고정).
//   (transient 토스트/도장은 짧게 살다 사라져 <body>여도 무방.)
function _kgpMount(el) {
  (document.documentElement || document.body).appendChild(el);
}

// 수집 누적 카운트 + 마일스톤 축하(실제 성공 시에만 호출).
function kgpBumpCount(n) {
  let c = parseInt(kgpLSget("kgp_collect_count", "0"), 10) || 0;
  c += (n || 0); kgpLSset("kgp_collect_count", String(c));
  return c;
}
const KGP_WIT = [
  "오늘도 한 건 +1", "담았습니다. 다음 상품 가시죠", "착! 도장 쾅",
  "수집 완료, 다음 상품으로", "마진은 셀러님 몫",
];
function kgpCelebrate(added, silent) {
  // silent=true면 축하 애니메이션(스탬프)만 — 토스트는 호출부가 '하나' 띄운다(완료/중복 동시출력 금지).
  added = Math.max(1, added || 1);
  const total = kgpBumpCount(added);
  const prev = total - added;
  const milestones = [10, 50, 100, 300, 500, 1000];
  let milestone = 0;
  for (const m of milestones) { if (prev < m && total >= m) milestone = m; }
  if (KGP_RM) {
    if (!silent) kgpToast(`수집 완료 · 누적 ${total}건` + (milestone ? `\n${milestone}건 달성!` : ""), true);
    return total;
  }
  kgpEnsureStyles();
  const ov = document.createElement("div");
  // v82 STEP4: 우하단 → 우상단(장바구니 버튼 가림 근치). 축하 스탬프는 상단, 정보/액션은 수집 카드(우측 1/3)가 담당.
  ov.style.cssText = "position:fixed;right:24px;top:20px;z-index:2147483647;pointer-events:none;display:flex;flex-direction:column;align-items:flex-end;gap:6px";
  const stamp = document.createElement("div");
  stamp.style.cssText = "display:flex;align-items:center;gap:8px;padding:10px 16px;border-radius:14px;background:#1a1714;border:2px solid #c9a24b;color:#f5efe3;font:700 14px/1 -apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;box-shadow:0 8px 24px rgba(0,0,0,.45);animation:kgpStampIn .5s ease-out both";
  stamp.innerHTML = '<span style="display:inline-flex;width:22px;height:22px;align-items:center;justify-content:center">' + KGP_BRIDGE_SVG + '</span><span>' + KGP_WIT[Math.floor(Math.random() * KGP_WIT.length)] + "</span>";
  ov.appendChild(stamp);
  const counter = document.createElement("div");
  counter.style.cssText = "padding:5px 12px;border-radius:999px;background:#119a8e;color:#fff;font:700 12px/1 -apple-system,sans-serif;animation:kgpStampIn .5s ease-out both";
  ov.appendChild(counter);
  if (milestone) {
    const badge = document.createElement("div");
    badge.style.cssText = "padding:6px 14px;border-radius:999px;background:#c9a24b;color:#1a1714;font:800 13px/1 -apple-system,sans-serif;animation:kgpStampIn .55s ease-out both";
    badge.textContent = milestone + "건 달성!";
    ov.appendChild(badge);
  }
  document.body.appendChild(ov);
  const t0 = performance.now(), dur = 650;
  (function tick(now) {
    const p = Math.min(1, (now - t0) / dur);
    counter.textContent = "누적 " + Math.round(prev + (total - prev) * p) + "건";
    if (p < 1) requestAnimationFrame(tick);
  })(t0);
  setTimeout(() => { ov.style.transition = "opacity .4s"; ov.style.opacity = "0"; setTimeout(() => ov.remove(), 420); }, milestone ? 3400 : 2300);
  return total;
}

// v47 STEP4: MAIN world 추출 결과 병합 — 격리월드(content_script)가 못 읽는 페이지 live 전역
//   (Temu 등 XHR로 렌더 후 채우는 초기 상태)을 MAIN world(kgp-main.js)에서 읽어 넘긴 meta와 병합.
//   비어 있는 필드는 채우고, 배열(이미지·옵션·리뷰·상세)은 더 완전한 쪽 채택. 응답 없으면 격리월드만(정직).
function kgpMergeMeta(base, extra) {
  if (!extra || typeof extra !== "object") return base;
  const out = Object.assign({}, base);
  const empty = (v) => v == null || v === "" || (Array.isArray(v) && v.length === 0);
  // v83 STEP1: currency_source(통화 근거)도 빈 쪽을 채운다 — 서버 진단이 어느 사다리로 확정했는지 본다.
  ["title", "price", "currency", "currency_source", "description", "rating", "review_count", "price_status", "source"].forEach((k) => {
    if (empty(out[k]) && !empty(extra[k])) out[k] = extra[k];
  });
  out.translated_dom = !!(out.translated_dom || extra.translated_dom);   // v83 STEP1: 어느 월드든 번역 DOM 감지 시 표기
  // F49-T 2부-b: ICE(티몰 상태)가 옵션·SKU를 줬으면 그게 정본이다 — 「긴 쪽이 이긴다」 규칙으로
  //   DOM 잡음 그룹(已售/可开发票/加入购物车 류 4그룹)이 ICE 1그룹을 덮으면 안 된다.
  const _iceBase = !!(base && base.field_sources && base.field_sources.sku === "ice_context");
  ["images", "gallery_images", "detail_images", "options", "skus", "reviews", "detail_specs"].forEach((k) => {
    if (_iceBase && (k === "options" || k === "skus")) return;
    const a = Array.isArray(out[k]) ? out[k] : [], b = Array.isArray(extra[k]) ? extra[k] : [];
    if (b.length > a.length) out[k] = b;
  });
  if (empty(out.image) && out.images && out.images.length) out.image = out.images[0];
  if (empty(out.thumbnail) && out.images && out.images.length) out.thumbnail = out.images[0];
  out.detail_fold = !!(out.detail_fold || extra.detail_fold);   // v57 STEP3: 어느 월드든 접힘 감지 시 표기
  if (!empty(out.price) && Array.isArray(out.images) && out.images.length) out.partial = false;  // 병합으로 핵심 확보
  // field_sources 병합: MAIN이 json 준 필드는 json 우선(수집 로그가 실제 소스 표기).
  if (extra.field_sources) {
    out.field_sources = Object.assign({}, out.field_sources || {});
    for (const fk in extra.field_sources) {
      // MAIN(Tier1/JSON)이 준 소스는 격리월드(DOM/none) 위에 우선(실제 소스 표기).
      if (extra.field_sources[fk] === "tier1" || extra.field_sources[fk] === "json") out.field_sources[fk] = extra.field_sources[fk];
      else if (!out.field_sources[fk] || out.field_sources[fk] === "none") out.field_sources[fk] = extra.field_sources[fk];
    }
  }
  return out;
}
// v86-G: Tier1 진단 조립 단일 소스. 종전엔 **성공 응답 경로에서만** merged.tier1_diag를 세웠고,
//   900ms 타임아웃 폴백은 콘솔 경고만 남기고 그냥 cb(isolated)로 빠졌다. 그래서 MAIN world가 응답을
//   못 하면 payload에 tier1 흔적이 **아예 없고**, 오너 실기기에선 "tier1 흔적 무"로만 보였다
//   (=미주입인지, 진단 자체가 안 붙은 건지 구분 불가). 이제 두 경로 모두 여기를 통과한다.
// 필드: tier1_hits(=채점 통과 응답 수) / tier1_seen·dropped(채점 이전 트래픽) / top(최고점 후보 요약).
function _kgpTier1Diag(diag, tier1Source, usedTier1, cause) {
  diag = diag || {};
  var ns = diag.netStats || {};
  return {
    used: !!usedTier1,
    netBound: !!diag.netBound,
    tier1_source: tier1Source || "",
    tier1_hits: diag.captured || 0,          // 채점 통과(score>=1) 응답 수 = 실제 후보 수
    tier1_seen: ns.seen || 0,                // 래퍼가 본 응답 수(채점 전) — 0이면 월드/타이밍 문제
    tier1_jsonish: ns.jsonish || 0,
    tier1_dropped: ns.dropped || 0,          // 봤지만 0점 = 시그니처 채점 문제
    dropped_urls: ns.droppedUrls || [],
    top: diag.top || null,                   // {url,score,price,images,sku,reviews,size,goods_id}
    // v86-K: 실제 채택 후보(읽기 전용 계측 — 선택 로직 무변경). top과 다르면 방어(id 불일치 기각) 작동 증거.
    //   {adopted, url, score, goods_id, goods_matched, price/images/sku/reviews 불리언, adopt_cause enum}.
    adopted: diag.adopted || null,
    topScore: diag.topScore || 0,
    cause: cause || "",
    page_goods_id: diag.pageGoodsId || "",
    goods_matched: !!diag.matched,
    // v86-G(수리): 매칭·스코프 판독. `goods_matched:false`의 원인이 "응답 자체가 없음"인지
    //   "응답은 왔는데 대표 id가 추천 상품이라 버려짐"인지 가르려면 **응답 안 goods_id 개수**가 필요하다.
    //   scope는 추천 캐러셀 배제 여부(narrowed / already_pure / scope_lost_signal).
    goods_ids_n: (diag.top && diag.top.goods_ids_n) || 0,
    tier1_scope: diag.scope || null,
    main_world: _kgpMainWorldState(),        // F49-T 3부: 원인 판정의 근거(관측값 그대로)
  };
}
// v86-G: 캡처 0의 원인 갈래를 **관측값으로** 가른다(추측 문구 금지).
// F49-T 3부: 「인터셉터 미주입(MAIN world 로드 실패 — 확장 재로딩 필요)」는 world.taobao.com에서 **오진**이었다.
//   네트워크 인터셉터(kgp-net.js)는 manifest상 temu에만 등록돼 있다 — 타오바오엔 원래 없다.
//   세 갈래를 **관측값으로** 가른다: ① 이 사이트는 등록 대상이 아님 ② 등록됐는데 이 페이지에서 안 돌았음
//   ③ 확장이 갱신됐는데 이 탭을 새로고침하지 않음(이 격리 월드가 끊긴 상태). 추측 문구 금지.
function _kgpNetRegistered(host) {
  try {
    var cs = (chrome.runtime.getManifest() || {}).content_scripts || [];
    host = String(host || location.hostname || "").toLowerCase();
    for (var i = 0; i < cs.length; i++) {
      if ((cs[i].js || []).indexOf("kgp-net.js") < 0) continue;
      var ms = cs[i].matches || [];
      for (var j = 0; j < ms.length; j++) {
        var m = String(ms[j]).match(/^[^:]+:\/\/([^/]+)\//);
        if (!m) continue;
        var hp = m[1].toLowerCase();
        if (hp === "*") return true;
        if (hp.indexOf("*.") === 0) { var base = hp.slice(2); if (host === base || host.slice(-(base.length + 1)) === "." + base) return true; }
        else if (host === hp) return true;
      }
    }
  } catch (e) { return null; }   // 모름(매니페스트를 못 읽음) — 없다고 말하지 않는다
  return false;
}
function _kgpMainWorldState() {
  // 못 잰 값은 null(모름) — 모르는 걸 false(없음)로 적지 않는다.
  var de = null;
  try { de = (typeof document !== "undefined" && document) ? document.documentElement : null; } catch (e) { de = null; }
  var alive = null;
  try { alive = (typeof kgpExtAlive === "function") ? !!kgpExtAlive() : null; } catch (e) { alive = null; }
  var reg = null;
  try { reg = (typeof chrome !== "undefined" && chrome && chrome.runtime) ? _kgpNetRegistered(location.hostname) : null; } catch (e) { reg = null; }
  return {
    ext_alive: alive,                                                      // false = 확장 갱신 뒤 이 탭 미새로고침
    main_marker: de ? !!(de.getAttribute && de.getAttribute("data-kgp-main")) : null,   // kgp-main.js가 이 페이지에서 돌았나
    net_marker: de ? !!(de.getAttribute && de.getAttribute("data-kgp-net")) : null,
    net_registered: reg,
  };
}
function _kgpTier1Cause(diag) {
  var ns = (diag && diag.netStats) || {};
  if (!diag || !diag.netBound) {
    var st = _kgpMainWorldState();
    if (st.ext_alive === false) return "확장이 갱신됐는데 이 탭을 새로고침하지 않음(격리 월드 끊김) — 새로고침 후 재측정";
    if (st.net_registered === false) return "인터셉터 대상 아님(이 사이트는 네트워크 가로채기 미등록 — MAIN world " + (diag ? "정상 응답" : "미응답") + ")";
    if (st.net_registered === null) return "인터셉터 미주입 — 이 사이트 등록 여부를 확인하지 못함(매니페스트 읽기 실패)";
    return "인터셉터 미주입 — 등록된 사이트인데 이 페이지에서 실행되지 않음(주입 차단/실패 — 새로고침해도 같으면 이 페이지가 막는 것)";
  }
  if (diag.pageGoodsId && diag.mismatch && diag.captured) {
    return "이 상품의 API 응답 미포착(goods_id " + diag.pageGoodsId + ") — 페이지 새로고침 후 재시도";
  }
  if (!diag.captured) {
    if (!ns.seen) return "래퍼는 붙었는데 응답 0건(주입 타이밍 — 상품 데이터가 document_start 이전/문서 외 경로)";
    if (!ns.jsonish) return "응답 " + ns.seen + "건 전부 JSON 아님(캡처 대상 밖 — 요청 형식 변경 의심)";
    return "JSON " + ns.jsonish + "건 포착·전부 0점(시그니처 채점 미달 — 응답 키 구조 변경)";
  }
  return "시그니처 미달(최고점 " + (diag.topScore || 0) + "/4 — 팝업 '자가진단 모드'로 후보 표 확인)";
}
function kgpExtractMerged(cb) {
  let isolated;
  try { isolated = extractProductMeta(); }
  catch (e) { isolated = { url: location.href, partial: true, warnings: ["추출 실패"] }; }
  let done = false;
  const reqId = "kgpq_" + Date.now() + "_" + Math.floor(Math.random() * 1e6);
  function onMsg(e) {
    if (e.source !== window || !e.data || e.data.__kgpRes !== reqId) return;
    window.removeEventListener("message", onMsg);
    if (done) return; done = true;
    const merged = kgpMergeMeta(isolated, e.data.meta);
    // v55 STEP1: MAIN meta의 Tier1 채택 URL 전파(sources=tier1:{URL}).
    try { if (e.data.meta && e.data.meta.tier1_source && !merged.tier1_source) merged.tier1_source = e.data.meta.tier1_source; } catch (_) {}
    // v55 STEP1 / v56 STEP4: Tier1 자동 진단 — 기여했으면 확인, 아니면 원인 1줄(무음 금지).
    //   v56: 진단 결과를 payload에 동봉(tier1_diag) → 서버 저장·드로어 표기(콘솔 안 봐도 최종 판정 확인).
    try {
      var diag = e.data.diag || {};
      var usedTier1 = !!(merged.tier1_source) || (merged.field_sources && merged.field_sources.price === "tier1");
      var cause = "";
      if (usedTier1) {
        console.log("%c[고가수집기] Tier1 동작 ✓ — 채택 " + (merged.tier1_source || "(API 응답)") + " (최고점 " + (diag.topScore || 0) + "/4)", "color:#119a8e;font-weight:bold");
        if (diag.topUrl) kgpStoreLocal({ ["kgp_api_pat:" + location.hostname]: diag.topUrl });
      } else {
        cause = _kgpTier1Cause(diag);
        console.warn("%c[고가수집기] Tier1 무동작 → DOM 폴백 사용. 원인: " + cause, "color:#c2503c;font-weight:bold");
      }
      merged.tier1_diag = _kgpTier1Diag(diag, merged.tier1_source, usedTier1, cause);
      console.log("[고가수집기] MAIN world 병합 — 이미지 " + ((isolated.images || []).length) + "→" + ((merged.images || []).length)
        + ", 가격 " + (isolated.price || "-") + "→" + (merged.price || "-"));
    } catch (_) {}
    cb(merged);
  }
  window.addEventListener("message", onMsg, false);
  // v86-H: MAIN world는 kgpFindCards가 없어 스스로는 목록 판정을 못 한다 → 격리월드의 권위 판정을 실어 보낸다.
  var _ptForMain = ""; try { _ptForMain = kgpPageType(); } catch (e) {}
  try { window.postMessage({ __kgpReq: reqId, pageType: _ptForMain }, "*"); } catch (e) {}
  setTimeout(() => {
    if (done) return; done = true;
    window.removeEventListener("message", onMsg);
    // F49-T 3부: 「미로드」와 「로드됐는데 늦음」과 「확장 갱신 후 미새로고침」을 가른다.
    var _st = _kgpMainWorldState();
    var tmCause = _st.ext_alive === false ? "확장이 갱신됐는데 이 탭을 새로고침하지 않음(격리 월드 끊김) — 새로고침 후 재측정"
      : (_st.main_marker ? "MAIN world 로드됨·응답 지연(900ms 타임아웃)"
                         : "MAIN world 스크립트가 이 페이지에서 실행되지 않음(주입 차단/실패)");
    try { console.warn("%c[고가수집기] Tier1 무동작 → DOM 폴백. 원인: " + tmCause, "color:#c2503c;font-weight:bold"); } catch (_) {}
    // v86-G: 이 경로도 진단을 **반드시** 실어 보낸다. 종전엔 여기서 tier1_diag가 아예 안 붙어,
    //   payload에 tier1 흔적이 없는 것이 곧 '미응답'인지 '진단 미부착'인지 판별 불가였다.
    try { isolated.tier1_diag = _kgpTier1Diag({}, "", false, tmCause); } catch (_) {}
    cb(isolated);   // MAIN world 미응답(비지원 크롬/타임아웃) → 격리월드 추출만(정직 폴백)
  }, 900);
}

// ── v86-I: 추출-저장 단일 권위 스토어 ──────────────────────────────────────
// 실측(오너 채점): 같은 분 테무 상세에서 **진단은 price/gallery/options/reviews 전부 tier1**인데
//   **서버 레코드는 title만 생존**(price=0·currency=USD·gallery 0·options 0)이었다. 탈락 집합이 정확히
//   tier1 비동기 필드였다. 갈래는 A(클릭 시점 tier1 미착지) 또는 B(payload가 진단과 다른 스토어 독출).
//   두 갈래 모두 **"클릭 시점에 같은 스토어를 다시 읽는다"** 로 덮인다 — 그래서 갈래 판별을 기다리지 않는다.
//
// 여기가 그 단일 진입점이다. 수집 payload도, 진단 export도 이 함수만 통과한다(별도 스냅샷·중복 직렬화 금지).
var KGP_TIER1_WAIT_MS = 700;    // 미착지 시 재독출까지 대기 상한(1회)
var KGP_TIER1_TRIES = 2;        // 최초 + 재독출 1회 — 무한 대기 금지(사용자를 세워두지 않는다)
var _kgpMetaStore = { meta: null, at: 0, tries: 0, echo: null };

// tier1 착지 판정 — 구조화 소스(tier1)가 **실제로 어떤 필드를 줬는가**로만 본다.
//   tier1_diag의 캡처 수로 판정하면 "잡았지만 추출에 안 쓰인" 경우를 착지로 오인한다.
function _kgpTier1Landed(meta) {
  var fs = (meta && meta.field_sources) || {};
  var keys = ["price", "images", "options", "reviews", "description"];
  for (var i = 0; i < keys.length; i++) if (fs[keys[i]] === "tier1") return true;
  return false;
}
// 통화 무가공 운반 — 빈 통화에 기본값(USD)을 **주입하지 않는다**. 빈 값은 빈 값으로 보내고 서버가 정직 표기.
//   다만 skus[].currency 공백은 상위 통화로 채운다(같은 상품인데 SKU만 통화 미상인 잔결함, 오너 칩).
function _kgpCarryCurrency(meta) {
  try {
    var top = String((meta && meta.currency) || "").trim();
    if (!top || !Array.isArray(meta.skus)) return;
    for (var i = 0; i < meta.skus.length; i++) {
      var s = meta.skus[i];
      if (s && typeof s === "object" && !String(s.currency || "").trim()) s.currency = top;
    }
  } catch (e) {}
}
// 마지막 전송 payload 요약(읽기 전용) — "추출은 됐는데 전송이 빔" 갈래를 진단만으로 가르는 근거.
function _kgpPayloadEcho(meta) {
  meta = meta || {};
  return {
    at: new Date().toISOString(),
    has_title: !!meta.title, has_price: !!meta.price,
    currency: meta.currency || "", currency_source: meta.currency_source || "",
    images_n: (meta.images || []).length, options_n: (meta.options || []).length,
    reviews_n: (meta.reviews || []).length, skus_n: (meta.skus || []).length,
    mode: meta.mode || "", tier1_pending: !!meta.tier1_pending,
    field_sources: meta.field_sources || null,
  };
}
// v86-L: echo 기록 단일 관문. 종전엔 FAB(handleFabClick)만 echo를 남겨, 호버 단건·벌크 경로
//   (collectBulk)로 수집하면 payload_echo=null이었다(오너 테무 실기기 결함 = 경로 분기 b).
//   모든 전송 경로가 이 함수를 통과하게 해 **어느 경로로 보냈든** echo가 남고, path enum으로
//   '어느 버튼이 보냈나'를, echoed_at으로 '언제 보냈나'를 진단 파일 하나로 판독한다.
//   path: "fab" | "hover" | "bulk" | "bulk-retry"(재시도). extra는 병합(예: {items_n}).
function _kgpRecordEcho(meta, path, extra) {
  try {
    var e = _kgpPayloadEcho(meta);
    e.path = path || "unknown";
    e.echoed_at = e.at;          // 명시적 별칭(판독 편의 — at은 유지)
    if (extra) for (var k in extra) if (Object.prototype.hasOwnProperty.call(extra, k)) e[k] = extra[k];
    _kgpMetaStore.echo = e;
  } catch (x) {}
}
// F49-T 2부-c: 보낸 것만 남기면 **서버가 어느 행에 무엇을 썼는지**를 모른다(03:21Z 실측 때 그 한 줄이 없었다).
//   서버 판정(새 행·중복·초안 채움·갱신)과 바뀐/남긴 필드 이름을 echo에 붙인다 — 값은 싣지 않는다.
function _kgpEchoServer(resp) {
  try {
    if (!_kgpMetaStore.echo || !resp) return;
    var keys = function (o) { return (o && typeof o === "object") ? Object.keys(o) : []; };
    _kgpMetaStore.echo.server = {
      ok: resp.ok === true, http: resp.httpStatus || null, item_id: resp.item_id || "",
      verdict: resp.draft_pending ? "draft" : (resp.enriched ? "draft-filled" : (resp.updated ? "updated"
        : (resp.duplicate ? "duplicate" : (resp.ok ? "new" : "error")))),
      changed: keys(resp.changed), kept: keys(resp.kept),
      message: String(resp.message || resp.error || "").slice(0, 120),
    };
  } catch (x) {}
}
// 클릭 시점 재독출. tier1이 아직 안 왔으면 **상한 내에서 한 번 더** 읽고, 그래도 없으면
//   조용히 빈 필드를 보내지 않고 tier1_pending + 간이(simple)로 정직 강등한다(v86-F 계보).
function kgpAcquireMeta(cb) {
  var tries = 0;
  var wait = true;
  try { wait = kgpPageType() === "single"; } catch (e) {}   // 목록에선 tier1이 원래 안 온다 — 지연 0
  function done(meta) {
    meta = meta || {};
    if (!_kgpTier1Landed(meta)) {
      meta.tier1_pending = true;
      // v86-V(3): tier1 미착지 ≠ 간이. 아마존 상세는 상태 JSON(tier1) 미캡처라도 buybox+DOM 어댑터가
      //   가격·옵션·리뷰를 채운 **tier2 full 추출**이다. 종전엔 tier1 미착지만 보고 mode='simple'로 과잉
      //   강등해 echo가 'simple인데 options·reviews 동봉'으로 라벨-내용 모순이었고, 서버(_resolve_collect_mode)는
      //   클라 simple을 그대로 신뢰해 '간이' 뱃지까지 붙었다. → 실제로 필드가 빈약할 때만 simple. 가격 +
      //   (옵션|리뷰|평점|SKU|상세≥20자)면 full 유지(tier1_pending으로 tier1 상태만 정직 표기). 'core'(북마클릿) 불변.
      var _rich = !!String(meta.price || "").trim() && (
          (meta.options || []).length || (meta.reviews || []).length ||
          String(meta.rating || "").trim() || (meta.skus || []).length ||
          String(meta.description || "").length >= 20);
      if (!_rich && String(meta.mode || "").toLowerCase() !== "core") meta.mode = "simple";
    }
    _kgpCarryCurrency(meta);
    _kgpMetaStore = { meta: meta, at: Date.now(), tries: tries, echo: _kgpMetaStore.echo };
    try { cb(meta); } catch (e) {}
  }
  function attempt() {
    tries++;
    kgpExtractMerged(function (meta) {
      if (!wait || _kgpTier1Landed(meta) || tries >= KGP_TIER1_TRIES) { done(meta); return; }
      try { console.warn("[고가수집기] tier1 미착지 — " + KGP_TIER1_WAIT_MS + "ms 후 재독출(" + tries + "/" + KGP_TIER1_TRIES + ")"); } catch (e) {}
      setTimeout(attempt, KGP_TIER1_WAIT_MS);
    });
  }
  attempt();
}

function handleFabClick(btn, opts) {
  opts = opts || {};
  if (btn._kgpDragged || btn.dataset.busy) return;
  setFabState(btn, "loading");
  // v57 STEP3: 상세 '더보기' 접힘을 먼저 펼친 뒤 추출(테무 상세이미지 전량) — 접힘 없으면 즉시 진행(지연 0).
  var _reveal = (typeof window.kgpRevealDetailFolds === "function")
    ? window.kgpRevealDetailFolds : function (cb) { cb && cb(); };
  _reveal(function () {
  // v86-I: 단일 권위 스토어 경유 — 클릭 시점 재독출 + tier1 미착지 시 상한 대기 후 재독출.
  kgpAcquireMeta(function (meta) {
  const corr = kgpNewCorr();
  meta.corr_id = corr;                    // 서버 로깅·알럿 dedupe 기준
  if (opts.force) meta.force = true;      // 다시 수집(덮어쓰기) — 가격·이미지 갱신
  // v49 STEP4 포렌식: 전송 직전 클라 추출 요약(어느 필드가 비었는지 콘솔에서 즉시 확인).
  try {
    console.log("[고가수집기] 전송요약", {
      price: meta.price, currency: meta.currency, images: (meta.images || []).length,
      desc: (meta.description || "").length + "자", options: (meta.options || []).length,
      reviews: (meta.reviews || []).length, rating: meta.rating, source: meta.source, partial: meta.partial,
    });
  } catch (e) { /* noop */ }
  // v86-I/L: 마지막 전송 payload 요약을 스토어에 남긴다(진단이 "무엇을 보냈나"). path="fab".
  _kgpRecordEcho(meta, "fab");
  kgpSendMessage({ action: "collect", meta }, (resp) => {
    setFabState(btn, "idle");
    _kgpEchoServer(resp);
    if (!resp || resp.ok !== true) {
      kgpAlertOnce(corr, () => {          // 실패 알럿도 건당 1회
        if (resp && resp.authRequired) {
          kgpToast("확장 옵션에서 토큰을 다시 설정해 주세요.\n(토큰이 만료됐거나 삭제됐어요)", false);
        } else {
          var _st = resp && resp.httpStatus ? ` (HTTP ${resp.httpStatus})` : "";
          kgpToast(((resp && resp.error) || "수집 실패") + _st, false);
        }
      });
      return;
    }
    // 다시 수집(덮어쓰기) 결과 — 가격·이미지 갱신됨(단일 메시지).
    if (resp.updated === true) {
      // F49-T 2부-c: 서버가 **무엇을** 갱신했는지 말한다(중복이어도 상위 출처면 갱신된다).
      kgpAlertOnce(corr, () => kgpResultToast(resp.message || "다시 수집 완료 — 가격·이미지를 갱신했어요", true,
        [{ label: "이력 열기", fn: kgpOpenHistory }]));
      return;
    }
    // 중복 — '이미 수집한 상품' 하나만(완료 토스트와 동시 출력 금지) + '다시 수집(덮어쓰기)'.
    if (resp.duplicate === true) {
      kgpAlertOnce(corr, () => kgpResultToast("이미 수집한 상품 — 이력에서 확인", true, [
        { label: "이력 열기", fn: kgpOpenHistory },
        { label: "다시 수집(덮어쓰기)", fn: () => handleFabClick(btn, { force: true }) },
      ]));
      return;
    }
    // v47/v49 STEP2·5: 서버 필드 상태(성공/부분/실패)로 정직 표기 — 무음 실패·가짜 성공 금지.
    //   서버 field_status가 단일 소스. 없으면(구서버) 클라 meta.partial 폴백.
    var fs = resp.field_status || null;
    // v84.1 STEP A(P0): 품절 상품은 저장하지 않는다 — 등록해도 팔 물건이 없고, 품절 DP는 가격 오염
    //   (장바구니 합계 등)이 잦다. unknown은 차단하지 않는다(확신 없는 차단 금지).
    if (meta && meta.stock_status === "out_of_stock") {
      kgpAlertOnce(corr, () => kgpCollectCard(
        "품절 상품이라 수집하지 않았어요\n재입고되면 다시 수집해 주세요", false,
        [{ label: "이력 열기", fn: kgpOpenHistory }]));
      return;
    }
    // v49 STEP5: 실패(핵심 3 전부 미확보) — 원인 명시, 축하 없음.
    if (fs && fs.status === "실패") {
      try { console.warn("[고가수집기] 수집 실패 —", fs.cause || "핵심 정보 미확보"); } catch (e) {}
      kgpAlertOnce(corr, () => kgpResultToast(
        "수집 실패 — " + (fs.cause || "핵심 정보(제목·가격·이미지)를 못 읽었어요") + "\n드로어에서 직접 입력하거나 다시 시도하세요",
        false, [{ label: "이력 열기", fn: kgpOpenHistory }]));
      return;
    }
    var isPartial = fs ? (fs.status === "부분") : !!(meta && meta.partial);
    if (isPartial) {
      var _ml = fs && ((fs.missing_short && fs.missing_short.length) ? fs.missing_short : fs.missing);
      var miss = (_ml && _ml.length) ? _ml.join("·") : "";
      try { console.warn("[고가수집기] 부분 수집 — 누락:", (fs && fs.missing) || (meta && meta.warnings) || []); } catch (e) {}
      var _msg = miss
        ? ("부분 수집 — " + miss + " 누락 (" + (fs.filled) + "/" + (fs.total) + " 필드)\n드로어에서 확인·보완하세요")
        : "부분 수집 — 페이지에서 정보를 충분히 못 읽었어요.\n드로어에서 가격·이미지를 확인·보완하세요";
      kgpAlertOnce(corr, () => kgpResultToast(_msg, false, [{ label: "이력 열기", fn: kgpOpenHistory }]));
      return;
    }
    // 성공 — '수집 완료(N/7 필드)' 하나만 + 축하 스탬프(토스트는 하나). 가격 경고 있으면 함께 안내.
    kgpAlertOnce(corr, () => {
      var _warn = (meta && Array.isArray(meta.warnings) && meta.warnings.length) ? "\n⚠ " + meta.warnings[0] : "";
      var _cnt = fs ? (" (" + fs.filled + "/" + fs.total + " 필드)") : "";
      // v58 STEP3: 확장 버전 스탬프(죽은 버전 혼동 차단) — 매니페스트 버전 표기.
      var _ev = "";
      try { _ev = " · ext v" + (chrome.runtime.getManifest && chrome.runtime.getManifest().version || ""); } catch (e) {}
      kgpCelebrate(1, true);           // 축하 스탬프(상단) + 누적 카운트 — silent(토스트 없음)
      // v82 STEP4: 결과는 우측 상단 1/3 수집 카드로(우하단 토스트 폐기 → 장바구니 버튼 가림 근치).
      //   카드는 등장 시 확장(Pop in) → 3초 후 pill 수렴(토스트·카드 중복 노출 금지).
      // v83 STEP1: 구글 번역 상태로 보고 있으면 알린다 — 통화·문구는 **원문 기준**으로 저장했음을 명시(오해 차단).
      var _tr = (meta && meta.translated_dom) ? "\n번역된 페이지 — 원문 기준으로 저장했어요" : "";
      // v83.1 STEP1: 이번 수집에 **실제로** 번역이 적용됐는지 — 서버가 확인한 값만 쓴다(가짜 '번역됨' 금지).
      //   서버 resp.translated=true면 번역 성공, 토글 OFF면 원문 저장, 그 외(키 미설정 등)는 언급하지 않는다.
      var _ko = resp.translated ? "\n한국어 번역 완료" : (KGP_TRANSLATE ? "" : "\n원문 그대로 저장했어요");
      kgpCollectCard("수집 완료" + _cnt + _ev + " — 이력에서 확인" + _ko + _tr + _warn, true, [{ label: "이력 열기", fn: kgpOpenHistory }]);
    });
  });
  });   // v47 STEP4: kgpExtractMerged 콜백 닫기
  });   // v57 STEP3: kgpRevealDetailFolds 콜백 닫기
}

function injectCollectButton() {
  // v16 P1: FAB off면 표시 안 함 — 단, v17: 앱에서 띄운 진입 세션이면 강제 노출.
  if (!KGP_FAB_ENABLED && !kgpEntrySession()) { kgpRemoveFab(); return; }
  if (!kgpHostAllowed() && !kgpEntrySession()) return;   // 지정 소싱처 또는 앱 진입 세션(v10/v17)
  if (document.getElementById(KGP_BTN_ID)) return;
  if (window.top !== window.self) return;       // iframe 안에서는 표시 안 함
  if (!document.body) return;
  // v38 #4: 지정 소싱처(또는 앱 진입)에서는 상품 페이지 휴리스틱과 무관하게 '항상' 노출.
  //   기존엔 looksLikeProductPage/디테일 URL 가드 때문에 SPA(Temu)·카테고리·검색·홈에서 버튼이 안 떠
  //   "어떤 창은 안 뜸"이 발생. 이미 host 게이트(위)로 소싱처에 한정되므로 추가 가드는 제거한다.

  // v86 STEP1: **<button>은 shadow 호스트가 될 수 없다**(Chrome은 div/span/section 등 일부 태그만 허용) —
  //   attachShadow가 던져 라이트 DOM 폴백으로 조용히 새던 것을 CI 가시성 계약이 잡았다. div+role=button으로.
  const btn = document.createElement("div");
  btn.id = KGP_BTN_ID;
  btn.setAttribute("role", "button");
  btn.setAttribute("tabindex", "0");
  // 모양은 shadowRoot 안에서 그린다(페이지 CSS 격리는 shadow 경계가 담당).
  const _fabCss =
    ".w{display:flex;align-items:center;gap:10px;box-sizing:border-box;max-width:min(82vw,300px);" +
    "padding:9px 16px 9px 10px;border:1px solid #c9a24b;border-radius:999px;background:#1a1714;color:#f5efe3;" +
    "font:14px/1 -apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;cursor:pointer;" +
    "box-shadow:0 6px 20px rgba(0,0,0,.4),0 0 0 4px rgba(17,154,142,.10);transition:transform .12s,box-shadow .12s}" +
    ".w:hover{transform:translateY(-2px);box-shadow:0 10px 26px rgba(0,0,0,.5),0 0 0 5px rgba(17,154,142,.18)}" +
    ".g{display:flex;align-items:center;justify-content:center;width:28px;height:28px;flex-shrink:0}" +
    ".g svg{display:block;width:22px;height:22px}" +
    ".t{display:flex;flex-direction:column;align-items:flex-start;line-height:1.12}" +
    ".kgp-fab-label{font-weight:700;font-size:14px;line-height:1.1;color:#f5efe3;white-space:nowrap}" +
    ".kgp-fab-sub{font-size:10px;line-height:1.1;color:#c9a24b;font-family:Georgia,'Times New Roman',serif;white-space:nowrap}";
  const _fabHtml =
    '<div class="w" part="btn"><span class="g">' + KGP_BRIDGE_SVG + '</span>' +
    '<span class="t"><span class="kgp-fab-label">고가수집기</span><span class="kgp-fab-sub"></span></span></div>';
  const _fabRoot = _kgpShadowHost(btn, _fabCss, _fabHtml);
  if (!_fabRoot) {
    // shadow 미지원(구형) — 라이트 DOM 폴백. all:initial은 쓰지 않는다(가시성 우선).
    btn.innerHTML = '<span class="g">' + KGP_BRIDGE_SVG + '</span>' +
      '<span class="t"><span class="kgp-fab-label">고가수집기</span><span class="kgp-fab-sub"></span></span>';
    btn.style.cssText = "display:flex;align-items:center;gap:10px;padding:9px 16px 9px 10px;" +
      "border:1px solid #c9a24b;border-radius:999px;background:#1a1714;color:#f5efe3;cursor:pointer;" +
      "font:14px/1 -apple-system,sans-serif";
  }
  kgpApplyTranslateCopy(btn);   // v83.1 STEP1: 부제·title을 번역 토글 상태에 맞춰 세팅
  kgpEnsureStyles();            // v84 STEP1: 주입 시점에 스타일 보장
  // v86 STEP1: 호스트에는 **위치 계열만** — all:initial 인라인 전개 폐기(가시성 원천 복구).
  btn.style.setProperty("background", "transparent", "important");
  btn.style.setProperty("border", "0", "important");
  btn.style.setProperty("padding", "0", "important");
  btn.style.setProperty("margin", "0", "important");
  btn.style.setProperty("width", "auto", "important");
  btn.style.setProperty("height", "auto", "important");
  btn.style.setProperty("min-width", "0", "important");
  btn.style.setProperty("line-height", "normal", "important");
  _kgpPinFixed(btn, { right: "16px", top: "calc(50% - 24px)" });   // position/z-index/오프셋
  btn.addEventListener("click", () => handleFabClick(btn));
  btn.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); handleFabClick(btn); } });
  _kgpMount(btn);                            // v45 P5: <html> 직속(본문 재렌더에도 상시 표시)
  kgpMakeDraggable(btn, "kgp_fab_pos");      // 드래그 이동 + 위치 기억(v7)

  // 처음 등장 시 한 번 살짝 강조(인지성↑, 과하지 않게). reduced-motion이면 생략.
  if (!KGP_RM) {
    btn.animate(
      [{ transform: "scale(1)" }, { transform: "scale(1.06)" }, { transform: "scale(1)" }],
      { duration: 600, iterations: 2, easing: "ease-in-out" }
    );
  }
}

// ---------------------------------------------------------------------------
// 리스팅/검색 페이지 다중 상품 수집 (Phase 221)
// 상품 카드마다 '수집' 체크 배지 + 상단 툴바(전체선택/선택수집/전체수집).
// 확장 background가 토큰으로 서버에 전송하므로 페이지 CSP 영향 없음.
// ---------------------------------------------------------------------------
const KGP_TOOLBAR_ID = "kgp-listing-toolbar";
const KGP_SELECTED = new Set();   // 선택된 상품 url 집합(재스캔에도 유지)
let _kgpCards = [];
let _kgpCardByUrl = {};           // url → 카드 데이터(el 포함) — 재스캔 시 '병합'(절대 비우지 않음)
let _kgpScannedCount = 0;         // 마지막 스캔에서 본 후보 카드 총수(상품 M개 / 전체 N개 표기용)
let _kgpClosed = false;           // 사용자가 툴바를 닫았으면 자동 재생성 안 함(같은 URL 동안)

// ── F49-T 4부: 목록 **지속 감시** 엔진(전 소싱처 공통 — 사이트 어댑터가 아니라 여기) ──────────────
//   오너 실측(world.taobao): 스크롤로 붙은 카드엔 hover 버튼이 없고 「전체 선택」이 안 먹었다. 「전체 선택」은
//   DOM에 이미 있는 체크박스만 돌았다 — 탐지는 됐는데 체크박스가 아직 없는 카드는 영영 선택되지 않았다.
//   선택은 이제 **상품 키**(_kgpCardKey — ASIN·goods·tb id) 기준이라 재렌더(가상 스크롤)돼도 유지된다.
const _kgpSelKeys = new Set();
const KGP_WATCH = { scan_count: 0, last_scan_at: "", last_scan_ms: 0, max_scan_ms: 0, cards_total: 0,
                    cards_tiled: 0, observer_alive: false, containers: 0, new_cards: 0, lazy: false, lazy_pending: 0 };
let _kgpInitialKeys = null;       // 첫 목록 스캔에서 본 상품 키 — 「새 상품 +N」의 기준
let _kgpWatchContainersEls = [];  // 지금 감시 중인 카드 컨테이너
let _kgpRescanHook = null;        // 재스캔(디바운스) — 컨테이너 옵저버가 부른다
let _kgpBodyObserved = false;
const _kgpContainerMO = { mo: null, els: [] };
// 컨테이너 전용 MutationObserver(childList+subtree) — 컨테이너가 통째로 교체되면(가상 스크롤·SPA) 다시 잡는다.
function _kgpWatchObserveContainers() {
  try {
    const els = _kgpWatchContainersEls.filter((e) => e && e.isConnected);
    const same = els.length === _kgpContainerMO.els.length && els.every((e, i) => e === _kgpContainerMO.els[i]);
    if (!same) {
      if (_kgpContainerMO.mo) _kgpContainerMO.mo.disconnect();
      _kgpContainerMO.mo = new MutationObserver(() => { if (_kgpRescanHook) _kgpRescanHook(); });
      els.forEach((e) => _kgpContainerMO.mo.observe(e, { childList: true, subtree: true }));
      _kgpContainerMO.els = els;
    }
    KGP_WATCH.observer_alive = !!(_kgpContainerMO.mo && els.length) || _kgpBodyObserved;
  } catch (e) { KGP_WATCH.observer_alive = _kgpBodyObserved; }
}
function _kgpIsSel(url) {
  if (KGP_SELECTED.has(url)) return true;
  try { return _kgpSelKeys.has(_kgpCardKey(url)); } catch (e) { return false; }
}
function _kgpDetectedKeys() {
  const keys = new Set();
  Object.keys(_kgpCardByUrl).forEach((u) => { try { keys.add(_kgpCardKey(u)); } catch (e) {} });
  return keys;
}
function _kgpWatchSite() {
  const h = (location.hostname || "").toLowerCase();
  const m = h.match(/(taobao|tmall|1688|amazon|rakuten|aliexpress|temu|yoshidakaban|iherb|qoo10|mercari)/);
  return m ? m[1] : "generic";
}
// 카드 컨테이너 — ① 원격 규칙(list_watch.container.<사이트>, 셀렉터 드리프트는 재설치 없이) ② 없으면
//   탐지된 메인 카드들의 **공통 부모**(카드 3장 이상 품은 것, 많은 순 최대 3개).
function _kgpResolveContainers(cards) {
  let out = [];
  const sel = String(_kgpRule("list_watch.container." + _kgpWatchSite(), "") || "");
  if (sel) { try { document.querySelectorAll(sel).forEach((el) => out.push(el)); } catch (e) { out = []; } }
  if (!out.length) {
    const cnt = new Map();
    (cards || []).forEach((c) => {
      if (!c || !c.el || c.region === "reco") return;
      const p = c.el.parentElement;
      if (p) cnt.set(p, (cnt.get(p) || 0) + 1);
    });
    out = Array.from(cnt.entries()).filter((e) => e[1] >= 3).sort((a, b) => b[1] - a[1]).slice(0, 3).map((e) => e[0]);
  }
  return out;
}
function _kgpSig(el) {
  try {
    const cls = String((el.className && el.className.baseVal !== undefined) ? el.className.baseVal : (el.className || ""))
      .split(/\s+/).filter((t) => t && !/\d{3,}/.test(t)).sort().join(".");
    return el.tagName + "|" + cls;
  } catch (e) { return ""; }
}
// 컨테이너의 새 자식 중 **이미 탐지된 카드와 같은 모양**(태그+클래스 서명)이고 상품 링크·이미지가 있는 것 —
//   어댑터 셀렉터가 새로 붙은 카드의 마크업을 놓쳐도(무한 스크롤 뒤 클래스 변형) 여기서 잡는다.
function _kgpContainerSiblingCards(merged, containers) {
  const extra = [];
  if (!containers.length) return extra;
  const known = new Set((merged || []).map((c) => c && c.el).filter(Boolean));
  const keys = new Set((merged || []).map((c) => { try { return _kgpCardKey(c.url); } catch (e) { return ""; } }));
  const tb = (typeof _kgpIsTaobaoHost === "function") && _kgpIsTaobaoHost((location.hostname || "").toLowerCase());
  containers.forEach((box) => {
    const sigCount = {};
    let n = 0;
    Array.prototype.forEach.call(box.children, (ch) => { if (known.has(ch)) { const s = _kgpSig(ch); sigCount[s] = (sigCount[s] || 0) + 1; n++; } });
    if (n < 3) return;
    const okSig = Object.keys(sigCount).filter((s) => sigCount[s] / n >= 0.6);
    if (!okSig.length) return;
    Array.prototype.forEach.call(box.children, (ch) => {
      try {
        if (known.has(ch) || okSig.indexOf(_kgpSig(ch)) < 0) return;
        if (ch.querySelector && ch.querySelector(".kgp-card-chk")) return;
        const a = (ch.tagName === "A") ? ch : ch.querySelector("a[href]");
        if (!a) return;
        const raw = a.getAttribute("href") || a.href || "";
        const url = tb ? _kgpTaobaoItemHref(raw) : (_kgpIsProductHref(raw) ? new URL(raw, location.href).href : "");
        if (!url) return;
        const k = _kgpCardKey(url);
        if (keys.has(k)) return;
        const img = _kgpCardImage(ch) || ch.querySelector("img");
        if (!img) return;
        const titleEl = ch.querySelector("[class*='title' i], [class*='name' i], h2, h3");
        let title = titleEl ? (titleEl.innerText || titleEl.textContent || "").trim() : "";
        if (!title && img.alt) title = img.alt.trim();
        const pr = _kgpPrice(ch.innerText || ch.textContent || "");
        const bimg = _kgpBestImg(img) || img.src || "";
        keys.add(k);
        extra.push({ url: url, title: (title || "(제목 없음)").replace(/\s+/g, " ").slice(0, 200), image: bimg,
                     images: bimg ? [bimg] : [], price: pr.price, currency: pr.currency || "", region: "main",
                     el: ch, via: "container" });
      } catch (e) { /* noop */ }
    });
  });
  return extra;
}
// v65 STEP2: 제외 사유별 분해 카운트('제외 (광고 등)' 뭉뚱그림 금지). 스캔마다 초기화.
//   ad=광고(스폰서, 태깅만·전체선택 제외) · region=비상품영역(추천/푸터) · parse=카드 파싱 실패(제목/ASIN 등)
//   · url=URL 추출 실패(앵커 없음) · dup=중복(같은 상품).
let _kgpExcl = { ad: 0, region: 0, parse: 0, url: 0, dup: 0, reco: 0 };
function _kgpExclReset() { _kgpExcl = { ad: 0, region: 0, parse: 0, url: 0, dup: 0, reco: 0 }; }

// v77 STEP2: 미부착(자격 탈락) 타일 자가보고 — 타일에 data-kgp-skip="사유" 부여 + 사유별 카운트 집계.
//   사유: non-product(구조적 비상품)·no-asin/no-url(식별자 없음)·parse-fail(제목·이미지 없음)·dup(중복)·ad-excluded.
//   "왜 이 타일만 버튼이 없지?"를 속성 하나로 판독 + 디버그 패널(진단 번들 excl/skipStats)에 집계.
let _kgpSkipStats = {};
function _kgpSkipReset() { _kgpSkipStats = {}; }
function _kgpMarkSkip(el, reason) {
  try {
    if (!el || !el.setAttribute) return;
    el.setAttribute("data-kgp-skip", reason);
    _kgpSkipStats[reason] = (_kgpSkipStats[reason] || 0) + 1;
  } catch (e) {}
}
function _kgpClearSkip(el) { try { if (el && el.removeAttribute) el.removeAttribute("data-kgp-skip"); } catch (e) {} }

// v64 STEP2 / v67 STEP1: 전체선택/전체수집 대상 — 기본은 **메인 그리드 실상품만**(추천·광고 제외).
//   '추천 포함'(kgp_incl_reco)·'광고 포함'(kgp_incl_ads) 토글로 확장. 버튼은 전 타일에 부착돼 개별 수집은 항상 가능.
function _kgpInclAds() { return kgpLSget("kgp_incl_ads", "0") === "1"; }
function _kgpInclReco() { return kgpLSget("kgp_incl_reco", "0") === "1"; }
function _kgpSelectableUrls() {
  const inclAds = _kgpInclAds(), inclReco = _kgpInclReco();
  const seen = new Set();
  return Object.keys(_kgpCardByUrl).filter((u) => {
    const c = _kgpCardByUrl[u];
    if (c && c.sponsored && !inclAds) return false;
    if (c && c.region === "reco" && !inclReco) return false;
    let k = u;
    try { k = _kgpCardKey(u); } catch (e) {}
    if (seen.has(k)) return false;          // F49-T 4부: 같은 상품 한 번만(재스캔 URL 변형)
    seen.add(k);
    return true;
  });
}
function _kgpAdCount() {
  return Object.keys(_kgpCardByUrl).filter((u) => _kgpCardByUrl[u] && _kgpCardByUrl[u].sponsored).length;
}
function _kgpRecoCount() {
  return Object.keys(_kgpCardByUrl).filter((u) => _kgpCardByUrl[u] && _kgpCardByUrl[u].region === "reco").length;
}
function _kgpMainCount() {
  // F49-T 4부: 같은 상품이 재스캔마다 다른 URL 형태로 잡혀도 한 번만 센다(상품 키).
  const keys = new Set();
  Object.keys(_kgpCardByUrl).forEach((u) => {
    const c = _kgpCardByUrl[u];
    if (c && c.region !== "reco" && !c.sponsored) { try { keys.add(_kgpCardKey(u)); } catch (e) { keys.add(u); } }
  });
  return keys.size;
}

function _kgpIsCnyHost(h) { return /(^|\.)(taobao|tmall|1688)\.com$/i.test(String(h || "")); }
function _kgpIsTaobaoHost(h) { return /(^|\.)(taobao|tmall)\.com$/i.test(String(h || "")); }
function _kgpPrice(text) {
  // v87-#597: 라쿠텐 리스트 타일 가격은 '1,706円'(엔 한자 접미) — 종전 정규식이 '원'·'¥'만 잡아 円 누락.
  //   円 접미(→JPY)를 추가해 타일 가격을 채운다. 감지(keep-set)는 불변 — 가격 필드만 채움. 없으면 빈값(날조 0).
  // F49-T 3부: 중국 사이트는 전각 ￥를 쓴다 — 그것도 가격 기호로 잡는다.
  const m = String(text || "").match(/([\d][\d.,]{1,})\s*(?:원|円)|(?:₩|\$|¥|￥|€|£)\s*([\d][\d.,]{1,})/);
  if (!m) return { price: "", currency: "" };
  const raw = (m[1] || m[2] || "").replace(/,/g, "");
  let cur = "";
  if (/円/.test(m[0])) cur = "JPY";
  else if (/원|₩/.test(m[0])) cur = "KRW";
  else if (/\$/.test(m[0])) cur = "USD";
  // F49-T 3부: ¥는 엔과 위안이 같은 기호다. 타오바오·티몰·1688에서는 위안(CNY) — 엔으로 적으면
  //   목록 수집이 JPY로 저장되고 상세의 「표시 통화(JPY)」 경고로 번진다(오너 실측).
  else if (/[¥￥]/.test(m[0])) cur = (typeof _kgpIsCnyHost === "function" && typeof location !== "undefined"
                                    && _kgpIsCnyHost(location.hostname)) ? "CNY" : "JPY";
  else if (/€/.test(m[0])) cur = "EUR";
  else if (/£/.test(m[0])) cur = "GBP";
  return { price: raw, currency: cur };
}

// ---------------------------------------------------------------------------
// v10 P0 — 지정 소싱처에서만 노출 (아무 사이트 ✕).
//   기본셋(ON) + 사용자 지정 도메인(옵션에서 추가/삭제). 비매치 사이트엔 아무것도 안 그림.
// ---------------------------------------------------------------------------
// v81 STEP3: 소싱처 레지스트리는 kgp-sources.js(단일 진실원천)에서 파생 — 팝업/콘텐츠스크립트 drift 봉인.
//   manifest content_scripts가 kgp-sources.js를 content_script.js보다 먼저 로드(KGPSources 전역 보장).
//   .test(h) 인터페이스 유지(하위 fast-path 호환) — .re 기반 레지스트리를 어댑터로 감싼다.
const _KGP_LEGACY_SOURCES = [
  { id: "taobao", label: "타오바오", test: (h) => /(^|\.)taobao\.com$/.test(h) },
  { id: "tmall", label: "티몰", test: (h) => /(^|\.)tmall\.com$/.test(h) },
  { id: "1688", label: "1688", test: (h) => /(^|\.)1688\.com$/.test(h) },
  { id: "temu", label: "테무", test: (h) => /(^|\.)temu\.com$/.test(h) },
  { id: "amazon", label: "아마존", test: (h) => /(^|\.)amazon\.[a-z]{2,3}(\.[a-z]{2,3})?$/.test(h) },
  { id: "aliexpress", label: "알리익스프레스", test: (h) => /(^|\.)aliexpress\.[a-z]{2,3}(\.[a-z]{2,3})?$/.test(h) },   // v83 STEP2: 국가 도메인 와일드카드
  { id: "iherb", label: "아이허브", test: (h) => /(^|\.)iherb\.com$/.test(h) },
  { id: "dhgate", label: "DHgate", test: (h) => /(^|\.)dhgate\.com$/.test(h) },
  { id: "qoo10", label: "큐텐", test: (h) => /(^|\.)qoo10\.[a-z.]+$/.test(h) },
  { id: "mercari", label: "메루카리", test: (h) => /(^|\.)mercari\.com$/.test(h) },
  { id: "rakuten", label: "라쿠텐(Rakuten Fashion 포함)", test: (h) => /(^|\.)rakuten\.(co\.jp|com)$/.test(h) },
  { id: "yahoo", label: "야후쇼핑(재팬)", test: (h) => /(shopping\.yahoo\.co\.jp|paypaymall\.yahoo\.co\.jp)$/.test(h) },
  { id: "yoshida", label: "요시다카반", test: (h) => /(^|\.)yoshidakaban\.com$/.test(h) },
  { id: "oliveyoung", label: "올리브영", test: (h) => /(^|\.)oliveyoung\.co\.kr$/.test(h) },          // R1 한국 소싱처
  { id: "smartstore", label: "스마트스토어", test: (h) => /^(m\.)?(smartstore|brand)\.naver\.com$/.test(h) },
  { id: "coupang", label: "쿠팡", test: (h) => /^(www\.|m\.)?coupang\.com$/.test(h) },
];
const KGP_DEFAULT_SOURCES = (typeof KGPSources !== "undefined" && KGPSources.SOURCES)
  ? KGPSources.SOURCES.map((s) => ({ id: s.id, label: s.label, test: (h) => s.re.test(h) }))
  : _KGP_LEGACY_SOURCES;
let KGP_SOURCES = null;   // chrome.storage의 사용자 설정 { defaults:{id:bool}, custom:[{host,on}] }
let KGP_FAB_ENABLED = true;   // v16 P1: 인페이지 수집 버튼(FAB) on/off (popup 토글, 기본 ON)
// v83.1 STEP1: 한국어 번역 on/off (팝업·수집 카드 공용 토글, 기본 ON). 실제 페이로드 주입은 background가
//   단일 관문에서 하고, 여기서는 **문구 동기화**(FAB 부제·title, 카드 안내)만 담당한다.
let KGP_TRANSLATE = true;

// v17 P0: 우리 앱에서 띄운 마켓/소싱처 진입이면(URL 마커 kgpsrc=app) 그 탭 세션 동안 수집기를
// 강제 노출한다(유저가 FAB를 off 했어도 진입 세션엔 보장). 마커는 sessionStorage로 SPA 이동에도 유지.
function kgpEntrySession() {
  try {
    if (/[?&]kgpsrc=app\b/.test(location.search || "")) sessionStorage.setItem("kgp_entry", "1");
    return sessionStorage.getItem("kgp_entry") === "1";
  } catch (e) { return false; }
}

function _kgpHostMatch(host, domain) {
  domain = String(domain || "").toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*$/, "").replace(/^www\./, "");
  if (!domain) return false;
  return host === domain || host.endsWith("." + domain);
}

// 현재 사이트가 '지정 소싱처'인가? — v81 STEP3: kgp-sources.js(단일 소스)에 위임(팝업과 동일 판정).
function kgpHostAllowed() {
  const host = (location.hostname || "").toLowerCase();
  if (!host) return false;
  const s = KGP_SOURCES || {};
  if (typeof KGPSources !== "undefined" && KGPSources.allowed) {
    try { return KGPSources.allowed(host, s); } catch (e) {}
  }
  // 폴백(KGPSources 미로드) — 레지스트리 어댑터로 동일 규칙.
  const defs = s.defaults || {};
  for (const src of KGP_DEFAULT_SOURCES) {
    if (defs[src.id] !== false && src.test(host)) return true;
  }
  for (const c of (s.custom || [])) {
    if (c && c.on !== false && _kgpHostMatch(host, c.host)) return true;
  }
  return false;
}

// ---------------------------------------------------------------------------
// v10 P0 — 실제 제품만 감지. 사이트 어댑터(정확) + 엄격 휴리스틱(폴백).
//   썸네일·추천레일·"본 적 있음"·캐러셀·푸터·광고 제외. "N개 발견" = 실제 수집 가능 수.
// ---------------------------------------------------------------------------
// 카드가 추천/푸터/캐러셀/광고 같은 '제품 그리드 아님' 영역에 속하면 제외.
// v64 STEP2: 구조적 비상품 영역(추천/캐러셀/푸터)과 광고 영역을 분리.
//   opts.allowAds=true면 sponsor/ad/promo/deal 토큰으로 '영역 제외'하지 않는다 — 아마존
//   스폰서는 실상품이므로 명시 신호(_kgpAmazonSponsored)로 '태깅'만 하고 카드는 살린다
//   (과잉 휴리스틱 제외 = 66중 48 오제외의 근본 원인 제거). 구조적 비상품은 여전히 제외.
function _kgpInBadRegion(el, opts) {
  opts = opts || {};
  const structRe = /(footer|recommend|related|carousel|slider|viewed|recently|history|also-?viewed|also-?bought|similar|banner|rcmd)/;
  const adRe = /(sponsor|advert|\bads?\b|promo|deal-?strip)/;
  let n = el;
  for (let i = 0; n && i < 9; i++, n = n.parentElement) {
    let cls = "";
    try { cls = (typeof n.className === "string" ? n.className : (n.getAttribute && n.getAttribute("class")) || ""); } catch (e) { cls = ""; }
    const tag = (n.tagName || "").toLowerCase();
    const meta = ((n.id || "") + " " + cls + " " + ((n.getAttribute && (n.getAttribute("aria-label") || n.getAttribute("data-component-type"))) || "")).toLowerCase();
    if (tag === "footer" || tag === "header" || tag === "nav") return true;
    // v67 STEP1: structuralOnly면 추천/캐러셀은 '제외' 안 함(전 타일 버튼 부착 — region 태깅으로 카운트만 구분).
    if (!opts.structuralOnly && structRe.test(meta)) return true;
    if (!opts.allowAds && adRe.test(meta)) return true;   // 광고 영역 제외(아마존은 allowAds로 유지)
  }
  return false;
}

// v67 STEP1: 카드가 추천/캐러셀/frequently-viewed 영역인지(제외 아님 — region='reco' 태그용).
function _kgpIsRecoRegion(el) {
  const recoRe = /(recommend|related|carousel|slider|viewed|recently|also-?viewed|also-?bought|similar|frequently|rcmd|sponsored-products|p13n|cross-?sell|up-?sell|you-?may)/i;
  let n = el;
  for (let i = 0; n && i < 9; i++, n = n.parentElement) {
    let cls = "";
    try { cls = (typeof n.className === "string" ? n.className : (n.getAttribute && n.getAttribute("class")) || ""); } catch (e) { cls = ""; }
    const meta = ((n.id || "") + " " + cls + " " + ((n.getAttribute && (n.getAttribute("aria-label") || n.getAttribute("data-component-type"))) || "")).toLowerCase();
    if (recoRe.test(meta)) return true;
  }
  return false;
}

// v41 X-1: 리스팅 카드의 대표 이미지가 lazy-load placeholder(빈/공용 src)라, 스크롤 전엔
// 여러 상품이 같은 placeholder src를 공유 → '상품 A에 상품 B 이미지'가 붙는 문제.
// 실제 이미지 소스(currentSrc·data-src·srcset 등)를 우선 선택해 상품별 '자기 이미지'로 귀속.
function _kgpBestImg(img) {
  if (!img) return "";
  const _isPlaceholder = (s) => !s || s.indexOf("data:") === 0 ||
    /(1x1|blank|spacer|placeholder|loading|transparent\.|pixel|lazy(load)?[-_.]|grey\.gif|gray\.gif|s\.gif)/i.test(s);
  const cand = [
    img.currentSrc || "",
    img.getAttribute("data-src") || "",
    img.getAttribute("data-original") || "",
    img.getAttribute("data-lazy") || "",
    img.getAttribute("data-lazy-src") || "",
  ];
  const ss = img.getAttribute("srcset") || img.getAttribute("data-srcset") || "";
  if (ss) {
    const parts = ss.split(",");
    cand.push((parts[parts.length - 1] || "").trim().split(" ")[0]);
  }
  cand.push(img.src || "");   // 마지막 폴백(placeholder일 수 있음)
  for (const c of cand) { if (c && !_isPlaceholder(c)) return c; }
  return img.currentSrc || img.src || "";   // 전부 placeholder면 그거라도(정직: 서버가 이후 보강/빈값)
}

// 스폰서(광고) 카드 판별 — 클래스/라벨 기반(보수적, 오탐 최소).
function _kgpAmazonSponsored(el) {
  try {
    if (el.querySelector('.s-sponsored-label-text, .puis-sponsored-label-text, [data-component-type="sp-sponsored-result"], [aria-label*="Sponsored"], [data-component-type="s-sponsored-label-info-icon"]')) {
      return true;
    }
  } catch (e) { /* noop */ }
  return false;
}

// 아마존 검색결과 어댑터 — 실제 '상품' 카드(유효 ASIN + 상품URL). 뮤직/앱/미디어 위젯 제외.
// v25 P0: data-asin(10자) 필수로 비-상품 위젯 제외.
// v45 P3: '버튼이 카드마다 있다 없다' 해소 — 셀렉터를 s-search-result만이 아니라 **유효 data-asin을
//   가진 카드 전부**로 넓히고(레이아웃 변형·스폰서 컨테이너 커버), **스폰서(광고) 상품도 포함**한다
//   (유효 ASIN=실제 소싱 가능 상품). 비-상품 미디어(ASIN 없음)는 자연 제외 = v25 '광고·미디어 제외' 의도 유지.
// v86-B: 아마존 스폰서(sspa) 링크의 목적지는 **URL 안에 평문으로** 있다 —
//   /sspa/click?…&url=%2FComfortable-Magnetic…%2Fdp%2FB0FJM1FRNZ%2Fref%3D…
//   (라쿠텐 redirect_rpp의 불투명 토큰과 다르다 → 리다이렉트 추적·서버 호출 없이 해석 가능.)
//   기존 코드가 href를 split("?")[0]로 잘라 이 payload를 통째로 버려서 **모든 광고 타일이
//   https://…/sspa/click 하나로 붕괴** → 첫 건만 채택되고 나머지가 전부 'dup'으로 떨어졌다.
function _kgpAmazonSspaAsin(rawHref) {
  try {
    var u = new URL(rawHref || "", location.href);
    if (u.pathname.indexOf("/sspa/click") < 0) return "";
    var t = u.searchParams.get("url") || "";
    var m = decodeURIComponent(t).match(/\/dp\/([A-Z0-9]{10})/);
    return m ? m[1] : "";
  } catch (e) { return ""; }
}
function _kgpAmazonCards() {
  const cards = [], seen = {};
  // v67 STEP1: **전 타일 버튼(대형 셀러툴 패리티)** — 메인 그리드뿐 아니라 추천 캐러셀·frequently-viewed
  //   배너 타일에도 버튼 부착. 메인/추천 구분은 region 태그로(카운트 표시에만). 구조적 비상품(footer/nav)만 제외.
  const mainSlot = (document.querySelector && document.querySelector('.s-main-slot, [data-component-type="s-search-results"]')) || null;
  const set = new Set();
  document.querySelectorAll('[data-component-type="s-search-result"], div[data-asin]:not([data-asin=""])')
    .forEach((e) => set.add(e));
  const all = Array.from(set);
  _kgpScannedCount = all.length;                          // '전체 N개'(메인+추천 상품/비상품 합)
  all.forEach((el) => {
    try {
      // v77 STEP2: 자격 탈락 타일에 data-kgp-skip="사유" 부여 — '왜 이 타일만 버튼이 없지?'를 속성 하나로 판독.
      // v67: 구조적 비상품(footer/nav)만 제외 — 추천/캐러셀은 버튼 부착(region='reco' 태깅).
      if (_kgpInBadRegion(el, { allowAds: true, structuralOnly: true })) { _kgpExcl.region++; _kgpMarkSkip(el, "non-product"); return; }
      let asin = (el.getAttribute("data-asin") || "").trim();
      // v86-B: data-asin이 비면 스폰서 링크 payload에서 목적지 ASIN을 복원한다(광고 타일도 실제 소싱 가능).
      // 셀렉터가 매치했다고 믿지 않고 **href를 직접 확인**한다(광고가 아닌 타일을 광고로 오인하면
      //   멀쩡한 ASIN을 날려 타일이 통째로 사라진다).
      const _adA = el.querySelector('a[href*="/sspa/click"]');
      const _adHref = _adA ? String((_adA.getAttribute && _adA.getAttribute("href")) || _adA.href || "") : "";
      const _isSspa = _adHref.indexOf("/sspa/click") >= 0;
      if (!/^[A-Z0-9]{10}$/.test(asin) && _isSspa) asin = _kgpAmazonSspaAsin(_adHref);
      if (!/^[A-Z0-9]{10}$/.test(asin)) {
        _kgpExcl.parse++;
        // 사유 분리: 광고 타일인데 payload에서도 못 뽑은 건 'no-asin'과 원인이 다르다(구조 변경 신호).
        _kgpMarkSkip(el, _isSspa ? "ad-sspa-fail" : "no-asin");
        return;
      }
      const parentAsin = el.parentElement && el.parentElement.closest('[data-asin]:not([data-asin=""])');
      if (parentAsin && parentAsin !== el && (parentAsin.getAttribute("data-asin") || "").trim() === asin) { _kgpExcl.dup++; _kgpMarkSkip(el, "dup"); return; }
      const sponsored = _kgpAmazonSponsored(el);           // v45 P3: 제외 아님 — 태깅만(스폰서 상품도 수집).
      if (sponsored) _kgpExcl.ad++;                        // v65 STEP2: 광고 카운트(제외 아님)
      // v67 STEP1: region = 메인 그리드 안이면 main, 밖(추천/캐러셀)이면 reco. 버튼은 둘 다 부착.
      const region = (mainSlot ? mainSlot.contains(el) : !_kgpIsRecoRegion(el)) ? "main" : "reco";
      if (region === "reco") _kgpExcl.reco++;
      const a = el.querySelector('a.a-link-normal[href*="/dp/"], h2 a, a.a-link-normal.s-no-outline, a[href*="/dp/"]');
      let href = a && a.href ? a.href.split("?")[0].split("#")[0] : "";
      // v86-B: sspa 링크는 자르면 전부 '/sspa/click'으로 붕괴한다 → 해석한 ASIN으로 정규 상세 URL을 세운다.
      const _aHref = a ? String((a.getAttribute && a.getAttribute("href")) || a.href || "") : "";
      if (_aHref.indexOf("/sspa/click") >= 0) href = "";
      if (!href || href.indexOf("http") !== 0) href = location.origin + "/dp/" + asin;   // ASIN 폴백
      // v86-B: 같은 상품이 여러 타일로 반복돼도 **인스턴스마다 버튼을 붙인다**(오너: 눈에 보이는 타일엔 다 있어야).
      //   url이 같으니 product key도 같고 병합은 기존 로직(서버 dedup·수집 시 중복 안내)이 그대로 처리한다.
      //   집계에서는 구분되게 dup_instance 표식만 남긴다(제외가 아니므로 _kgpExcl.dup는 올리지 않는다).
      const _dupInstance = !!seen[href];
      const img = el.querySelector("img.s-image") || el.querySelector("img");
      const titleEl = el.querySelector("h2 span") || el.querySelector("h2 a span") || el.querySelector("h2")
        || el.querySelector('[data-cy="title-recipe"] span') || el.querySelector(".a-size-base-plus, .a-size-medium");
      let title = titleEl ? (titleEl.innerText || titleEl.textContent || "").trim() : "";
      if (!title && img && img.alt) title = img.alt.trim();
      if (!title && !img) { _kgpExcl.parse++; _kgpMarkSkip(el, "parse-fail"); return; }     // 제목·이미지 둘 다 없으면 상품 아님
      const priceEl = el.querySelector(".a-price .a-offscreen") || el.querySelector(".a-price");
      const pr = _kgpPrice(priceEl ? priceEl.textContent : (el.innerText || ""));
      seen[href] = 1;
      _kgpClearSkip(el);   // v77 STEP2: 채택된 타일은 스킵 표식 제거(재스캔 정합)
      const bimg = _kgpBestImg(img);                        // v41 X-1: lazy placeholder 대신 실제 이미지
      cards.push({
        url: href, title: (title || "(제목 없음)").slice(0, 200),
        image: bimg, images: bimg ? [bimg] : [], price: pr.price, currency: pr.currency,
        sponsored: sponsored, region: region, el: el,   /* v67: region 태그(main/reco) */
        dup_instance: _dupInstance,                     /* v86-B: 같은 상품의 반복 타일(버튼은 부착) */
      });
    } catch (e) { /* noop */ }
  });
  return cards;
}

// 특정 href가 상품 '상세 페이지' 링크인지(가격 없는 카드의 대체 상품 신호). — 앵커 선택용(느슨).
function _kgpIsDetailHref(href) {
  return /(\/dp\/|\/gp\/product\/|item\.htm|offer\/detail|\/g-?\d|\/goods\/|\/product\/|-i\.\d+\.\d+|\/products?\/)/i.test(href || "");
}
// v74 STEP1: 카테고리 내비 URL 판별(상품 아님) — 카테고리/컬렉션/브랜드/랭킹/리스트 내비.
function _kgpIsCategoryHref(href) {
  return /(\/category\/|\/categories\/|\/categorylist|\/c\/[a-z]|\/collection\b|\/collections\/|\/brand\/|\/brands\/|\/department\b|\/ranking\b|\/lineup\b|\/gnb\b|[?&](category|categoryid|cat|dept|genre)=)/i.test(href || "");
}
// v74 STEP1: '상품' URL(식별자 있는 상세 링크)만 인정 — 카테고리 URL은 제외(오탐 봉인).
//   상품 신호=명시 ID(dp/goods_id/g-<n>/item.htm 등) 또는 상세 슬러그(products/detail·digit 포함·8+자 슬러그).
function _kgpIsProductHref(href) {
  const h = href || "";
  if (_kgpIsCategoryHref(h)) return false;
  // v86 STEP5: **라쿠텐 상품 URL은 경로에 /item/ 이 없다** — 호스트 자체가 item.rakuten.co.jp이고
  //   경로가 `/{샵ID}/{상품코드}/` 형태다(예: item.rakuten.co.jp/tabemon-dikara/20072/?variantId=20072).
  //   기존 패턴들(/item/\d+ 등)은 전부 '경로에 /item/'을 전제해서 **라쿠텐 검색 타일 80개가 통째로
  //   no-item-url로 버려졌다**(오너 진단 skipStats 45 + 스냅샷 실측 80).
  //   판정: item.rakuten.co.jp + **경로 세그먼트 2개 이상**(샵 최상위 `/{샵ID}/`는 1개라 자연히 제외).
  if (_kgpIsRakutenItemHref(h)) return true;
  return /(\/dp\/[A-Z0-9]{10}|\/gp\/product\/|item\.htm|[?&]goods_id=|[/-]g-\d{3,}|\/goods\/\d|-i\.\d+\.\d+|aliexpress\.[^/]+\/item\/\d+|\/item\/\d+|\/product\/\d|\/products?\/detail|\/products?\/[^/?#]*\d|\/products?\/[^/?#]{8,}|\/itm\/)/i.test(h);
}
// v86 STEP5: 광고/추적 리다이렉트 링크 판정 — 목적지가 토큰 뒤에 숨어 클라이언트에서 해석 불가한 것들.
//   (라쿠텐 RPP 광고·rd.rakuten 추적). 상품일 수도 있지만 **안정적인 상품 URL을 못 얻으므로** 후보에서 제외한다.
function _kgpIsAdRedirectHref(href) {
  return /(\/redirect_rpp\/|(^|\/\/)[a-z0-9.-]*\bias\.rakuten\.co\.jp\/|rd\.rakuten\.co\.jp\/s\/)/i.test(href || "");
}
// 라쿠텐 상품 상세 판정 — 호스트+세그먼트 수로만 본다(상품코드 형식은 샵마다 제각각: 숫자·해시·한글 혼재).
function _kgpIsRakutenItemHref(href) {
  try {
    var u = new URL(href, location.href);
    if (!/(^|\.)item\.rakuten\.co\.jp$/i.test(u.hostname)) return false;
    var seg = u.pathname.split("/").filter(Boolean);
    return seg.length >= 2;          // /{shop}/{itemCode}[/...] = 상품 상세
  } catch (e) { return false; }
}
// v74 STEP1: 내비/메뉴/브레드크럼 영역이면 상품 타일 아님(구조적 오탐 차단, 최대 6단계 조상).
function _kgpInNavRegion(el) {
  const navRe = /(^|[\s_-])(nav|navi|navigation|menu|gnb|lnb|breadcrumb|megamenu|category-?nav|tablist)([\s_-]|$)/i;
  let n = el;
  for (let i = 0; n && i < 6; i++, n = n.parentElement) {
    if ((n.tagName || "").toLowerCase() === "nav") return true;
    const role = (n.getAttribute && n.getAttribute("role")) || "";
    if (role === "navigation" || role === "menu" || role === "menubar" || role === "tablist") return true;
    let cls = ""; try { cls = (typeof n.className === "string" ? n.className : (n.getAttribute && n.getAttribute("class")) || ""); } catch (e) { cls = ""; }
    if (navRe.test(((n.id || "") + " " + cls))) return true;
  }
  return false;
}

// v81 STEP4: 추천/이력(足あと) 위젯 명시 블록리스트 — 라쿠텐 톱/상품 페이지의 '閲覧した商品からのおすすめ',
//   'あなたにおすすめ', 足あと(#riAshiato), 추천 탭패널([id^=tabpanel-recommend]) 섹션 전체를 후보에서 제외.
//   ※ 감지 자체는 죽이지 않는다 — 이 섹션에 속한 타일만 skip="recommend-widget"으로 제외(제네릭 감지 유지).
const _KGP_RECO_HEADING_RE = /(閲覧した商品からのおすすめ|あなたにおすすめ|おすすめ商品|チェックした商品|履歴から|이 상품을 본 고객|추천 상품|최근 본 상품)/;
function _kgpInRecommendWidget(el) {
  let n = el;
  for (let i = 0; n && i < 10; i++, n = n.parentElement) {
    const id = (n.id || "");
    if (id === "riAshiato" || /^tabpanel-recommend/i.test(id)) return true;
    // 섹션(section/div[role=region]/aside)에 추천/이력 헤딩이 붙어 있으면 그 섹션 전체 제외.
    const tag = (n.tagName || "").toLowerCase();
    const role = (n.getAttribute && n.getAttribute("role")) || "";
    if (tag === "section" || tag === "aside" || role === "region" || role === "tabpanel") {
      let hd = null;
      try { hd = n.querySelector("h1,h2,h3,h4,[role='heading'],[class*='title' i],[class*='header' i],[class*='heading' i]"); } catch (e) { hd = null; }
      const txt = hd ? (hd.textContent || "") : "";
      if (txt && _KGP_RECO_HEADING_RE.test(txt)) return true;
    }
  }
  return false;
}

// 폴백 휴리스틱 — 제목+제품링크+충분히 큰 이미지. v43-2: 가격이 없어도 '상품 상세 링크'면 인식(미렌더 가격 카드 복구).
function _kgpGenericCards() {
  const cards = [], seen = {};
  let scanned = 0;
  try {
    const imgs = document.querySelectorAll("img");
    for (let i = 0; i < imgs.length; i++) {
      const img = imgs[i];
      const w = img.naturalWidth || img.width || 0;
      const h = img.naturalHeight || img.height || 0;
      if (w < 140 || h < 140) continue;                    // 작은 썸네일/아이콘 제외
      let a = img.closest("a[href]");
      // v63 STEP1: 테무 등 SPA는 이미지를 <a>로 안 감쌀 수 있음 → 카드 컨테이너의 상세링크 앵커로 폴백.
      let card = (a && a.closest("li,article,div"))
        || img.closest("li,article,[class*='card' i],[class*='item' i],[class*='product' i],[class*='goods' i]");
      if ((!a || !a.href || a.href.indexOf("http") !== 0) && card) {
        const cand = card.querySelectorAll("a[href]");
        for (let j = 0; j < cand.length; j++) {
          const hh = cand[j].href || "";
          if (hh.indexOf("http") === 0 && _kgpIsDetailHref(hh)) { a = cand[j]; break; }  // 상세링크 우선
        }
        if ((!a || (a.href || "").indexOf("http") !== 0) && cand.length && (cand[0].href || "").indexOf("http") === 0) a = cand[0];
      }
      // v77 STEP2: 미부착 타일 자가보고 — 스킵 대상 타일 요소에 data-kgp-skip="사유".
      const _skipEl = card || (a && a.closest("li,article,div")) || (img.closest && img.closest("li,article,div")) || img.parentElement;
      if (!a || !a.href || a.href.indexOf("http") !== 0) { _kgpExcl.url++; _kgpMarkSkip(_skipEl, "no-url"); continue; }   // v65 STEP2: URL 추출 실패
      const href = a.href.split("#")[0];
      if (seen[href]) { _kgpExcl.dup++; _kgpMarkSkip(_skipEl, "dup"); continue; }
      if (!card) card = a.closest("li,article,div") || a;
      // v67 STEP1: 구조적 비상품(footer/nav)만 제외 — 추천/캐러셀 상품 타일도 버튼 부착(region='reco').
      if (_kgpInBadRegion(card, { structuralOnly: true })) { _kgpExcl.region++; _kgpMarkSkip(card, "non-product"); continue; }
      // v74 STEP1: 내비/메뉴/카테고리 영역 타일은 상품 아님 → 오탐 봉인(요시다 카테고리 아이콘 줄).
      if (_kgpInNavRegion(card)) { _kgpExcl.region++; _kgpMarkSkip(card, "nav"); continue; }
      // v81 STEP4: 추천/이력 위젯(足あと·あなたにおすすめ·閲覧した商品) 타일 명시 제외 — 후보 제외만(감지 유지).
      if (_kgpInRecommendWidget(card)) { _kgpExcl.region++; _kgpMarkSkip(card, "recommend-widget"); continue; }
      const text = (card.innerText || "").trim();
      let pr = _kgpPrice(text);
      // v87-#597: 라쿠텐 검색 타일은 가격(1,706円)이 **감지 카드 바깥 상위 타일 컨테이너**(.searchresultitem)에
      //   있어 카드 스코프 텍스트론 못 잡는다(가격만 누락, 감지·keep-set은 불변). 라쿠텐 item 타일에 한해
      //   상품 링크가 여러 개(다른 타일 혼입)로 늘기 직전까지만 조상을 올라가 가격을 포착 → 교차 오염 0.
      if (!pr.price && href.indexOf("item.rakuten.co.jp") >= 0) {
        let anc = card.parentElement, hops = 0;
        while (anc && hops < 4) {
          if (anc.querySelectorAll('a[href*="item.rakuten.co.jp"]').length > 2) break;   // 타일 경계 초과 → 중단
          const p2 = _kgpPrice(anc.innerText || anc.textContent || "");
          if (p2.price) { pr = p2; break; }
          anc = anc.parentElement; hops++;
        }
      }
      const titleEl = card.querySelector("h1,h2,h3,h4,[class*='title'],[class*='name']");
      const title = ((img.alt || "").trim()) || (titleEl ? titleEl.innerText : "") || text;
      if (!title || title.trim().length < 4) { _kgpExcl.parse++; _kgpMarkSkip(card, "parse-fail"); continue; }     // 제목 없으면 상품 후보 아님
      scanned++;                                           // 상품 후보(제목+이미지+링크+영역OK)
      // v74 STEP1: 타일 자격 = [상품 URL 패턴 or 가격 텍스트] 중 1 필수 + 이미지(위). 카테고리 URL(가격없음)은 제외.
      //   (v43-2의 느슨한 _kgpIsDetailHref는 /products/<카테고리>까지 통과시켜 카테고리 줄 오탐 유발 → 엄격판.)
      // v81 STEP4 STEP C: 사유 세분화 — 상품 상세 링크 자체가 없으면 no-item-url, 링크는 되나 가격만 없는 케이스는
      //   no-price. keep-set 불변(가격·상품링크 둘 다 없을 때만 제외 — 회귀 0).
      if (!pr.price && !_kgpIsProductHref(href)) {
        _kgpExcl.parse++;
        // v86 STEP5: 광고 리다이렉트 타일을 'no-item-url'로 뭉뚱그리면 원인을 못 읽는다 → 사유 분리.
        //   라쿠텐 검색의 광고 타일(grp07.ias…/redirect_rpp)은 **목적지 URL이 어디에도 없다**
        //   (앵커 1개·불투명 토큰만, 타일/조상에 item 링크·data 속성 0 — 실측 확인).
        //   채택하면 안 되는 이유가 분명하다: normalize_product_key가 쿼리를 버려 **10개 광고가 전부
        //   같은 키(grp07.ias.rakuten.co.jp/redirect_rpp)로 붕괴** → 서로 다른 상품이 1건으로 합쳐져 소실된다.
        //   그래서 제외하되, 'no-item-url'이 아니라 **ad-redirect**로 정직하게 표기한다(집계에서 즉시 구분).
        _kgpMarkSkip(card, _kgpIsAdRedirectHref(href) ? "ad-redirect"
                          : (_kgpIsProductHref(href) ? "no-price" : "no-item-url"));
        continue;
      }
      seen[href] = 1;
      _kgpClearSkip(card);   // v77 STEP2: 채택 타일 스킵 표식 제거
      const region = _kgpIsRecoRegion(card) ? "reco" : "main";   // v67: 추천 영역 태깅(버튼은 부착)
      if (region === "reco") _kgpExcl.reco++;
      const bimg = _kgpBestImg(img) || img.src;             // v41 X-1: 실제 이미지 우선(placeholder 공유 방지)
      cards.push({
        url: href, title: title.trim().replace(/\s+/g, " ").slice(0, 200),
        image: bimg, images: bimg ? [bimg] : [], price: pr.price, currency: pr.currency, region: region, el: card,
      });
    }
  } catch (e) { /* noop */ }
  // v43-2: 정직 '전체 N 중 상품 M · 제외 K'.
  // v83 STEP4: `scanned > cards.length`일 때만 기록해, **전건 채택(동수)** 이면 카운터가 0에 머물렀다
  //   (요시다 목록 진단 scanned=0의 근원 — 스캔을 안 한 게 아니라 안 적었다). 항상 실측값으로 기록.
  _kgpScannedCount = Math.max(_kgpScannedCount || 0, scanned);
  return cards;
}

// ── F49-T 3부 — 타오바오 목록(world.taobao.com 등) 어댑터 ──────────────────────────────
//   오너 진단 실측(ext 1.5.152, world.taobao.com): 피드 카드 30장 = `a.item-link`
//   (class tb-pick-content-item · item-appear), href = item.taobao.com | detail.tmall.com /item.htm?id=.
//   제네릭은 그중 0장을 잡고 「내 찜」 블록(mytao-collectitem) 4장만 잡았다 → 앵커 기준으로 센다.
//   셀렉터는 이 실측에서만 왔다(발명 0). 상품 번호는 서버 vendor_sku가 같은 `id=`를 다시 읽는다.
function _kgpTaobaoItemHref(href) {
  try {
    const u = new URL(String(href || ""), location.href);
    if (!/(^|\.)(item\.taobao|detail\.tmall)\.com$/i.test(u.hostname)) return "";
    if (!/\/item\.htm$/i.test(u.pathname)) return "";
    const id = u.searchParams.get("id") || "";
    return /^\d{6,}$/.test(id) ? ("https://" + u.hostname + "/item.htm?id=" + id) : "";
  } catch (e) { return ""; }
}
// 「내 찜」(mytao-collectitem) — 셀러가 이미 찜한 상품 블록. 피드가 아니라 **제외**한다(사유 표식은 남긴다).
function _kgpInTaobaoSaved(el) {
  try { return !!(el && el.closest && el.closest(_kgpRule("list_cards.taobao.saved_block", "[class*='mytao-collectitem']"))); } catch (e) { return false; }
}
// 타오바오·티몰 도메인의 **상품이 아닌** 링크(행사·앱 입구). 1688은 상품 URL 모양이 달라 여기서 판정하지 않는다.
function _kgpIsTaobaoPromoUrl(url) {
  try {
    const u = new URL(String(url || ""), location.href);
    if (!/(^|\.)(taobao|tmall)\.com$/i.test(u.hostname)) return false;
    return !_kgpTaobaoItemHref(u.href);
  } catch (e) { return false; }
}
function _kgpTaobaoListCards() {
  const cards = [], seen = {};
  let scanned = 0;
  let _anchorSel = _kgpRule("list_cards.taobao.anchor", "a.item-link, a.tb-pick-content-item");
  try { document.querySelector(_anchorSel); } catch (e) { _anchorSel = "a.item-link, a.tb-pick-content-item"; }   // 깨진 규칙 → 기본값
  document.querySelectorAll(_anchorSel).forEach((a) => {
    try {
      scanned++;
      if (_kgpInTaobaoSaved(a)) { _kgpExcl.region++; _kgpMarkSkip(a, "mytao-saved"); return; }
      const href = _kgpTaobaoItemHref(a.getAttribute("href") || a.href);
      if (!href) { _kgpExcl.url++; _kgpMarkSkip(a, "no-item-url"); return; }
      const img = _kgpCardImage(a) || a.querySelector("img");
      const titleEl = a.querySelector("[class*='title' i], [class*='name' i]");
      let title = titleEl ? (titleEl.innerText || titleEl.textContent || "").trim() : "";
      if (!title && img && img.alt) title = img.alt.trim();
      if (!title) title = String(a.innerText || a.textContent || "").trim().split("\n")[0];
      const pr = _kgpPrice(a.innerText || a.textContent || "");
      const bimg = img ? (_kgpBestImg(img) || img.src || "") : "";
      _kgpClearSkip(a);
      cards.push({
        url: href, title: (title || "(제목 없음)").replace(/\s+/g, " ").slice(0, 200),
        image: bimg, images: bimg ? [bimg] : [], price: pr.price, currency: pr.currency || (pr.price ? "CNY" : ""),
        region: "main", el: a, dup_instance: !!seen[href],
      });
      seen[href] = 1;
    } catch (e) { /* noop */ }
  });
  _kgpScannedCount = Math.max(_kgpScannedCount || 0, scanned);
  return cards;
}

// v63 STEP1: 상품 고유키 — 어댑터/제네릭이 같은 상품을 다른 URL 형태로 잡아도 하나로 묶는다.
//   아마존 ASIN(/dp/·/gp/product/), 테무·굿즈(goods_id·-g-<n>·/goods/<n>) 우선, 그 외 쿼리/ref 제거 URL.
function _kgpCardKey(url) {
  const u = url || "";
  let m = u.match(/\/(?:dp|gp\/product|gp\/aw\/d)\/([A-Z0-9]{10})/i);
  if (m) return "asin:" + m[1].toUpperCase();
  m = u.match(/[?&]goods_id=(\d+)/i) || u.match(/[/-]g-(\d{4,})/i) || u.match(/\/goods\/(\d+)/i);
  if (m) return "goods:" + m[1];
  // F49-T 3부: 타오바오·티몰 상품은 `item.htm?id=` — 제네릭과 어댑터가 같은 상품을 하나로 묶게.
  if (/(taobao|tmall)\.com\/item\.htm/i.test(u)) { m = u.match(/[?&]id=(\d{6,})/); if (m) return "tb:" + m[1]; }
  return u.split("#")[0].split("?")[0].replace(/\/(?:ref|spm|dp)=.*$/i, "").replace(/\/+$/, "").toLowerCase();
}

// v63 STEP1: 감지 역전 — 제네릭(요시다에서 검증된 건강 경로)을 항상 먼저, 어댑터는 정밀 보강만.
//   같은 상품키는 어댑터 결과로 덮어써(정밀: 스폰서 태그·정돈된 제목/가격), 제네릭만 잡은 상품은 유지한다.
//   → 어댑터 셀렉터가 현행 DOM과 불일치(사망)해도 제네릭 커버리지를 절대 막지 않는다(폴백 차단 구조 제거).
function _kgpMergeCards(generic, adapter) {
  const byKey = {}, order = [];
  (generic || []).forEach((c) => {
    const k = _kgpCardKey(c && c.url); if (!k) return;
    if (!byKey[k]) order.push(k);
    byKey[k] = c;
  });
  (adapter || []).forEach((c) => {
    const k = _kgpCardKey(c && c.url); if (!k) return;
    if (!byKey[k]) order.push(k);
    byKey[k] = c;                          // 어댑터 우선(정밀 보강) — 없으면 신규 추가
  });
  const out = order.map((k) => byKey[k]);
  // v86-B: 같은 상품이 **여러 타일로 반복**되는 목록(아마존 검색)에서는 상품키로만 합치면 두 번째
  //   타일이 통째로 사라져 '왜 이 타일만 버튼이 없지'가 된다(실측: 34 실타일 중 10개가 표식도 없이 소멸).
  //   상품키 병합(어댑터 우선)은 그대로 두고, **키가 같아도 DOM 타일이 다르면** 인스턴스를 하나 더 남긴다.
  //   url이 같으니 product key도 같고 병합·중복 안내는 서버의 기존 dedup 로직이 그대로 처리한다.
  const taken = {};
  out.forEach((c) => { if (c && c.el) { c.el._kgpTaken = 1; taken.x = 1; } });
  (adapter || []).forEach((c) => {
    if (!c || !c.el || c.el._kgpTaken) return;
    c.el._kgpTaken = 1;
    const inst = {};
    for (const p in c) inst[p] = c[p];
    inst.dup_instance = true;
    out.push(inst);
  });
  out.forEach((c) => { if (c && c.el) { try { delete c.el._kgpTaken; } catch (e) { /* noop */ } } });
  return out;
}

// v63 STEP1: 마지막 감지 스냅샷(팝업 디버그 패널이 조회) — 추측이 아니라 실측을 보고한다.
let _kgpLastDetect = { generic: 0, adapter: 0, merged: 0, adapterMatched: false };
function kgpFindCards() {
  const host = (location.hostname || "").toLowerCase();
  _kgpScannedCount = 0;            // 매 스캔 초기화(어댑터/제네릭이 '전체 N개'를 설정)
  _kgpExclReset();                 // v65 STEP2: 제외 사유 카운트 초기화
  _kgpSkipReset();                 // v77 STEP2: 타일 스킵 사유 집계 초기화
  let generic = [], gScanned = 0;
  try { generic = _kgpGenericCards(); gScanned = _kgpScannedCount; } catch (e) { generic = []; }
  let adapter = [];
  try { if (/(^|\.)amazon\.[a-z.]+$/.test(host)) { _kgpScannedCount = 0; adapter = _kgpAmazonCards(); } } catch (e) { adapter = []; }
  // F49-T 3부: 타오바오·티몰 목록 — 앵커 기준 어댑터. 제네릭이 잡은 「내 찜」 블록은 병합 후 뺀다.
  try { if ((typeof _kgpIsTaobaoHost === "function" && _kgpIsTaobaoHost(host))) { _kgpScannedCount = 0; adapter = _kgpTaobaoListCards(); } } catch (e) { adapter = []; }
  // 정직 카운트: 어댑터가 스캔한 전체(있으면)와 제네릭 스캔 중 큰 값 유지('전체 N 중 상품 M').
  _kgpScannedCount = Math.max(_kgpScannedCount || 0, gScanned || 0);
  let merged = _kgpMergeCards(generic, adapter);
  if ((typeof _kgpIsTaobaoHost === "function" && _kgpIsTaobaoHost(host))) {
    merged = merged.filter((c) => {
      if (c && c.el && _kgpInTaobaoSaved(c.el)) { _kgpMarkSkip(c.el, "mytao-saved"); return false; }
      // F49-T 4부-b: 오너 재업로드 스냅샷(2026-09-28) 실측 — 제네릭이 피드 위 **행사 입구**
      //   (business-entry · huodong.taobao.com·web.m.taobao.com) 4개를 상품으로 셌다. 타오바오·티몰 도메인인데
      //   상품 링크(item.htm?id=)가 아니면 상품이 아니다 → 「메인 N」·「전체 선택」에서 뺀다(사유 표식은 남김).
      if (c && c.url && _kgpIsTaobaoPromoUrl(c.url)) { if (c.el) _kgpMarkSkip(c.el, "taobao-promo"); _kgpExcl.url++; return false; }
      return true;
    });
  }
  // F49-T 4부: 컨테이너 감시 — 같은 모양의 새 카드(어댑터·제네릭이 놓친 것)를 더한다.
  let viaContainer = 0;
  try {
    _kgpWatchContainersEls = _kgpResolveContainers(merged);
    const extra = _kgpContainerSiblingCards(merged, _kgpWatchContainersEls);
    viaContainer = extra.length;
    if (extra.length) merged = merged.concat(extra);
  } catch (e) { /* noop */ }
  _kgpLastDetect = { generic: generic.length, adapter: adapter.length, merged: merged.length, adapterMatched: adapter.length > 0,
                     container: viaContainer };
  return merged;
}

function kgpCardBadgeStyle(selected) {
  // v80 STEP1: 체크박스 호스트 = 위치·크기 컨테이너만(가시 UI는 shadow DOM). 텍스트 배지 폐기 →
  //   'I빔 커서·무스타일 텍스트'(all:initial이 cursor/box-shadow 등 비-!important 속성 스트립) 근원 제거.
  //   cursor:pointer도 !important로(과거 비-!important라 all:initial이 I빔으로 덮던 것 봉인).
  // v86 STEP2: 호스트에서 all:initial 인라인 제거 — 가시 UI(체크박스)는 이미 shadow에서 그리므로
  //   격리는 shadow 경계가 담당한다. 호스트엔 위치·크기·중립화 선언만 둔다(250 롱핸드 전개 폐기).
  return [
    "position:absolute !important", "top:6px !important", "left:6px !important", "z-index:2147483642 !important",
    "background:transparent !important", "border:0 !important", "outline:0 !important", "float:none !important",
    "box-sizing:border-box !important", "display:block !important",
    "width:22px !important", "height:22px !important", "min-width:22px !important", "min-height:22px !important",
    "padding:0 !important", "margin:0 !important", "cursor:pointer !important", "user-select:none !important",
    // v77 STEP1(B): 선택 토글은 호버 전용(미선택·비호버=숨김), selected·터치는 상시.
    "opacity:" + ((KGP_TOUCH || selected) ? "1" : "0") + " !important", "transition:opacity .12s !important",
  ].join(";");
}

// v80 STEP1: 선택 체크박스를 shadow DOM에 자체 그림(먹 반투명 원+금 체크) — 사이트 CSS·all:initial 취약성에서
//   완전 격리. 스타일 이중 주입(adoptedStyleSheets + <style> 인라인 폴백, 실패 시 콘솔 경고). 22px·이미지 위
//   대비 보장(반투명 백킹). 미선택=먹 박스+금 테(빈), 선택=청록 박스+금 체크 — 두 상태 육안 구분.
function _kgpBuildCheckbox(host, selected) {
  var root = host._kgpShadow;
  if (root === undefined) {
    try { root = host.attachShadow({ mode: "open" }); } catch (e) { root = null; }
    host._kgpShadow = root;
    if (root) {
      var css = ":host{all:initial}"
        + ".b{box-sizing:border-box;width:22px;height:22px;border-radius:6px;display:flex;align-items:center;"
        + "justify-content:center;background:rgba(26,23,20,.82);border:1.6px solid #c9a24b;"
        + "box-shadow:0 2px 8px rgba(0,0,0,.45);cursor:pointer}"
        + ".b.on{background:#119a8e;border-color:#0f8c80}"
        + ".c{width:13px;height:13px;display:none}.b.on .c{display:block}svg{display:block;width:13px;height:13px}";
      var adopted = false;
      try {
        if (("adoptedStyleSheets" in root) && typeof CSSStyleSheet === "function") {
          var sh = _KGP_SHEETS["chk:" + css];      // F49-T 4부: 체크박스 시트도 공유
          if (!sh) { sh = new CSSStyleSheet(); sh.replaceSync(css); _KGP_SHEETS["chk:" + css] = sh; }
          root.adoptedStyleSheets = [sh]; adopted = true;
        }
      } catch (e) { adopted = false; }
      var st = document.createElement("style"); st.textContent = css; root.appendChild(st);   // 인라인 폴백(항상 주입)
      if (!adopted) { try { console.warn("[고가수집기] 체크박스 adoptedStyleSheets 미지원 — <style> 인라인 폴백 사용"); } catch (e) {} }
      var box = document.createElement("div"); box.setAttribute("class", "b");
      box.innerHTML = '<span class="c"><svg viewBox="0 0 13 13" aria-hidden="true"><path d="M2.5 7 L5.5 10 L10.5 3.5" fill="none" stroke="#f0d68a" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"/></svg></span>';
      root.appendChild(box);
      host._kgpBox = box;
    }
  }
  if (host._kgpBox) host._kgpBox.setAttribute("class", "b" + (selected ? " on" : ""));
  else host.textContent = selected ? "✓" : "○";   // shadow 미지원 구형 폴백(무스타일 텍스트라도 표식)
}

function kgpSetCardSelected(url, badge, el, selected) {
  let _k = "";
  try { _k = _kgpCardKey(url); } catch (e) {}
  if (selected) {
    KGP_SELECTED.add(url);
    if (_k) _kgpSelKeys.add(_k);
    if (badge) { badge.style.cssText = kgpCardBadgeStyle(true); _kgpBuildCheckbox(badge, true); badge.setAttribute("aria-checked", "true"); }
    if (el) { el.style.outline = "3px solid #119a8e"; el.style.outlineOffset = "-3px"; el.setAttribute("data-kgp-outline", "1"); }
  } else {
    KGP_SELECTED.delete(url);
    if (_k) {                       // 같은 상품의 다른 URL 형태도 같이 해제(키 기준 선택)
      _kgpSelKeys.delete(_k);
      Array.from(KGP_SELECTED).forEach((u) => { try { if (_kgpCardKey(u) === _k) KGP_SELECTED.delete(u); } catch (e) {} });
    }
    if (badge) { badge.style.cssText = kgpCardBadgeStyle(false); _kgpBuildCheckbox(badge, false); badge.setAttribute("aria-checked", "false"); }   // v80 STEP1: shadow 체크박스 토글
    if (el) { el.style.outline = ""; el.removeAttribute("data-kgp-outline"); }
  }
}

function kgpToggleCard(url, badge, el) {
  kgpSetCardSelected(url, badge, el, !KGP_SELECTED.has(url));
  kgpUpdateToolbar();
}

function kgpSetStatus(msg) {
  const s = _kgpTbQ("#kgp-tb-status");
  if (s) s.textContent = msg || "";
}

// ── v42 E-3: 목록 카드 호버 즉시 수집 ──
const KGP_TOUCH = (() => { try { return matchMedia("(pointer: coarse)").matches; } catch (e) { return false; } })();
let _kgpCollectedUrls = new Set();   // 이미 수집된 상품 URL(호버 버튼 '수집됨 ✓' 선표시)
// v86-G: **빈 키 오염 봉인.** rest에서 [수집]이 보이는 유일한 정당 사유는 `dataset.collected==="1"`
//   ('수집됨 ✓' 상시 노출, v86-C)이고, 그 값은 이 집합 조회로도 켜진다(타일 생성 시 done, 선표시 시 mark).
//   URL이 안 잡히는 타일(아마존 홈 캐러셀처럼 href 해석이 실패하는 경로)이 섞이면 `""`/`"undefined"`가
//   집합에 들어갈 수 있고, 그 순간 **같은 처지의 모든 타일이 '수집됨'으로 켜져 rest가 통째로 1**이 된다
//   — 사이트별 rest 불일치가 만들어지는 구조적 분기. 빈 키는 어떤 경우에도 매칭 근거가 아니다.
function _kgpUrlKey(u) {
  u = (u == null ? "" : String(u)).trim();
  return (!u || u === "undefined" || u === "null") ? "" : u;
}
function _kgpRememberCollected(u) { const k = _kgpUrlKey(u); if (k) _kgpCollectedUrls.add(k); }
function _kgpIsCollectedUrl(u) { const k = _kgpUrlKey(u); return !!k && _kgpCollectedUrls.has(k); }
const KGP_BRIDGE_MINI = '<svg width="14" height="14" viewBox="0 0 512 512" aria-hidden="true">' +
  '<circle cx="256" cy="205" r="92" fill="none" stroke="#c9a24b" stroke-width="46"/>' +
  '<line x1="80" y1="356" x2="432" y2="356" stroke="#119a8e" stroke-width="46" stroke-linecap="round"/>' +
  '<circle cx="256" cy="108" r="40" fill="#f5821f"/></svg>';

// v64 STEP3: 호버 수집 버튼 스펙 확정 — 이미지 영역 오버레이 앵커(요시다 '수집됨✓' 스타일).
//   원 과대·글자 과소 → 지름 절반(min-height 66→34)·텍스트 위주 필(아이콘 21→14, 글자 위계 ↑).
//   앵커: 기본 중앙, 설정(kgp_hover_anchor)에서 좌하 7시(bl)/우하 5시(br) 선택. 터치는 우상단 상시 소형.
//   토큰: 먹(#1a1714)·금(#c9a24b) 테, 수집됨=청록(#119a8e). 임의 색 금지.
let KGP_HOVER_ANCHOR = "center";   // v64 STEP3: chrome.storage.local(사이트 무관 공유) — 팝업이 설정.
function kgpHoverAnchor() {
  const a = KGP_HOVER_ANCHOR;
  return (a === "bl" || a === "br" || a === "center") ? a : "center";
}
function _kgpAnchorCss(mode) {
  // v65 STEP3: mode='corner'(이미지 못 찾음) → 좌상단 폴백(허공 금지). 그 외 이미지 영역 앵커.
  // v73 STEP1: 앵커 오프셋 전부 !important — all:initial의 auto가 호버 버튼 위치를 덮어써 '일부만' 보이던
  //   회귀 수리(카드 배지는 이미 !important라 생존, 호버 버튼만 앵커 오프셋이 비-!important였음).
  // F49-T 3부: 타오바오·티몰 목록은 카드 **우상단**(오너 지시) — 이미지를 못 찾아도 같은 자리.
  if ((typeof _kgpIsTaobaoHost === "function" && _kgpIsTaobaoHost(location.hostname))) return ["top:8px !important", "right:8px !important"];
  if (mode === "corner") return ["top:6px !important", "left:6px !important"];
  if (KGP_TOUCH) return ["top:8px !important", "right:8px !important"];       // 터치: 우상단 상시
  const a = kgpHoverAnchor();
  if (a === "bl") return ["bottom:10px !important", "left:10px !important"];   // 7시
  if (a === "br") return ["bottom:10px !important", "right:10px !important"];  // 5시
  return ["top:50% !important", "left:50% !important", "transform:translate(-50%,-50%) !important"];  // 중앙(기본)
}
// v65 STEP3: 카드에서 대표 이미지 요소 찾기(가장 큰 상품 이미지) — 버튼을 이 이미지 위에 앵커.
function _kgpCardImage(card) {
  if (!card || !card.querySelectorAll) return null;
  let best = null, bestArea = 0;
  try {
    const imgs = card.querySelectorAll("img");
    for (let i = 0; i < imgs.length; i++) {
      const im = imgs[i];
      const w = im.naturalWidth || im.width || im.clientWidth || 0;
      const h = im.naturalHeight || im.height || im.clientHeight || 0;
      if (w < 60 || h < 60) continue;                    // 아이콘/썸네일 제외
      const area = w * h;
      if (area > bestArea) { bestArea = area; best = im; }
    }
  } catch (e) {}
  return best;
}
// v86 STEP2: 호버 수집 버튼을 Shadow DOM으로 이전. 호스트에는 **위치·가시성 계열만** 인라인으로 두고
//   알약(배경·테두리·글자)은 shadowRoot 안에서 그린다. 옛 구현은 버튼과 자식 span 전부에 `all:initial
//   !important`를 인라인으로 박았는데, 그게 곧 v86이 규명한 '위치는 맞는데 투명·0크기' 유령의 메커니즘이다
//   (250 롱핸드 전개 + 인라인 !important라 시트 복원 불가). 사이트 CSS 격리는 shadow 경계가 대신한다.
// v86 STEP4: absolute 앵커의 기준(containing block) 보장 — 공통 유틸.
//   종전엔 아마존 카드(c.el)에만 `position:relative`를 줬는데, 알리 카드는 인라인 style=""(static)이라
//   중앙 앵커가 **카드 밖 조상**을 기준으로 잡혀 버튼이 엉뚱한 좌표로 표류했다.
//   앵커 대상(host)이 static이면 무조건 relative를 준다 — 사이트 무관 단일 규칙.
// v86 STEP4.1: **계측 사각 3호** — 필드(실기기) 진단에 "호버하면 켜지는가"를 판정할 수단이 없었다.
//   첫 카드에 synthetic mouseenter를 쏘고 전이(.12s)가 끝날 여유를 준 뒤 다시 재서 {before, after}로 남긴다.
//   리스너가 안 붙었거나 죽었으면 after가 before와 같게 나와 즉시 드러난다(추측 불필요).
//   ※ 비동기라 진단 응답 전에 끝나야 한다 → 350ms 후 콜백이 아니라, 호출자가 이미 만든 스냅샷에 채워 넣는다.
function _kgpHoverProbe(q) {
  var out = { fired: false, before: null, after: null, note: "", collected: false };
  try {
    // v86-G: **collected를 같이 남긴다.** '수집됨 ✓' 타일은 v86-C 설계상 rest에서도 opacity 1로
    //   상시 노출되고 호버 토글에서도 제외된다(kgpQuickHover의 dataset.collected 가드). 이 값이 없으면
    //   실기기 진단의 `host_opacity=1`이 **호버 은닉 위반인지 수집됨 타일인지 구분되지 않는다** —
    //   아마존 홈 rest=1 / 알리·라쿠텐 rest=0 불일치 판독을 막고 있던 지점이 정확히 여기다.
    out.collected = (q.dataset && q.dataset.collected === "1");
    var card = q.closest ? q.closest('[data-kgp="done"]') : null;
    out.before = { host_opacity: getComputedStyle(q).opacity, center_hit: _kgpCenterHit(q) };
    if (out.collected) {
      out.note = "수집됨 타일 — rest 상시 노출(설계). 호버 계약 대상 아님";
      return out;
    }
    if (!card) { out.note = "카드 요소를 못 찾음(앵커 구조 변경?)"; return out; }
    card.dispatchEvent(new MouseEvent("mouseenter"));
    out.fired = true;
    // 동기 측정은 전이 중이라 옛 값이 나온다(STEP4 함정) → 인라인 선언값을 함께 남겨 판정 가능하게.
    out.after = { host_opacity: getComputedStyle(q).opacity, inline_opacity: q.style.opacity || "",
                  center_hit: _kgpCenterHit(q) };
    out.note = "after.host_opacity는 전이 중일 수 있음 — inline_opacity가 최종 목표값";
  } catch (e) { out.note = "probe 예외: " + (e && e.message); }
  return out;
}
function _kgpCenterHit(el) {
  try {
    var r = el.getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) return false;
    var cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    if (cx < 0 || cy < 0 || cx > innerWidth || cy > innerHeight) return false;   // 뷰포트 밖=판정 불가
    var hit = document.elementFromPoint(cx, cy);
    return !!(hit && (hit === el || el.contains(hit) || (hit.getRootNode && hit.getRootNode().host === el)));
  } catch (e) { return false; }
}
// v86 STEP4.1: 요소가 **스태킹 컨텍스트**를 만드는지 판정(대표적 원인만 — 오탐이 나면 앵커만 한 칸 올라가므로 안전).
//   transform/filter/will-change/perspective/isolation/opacity<1/contain 등이 걸리면 그 안의 z-index는
//   컨텍스트 **내부 순위**일 뿐이라, 바깥의 z-index:1짜리 오버레이한테도 진다.
// v86-C: 오너가 STEP4.1의 '상시 노출'을 **철회**했다 → rest는 다시 0(마우스를 떼면 사라진다).
//   목록 카드 호버 노출 방식. 값은 여기 한 곳에서만 정하고, 적용은 전부 JS setProperty로 한다
//   (시트 의존 금지 — STEP4 원칙: 인라인 !important는 시트가 못 되돌린다).
var KGP_QUICK_REST_OPACITY = 0;
// F49-T 3부(오너 2026-09-26, world.taobao.com 진단): rest 0 방식은 **호버 전이가 끝나지 않으면 영영 안 보인다**
//   — 진단의 hover_test가 호버 뒤에도 host_opacity "0"이었다. 타오바오·티몰 목록은 평소에도 **반투명 작은**
//   「고가 수집」을 우상단에 두고, 호버하면 불투명으로. 다른 사이트는 v86-C(rest 0) 그대로 — 넓히는 건 오너 결정.
var KGP_QUICK_REST_OPACITY_TB = 0.6;
function _kgpQuickRestOpacity() {
  try {
    if (!_kgpIsTaobaoHost(location.hostname)) return KGP_QUICK_REST_OPACITY;
    const v = Number(_kgpRule("tiles.rest_opacity.taobao", KGP_QUICK_REST_OPACITY_TB));
    return (v >= 0 && v <= 1) ? v : KGP_QUICK_REST_OPACITY_TB;
  }
  catch (e) { return KGP_QUICK_REST_OPACITY; }
}
function _kgpQuickLabel() {
  try { return _kgpIsTaobaoHost(location.hostname) ? String(_kgpRule("tiles.label.taobao", "고가 수집")).slice(0, 12) : "수집"; } catch (e) { return "수집"; }
}
function _kgpMakesStackingContext(el) {
  try {
    var cs = getComputedStyle(el);
    if (cs.transform && cs.transform !== "none") return true;
    if (cs.filter && cs.filter !== "none") return true;
    if (cs.perspective && cs.perspective !== "none") return true;
    if (cs.isolation === "isolate") return true;
    if (cs.mixBlendMode && cs.mixBlendMode !== "normal") return true;
    if (cs.contain && /paint|layout|strict|content/.test(cs.contain)) return true;
    if (cs.willChange && /transform|opacity|filter/.test(cs.willChange)) return true;
    if (cs.opacity !== "" && parseFloat(cs.opacity) < 1) return true;
  } catch (e) {}
  return false;
}
// 앵커(anchor)와 카드(card) 사이(앵커 자신 포함)에 컨텍스트 생성 조상이 있으면 카드로 올린다.
//   카드 자체가 컨텍스트 안이면 더 올릴 수 없지만, 가림막이 카드 하위인 한 카드 층이면 충분하다.
function _kgpEscapeStackingContext(anchor, card) {
  try {
    if (!anchor || !card || anchor === card) return anchor || card;
    var cur = anchor, depth = 0;
    while (cur && cur !== card && depth < 10) {
      if (_kgpMakesStackingContext(cur)) return card;
      cur = cur.parentElement; depth++;
    }
  } catch (e) {}
  return anchor;
}
function _kgpEnsureContainingBlock(el) {
  try {
    if (el && getComputedStyle(el).position === "static") el.style.position = "relative";
  } catch (e) {}
}

// v86 STEP4: [수집] 노출을 **JS 단일 소스**로. 시트 :hover에 기대지 않는다(시트 없이도 보여야 한다는
//   계약과 정합) + 호스트 인라인 !important도 쓰지 않는다(쓰는 순간 복원 불가 유령이 된다 — 두 번 겪었다).
//   데스크톱: 카드/버튼 hover 공통 판정(버튼이 카드 밖으로 삐져나와도 깜빡임 루프가 안 생기게 200ms 유예).
//   터치: 호버가 없으므로 **첫 탭이 노출**(그 탭은 수집을 실행하지 않는다) — 두 번째 탭부터 수집.
function _kgpBindQuickReveal(card, q, badge) {
  var show = function (on) {
    // v86-C: rest=0 — 마우스를 떼면 사라진다(상시 노출 철회). 시트가 아니라 인라인 setProperty로 건다.
    var rest = String(_kgpQuickRestOpacity());
    if (q.dataset.collected !== "1") q.style.setProperty("opacity", on ? "1" : rest);
    if (badge && !KGP_SELECTED.has(badge.dataset.url)) badge.style.setProperty("opacity", on ? "1" : rest);
  };
  q._kgpReveal = show;                       // 재적용(스타일 리셋) 후에도 현재 상태를 되살릴 수 있게 노출
  if (KGP_TOUCH) {
    // F49-T 3부: rest가 0이 아니면 이미 보인다 — 「첫 탭은 노출만」 규칙이 필요 없다(보이는 버튼이 한 번 헛돌면 사고).
    if (_kgpQuickRestOpacity() > 0) { q.dataset.revealed = "1"; show(false); return; }
    // v86-C 터치 폴백: 마우스가 없으니 **첫 탭=노출 · 둘째 탭=실행**. 상시 노출은 화면을 가린다.
    q.dataset.revealed = "0";
    show(false);
    var reveal = function () {
      if (q.dataset.revealed === "1") return;
      q.dataset.revealed = "1";
      show(true);
    };
    try { card.addEventListener("touchstart", reveal, { passive: true }); } catch (e) { card.addEventListener("touchstart", reveal); }
    card.addEventListener("click", reveal);
    return;
  }
  var timer = null;
  var enter = function () { if (timer) { clearTimeout(timer); timer = null; } show(true); };
  var leave = function () {
    if (timer) clearTimeout(timer);
    timer = setTimeout(function () { show(false); timer = null; }, 200);
  };
  card.addEventListener("mouseenter", enter);
  card.addEventListener("mouseleave", leave);
  q.addEventListener("mouseenter", enter);   // 버튼 위로 올라와도 유지
  q.addEventListener("mouseleave", leave);
}
function kgpQuickBtnStyle(collected, mode) {
  return [
    // v80 STEP2: 알리 호버 오버레이(미리보기 팝업)보다 위로 — 캐러셀 카드에서 버튼이 팝업에 가려 클릭 불가 방지.
    "position:absolute !important", "z-index:2147483644 !important",
  ].concat(_kgpAnchorCss(mode)).concat([
    "box-sizing:border-box !important", "width:auto !important", "height:auto !important", "max-width:none !important",
    "display:block !important", "margin:0 !important", "padding:0 !important",
    "background:transparent !important", "border:0 !important", "outline:0 !important", "float:none !important",
    "cursor:pointer", "pointer-events:auto",
    // ★ v86 STEP4 원칙: **가시 UI 호스트 인라인에 !important 금지.**
    //   all:initial(§8-1)과 opacity가 두 번 다 같은 법칙으로 유령을 만들었다 — 인라인 !important는
    //   시트(:hover 포함)로 되돌릴 수 없어, 한 번 숨으면 복원 경로가 원천 봉쇄된다.
    //   노출은 시트가 아니라 **JS 단일 토글**(_kgpBindQuickReveal)이 책임진다 → "시트 없어도 보임" 계약과 정합.
    // v86 STEP4.1(오너 승인): **상시 노출**. 종전 rest=0(호버해야 등장)은 "지금 보이는가"를 매번 의심하게 만들었다.
    //   rest 0.85 · hover 1.0 — 질문 자체를 소멸시키는 게 목적이다. 전환은 여전히 JS 단일 토글(시트 의존 0),
    //   상태전환 속성에 인라인 !important 금지(STEP4 명문화 원칙) 유지.
    // v86-C: 수집된 타일('수집됨 ✓')만 상시 표시. 그 외는 터치·데스크톱 모두 rest=0에서 시작한다.
    "opacity:" + (collected ? "1" : String(_kgpQuickRestOpacity())), "transition:opacity .12s",
  ]).join(";");
}
// shadow 안 알약 CSS — 색 토큰: 먹(#1a1714)·금(#c9a24b), 수집됨=청록(#119a8e).
function _kgpQuickShadowCss() {
  var small = false;
  try { small = _kgpIsTaobaoHost(location.hostname); } catch (e) {}   // F49-T 3부: 타오바오 목록은 작게
  var fs = small ? "13px" : (KGP_TOUCH ? "13px" : "15px");
  var pad = small ? "4px 10px" : (KGP_TOUCH ? "5px 11px" : "6px 14px");
  return ".p{box-sizing:border-box;display:flex;align-items:center;justify-content:center;gap:6px;"
    + "white-space:nowrap;padding:" + pad + ";border-radius:999px;cursor:pointer;"
    + (small ? "min-height:28px;" : "min-height:34px;") + "max-height:44px;background:#1a1714;color:#fff;border:1.5px solid #c9a24b;"
    + "font:800 " + fs + "/1 -apple-system,BlinkMacSystemFont,sans-serif;letter-spacing:-.01em;"
    + "box-shadow:0 3px 12px rgba(0,0,0,.34)}"
    + ".p.on{background:#119a8e;border-color:#0f8c80}"
    + ".i{display:inline-flex;width:14px;height:14px;flex:none;align-items:center;justify-content:center}"
    + ".i svg{display:block;width:14px;height:14px}"
    + ".l{display:inline;white-space:nowrap}";
}
// 호버 버튼의 shadow 내용을 만들고(1회) 상태를 반영한다.
function _kgpBuildQuick(host, collected, text) {
  if (host._kgpShadow === undefined) {
    _kgpShadowHost(host, _kgpQuickShadowCss(),
      '<span class="p"><span class="i">' + KGP_BRIDGE_MINI + '</span><span class="l"></span></span>');
    var r = host._kgpShadow;
    host._kgpPill = r ? r.querySelector(".p") : null;
    host._kgpLbl = r ? r.querySelector(".l") : null;
  }
  if (host._kgpPill) {
    host._kgpPill.setAttribute("class", "p" + (collected ? " on" : ""));
    if (host._kgpLbl && text != null) host._kgpLbl.textContent = text;
  } else if (text != null) {
    host.textContent = text;   // shadow 미지원 구형 폴백(무스타일이라도 클릭 가능한 표식)
  }
}
// 라벨 조회 — shadow 우선, 구형 폴백은 라이트 DOM.
function _kgpQuickLabelEl(btn) {
  if (!btn) return null;
  if (btn._kgpLbl) return btn._kgpLbl;
  try { return btn.querySelector(".kgp-q-label"); } catch (e) { return null; }
}
function kgpMarkQuickCollected(btn) {
  btn.dataset.collected = "1";
  _kgpBuildQuick(btn, true, "수집됨 ✓");                                       // v86 STEP2: shadow 상태·라벨 갱신
  btn.style.cssText = kgpQuickBtnStyle(true, btn.dataset.anchorMode || "");   // v65 STEP3: 앵커 모드 보존
  btn.style.cursor = "default";
}
// v86-F: 목록 타일 수집 페이로드 단일 소스. 타일에는 **제목·이미지(+목록가)만** 있다 —
//   상세·옵션·갤러리·스펙은 구조상 담길 수 없다(그건 상세페이지 수집 또는 보강 큐의 몫).
//   그런데 종전엔 mode를 아예 안 실어 서버가 기본값 'full'로 저장했고, 목록에서 PDP 수집분과
//   구별이 안 됐다(오너 지적: "간이 수집이 full로 저장"). → 타일 경로는 mode:'simple'을 강제한다.
//   ※ 서버도 이 값을 그대로 믿지 않고 실체(상세·옵션·갤러리 유무)로 재검증한다(extension_api).
function _kgpTileMeta(c) {
  return { url: c.url, title: c.title, image: c.image, images: c.images,
           price: c.price, currency: c.currency, mode: "simple" };
}
function kgpQuickCollect(card, btn) {
  if (btn.dataset.collected === "1" || btn.dataset.busy === "1") return;
  btn.dataset.busy = "1";
  const lbl = _kgpQuickLabelEl(btn);
  const prev = lbl ? lbl.textContent : "수집";
  if (lbl) lbl.textContent = "수집 중…";
  const corr = kgpNewCorr();
  const meta = _kgpTileMeta(card);
  meta.corr_id = corr;
  // v86-L: 호버 단건도 echo 기록(경로 분기 봉인) — 종전엔 FAB만 남겨 payload_echo=null이었다.
  _kgpRecordEcho(meta, "hover");
  kgpSendMessage({ action: "collectBulk", items: [meta] }, (resp) => {
    btn.dataset.busy = "";
    if (resp && resp.ok === true && ((resp.success || 0) > 0 || (resp.duplicate || 0) > 0)) {
      _kgpRememberCollected(card.url);
      kgpMarkQuickCollected(btn);
      // v72 STEP3: 호버 단건도 **보강 큐 자동 등록**(벌크 경로와 동일) — 아마존 목록가 미달('-')·옵션·상세를
      //   상세 페이지 방문으로 채운다. 목록 카드 가격/제목은 이미 1차로 담겨 저장됨(meta), 보강은 fill-only.
      const _targets = (resp.enrichTargets || []).filter((t) => t && t.item_id && t.url);
      if (_targets.length) { try { kgpSendMessage({ action: "enrichStart", targets: _targets }, () => {}); } catch (e) {} }
      if ((resp.success || 0) > 0) kgpAlertOnce(corr, () => kgpCelebrate(1));   // 실제 새 수집만 축하(건당 1회·중복은 조용)
      // F49-T 3부: 타오바오·티몰은 목록 카드엔 제목·썸네일·목록가뿐이다 — 상세 페이지(ICE)가 SKU·가격을 채운다.
      //   만든 초안으로 **바로 가는 링크**를 준다(서버가 돌려준 item_id — 없으면 링크를 만들지 않는다).
      const _iid = _targets.length ? String(_targets[0].item_id) : "";
      if (_iid && _kgpIsTaobaoHost(location.hostname)) {
        const _dup = !((resp.success || 0) > 0);
        kgpCollectCard((_dup ? "이미 수집한 상품이에요" : "초안을 만들었어요")
          + " — 상세 페이지에서 SKU·가격을 채우는 중", true,
          [{ label: "초안 열기", fn: () => kgpOpenDraft(_iid) }]);
      }
    } else {
      kgpAlertOnce(corr, () => {
        if (lbl) lbl.textContent = prev;
        kgpToast((resp && resp.error) || "수집 실패", false);
      });
    }
  });
}
// 스캔한 카드 중 이미 수집된 것을 서버에 물어 '수집됨 ✓'로 선표시(중복 방지 연동).
function kgpMarkExisting(cards) {
  const urls = cards.map((c) => _kgpUrlKey(c.url)).filter((u) => u && !_kgpIsCollectedUrl(u));
  if (!urls.length) return;
  kgpSendMessage({ action: "collectExists", urls }, (resp) => {
    if (!resp || !resp.ok || !Array.isArray(resp.collected)) return;
    resp.collected.forEach((u) => _kgpRememberCollected(u));
    document.querySelectorAll(".kgp-card-quick").forEach((q) => {
      if (_kgpIsCollectedUrl(q.dataset.url) && q.dataset.collected !== "1") kgpMarkQuickCollected(q);
    });
  });
}

function kgpUpdateToolbar() {
  const c = _kgpTbQ("#kgp-tb-count");
  if (!c) return;
  // v42 E-4: 정직 표기 — 인식된 상품 수 + 제외(광고 등) 수를 눈에 보이게(조용한 누락 금지).
  // v64 STEP2: 광고(스폰서) 수를 명시(오너가 분류 정합을 눈으로 검증). 제외=구조적 비상품(광고 아님).
  // v67 STEP1: 카운트 표기 [메인 n / 추천 m / 광고 k] — 버튼은 전 타일 부착, 카운트만 구분.
  const ads = _kgpAdCount(), reco = _kgpRecoCount(), main = _kgpMainCount();
  const recoTxt = reco ? ` · 추천 ${reco}` : "";
  const adTxt = ads ? ` · 광고 ${ads}` : "";
  // F49-T 4부: 스크롤로 새로 붙은 상품 수(첫 스캔 이후) · 선택 수는 **상품 키** 기준(같은 상품 URL 변형 1개로).
  const newTxt = KGP_WATCH.new_cards ? ` · 새 상품 +${KGP_WATCH.new_cards}` : "";
  c.textContent = `메인 ${main}${recoTxt}${adTxt}${newTxt} · ${_kgpSelKeys.size || KGP_SELECTED.size}개 선택`;
}

function kgpCollect(urls, opts) {
  const _seenK = new Set();
  urls = (urls || []).filter((u) => { let k = u; try { k = _kgpCardKey(u); } catch (e) {} if (_seenK.has(k)) return false; _seenK.add(k); return true; });
  const items = (urls || []).map(u => _kgpCardByUrl[u]).filter(Boolean).map(c => (
    _kgpTileMeta(c)
  ));
  if (!items.length) { kgpSetStatus("선택된 상품이 없어요. 상품의 ‘수집’ 배지를 눌러 선택하세요."); return; }
  kgpRunBulk(items, opts);
}

// v42 E-5: 벌크 실행 코어 — 정직 요약(완료/중복/실패) + 실패 항목 재시도. 전체수집·선택수집·재시도가 공용.
// v72b STEP3: opts.force=true면 각 항목에 force 플래그 → 서버가 기존 레코드를 덮어씀(신규 행 금지, '다시 수집').
function kgpRunBulk(items, opts) {
  if (!items || !items.length) return;
  if (opts && opts.force) items.forEach(it => { if (it) it.force = true; });
  kgpSetStatus(`수집 중… (0/${items.length})`);
  const btns = _kgpTbAll(".kgp-tb-btn");
  btns.forEach(b => b.disabled = true);
  const oldRetry = _kgpTbQ("#kgp-tb-retry");
  if (oldRetry) oldRetry.remove();
  // v86-L: 벌크도 echo 기록 — 대표(items[0]) 요약 + items_n. path=재시도면 bulk-retry.
  _kgpRecordEcho(items[0] || {}, (opts && opts.retry) ? "bulk-retry" : "bulk", { items_n: items.length });
  kgpSendMessage({ action: "collectBulk", items }, (resp) => {
    btns.forEach(b => b.disabled = false);
    if (!resp || resp.ok !== true) { kgpSetStatus(((resp && resp.error) || "수집 실패")); return; }
    if (resp.success > 0) kgpCelebrate(resp.success);   // 실제(중복 제외) 성공 건수만 축하
    const dup = resp.duplicate || 0, fail = resp.failed || 0;
    let msg = `총 ${resp.total}: 완료 ${resp.success}`;
    if (dup) msg += ` · 중복 ${dup}`;
    if (fail) msg += ` · 실패 ${fail}`;
    msg += fail ? " — 아래 ‘재시도’를 누르세요." : ". 셀러 콘솔 수집 이력에서 확인하세요.";
    kgpSetStatus(msg);
    kgpRenderRetry(resp.failedItems || []);   // 실패분만 재시도 버튼
    // v64 STEP1: 2단 상세 보강 시작 — 목록 저장분(item_id)을 백그라운드 탭으로 순차 방문해 보강.
    const targets = resp.enrichTargets || [];
    if (targets.length) {
      kgpSendMessage({ action: "enrichStart", targets }, (er) => {
        if (er && er.ok) kgpSetStatus(msg + ` · 상세 보강 시작(0/${er.total})`);
      });
    }
  });
}

// v64 STEP1: 상세 보강 진행률을 벌크바 상태에 실시간 표시(background가 1건마다 전송).
try {
  chrome.runtime.onMessage.addListener((m) => {
    if (m && m.action === "enrichProgress" && m.state) {
      const s = m.state;
      if (s.total > 0 && document.getElementById(KGP_TOOLBAR_ID)) {
        let t = `상세 보강 ${s.done}/${s.total}`;
        if (s.failed) t += ` · 보강 실패 ${s.failed}`;
        if (s.paused) t += " · 일시정지";
        else if (!s.running && s.done >= s.total) t += " · 완료";
        kgpSetStatus(t);
        kgpRenderEnrichRetry(s.failures || []);   // F49-T 5부: 실패 항목(사유) + 「다시」
      }
    }
    return false;
  });
} catch (e) { /* noop */ }

// F49-T 5부: 상세 보강 실패 항목 — 사유를 보이고(title) 「보강 다시」로 같은 큐에 다시 넣는다.
function kgpRenderEnrichRetry(failures) {
  const old = _kgpTbQ("#kgp-tb-enrich-retry");
  if (old) old.remove();
  if (!failures || !failures.length) return;
  const tb = document.getElementById(KGP_TOOLBAR_ID);
  if (!tb) return;
  const b = document.createElement("button");
  b.id = "kgp-tb-enrich-retry";
  b.className = "kgp-tb-btn";
  b.textContent = `보강 실패 ${failures.length}건 다시`;
  b.title = failures.slice(0, 8).map((f) => "· " + (f.reason || "사유 없음")).join("\n");
  b.setAttribute("style", "background:#f5821f;color:#fff;border:0;border-radius:8px;padding:6px 12px;font-weight:700;font-size:15px;cursor:pointer;min-height:40px;display:inline-flex;align-items:center");
  b.addEventListener("click", () => {
    const targets = failures.map((f) => ({ item_id: f.item_id, url: f.url }));
    kgpSendMessage({ action: "enrichStart", targets }, () => {});
    b.remove();
  });
  (_kgpTbRoot() || tb).appendChild(b);
}

// 실패 항목 재시도 버튼(정직: 조용한 누락 금지 — 실패 N건을 눈에 보이게).
function kgpRenderRetry(failedItems) {
  const old = _kgpTbQ("#kgp-tb-retry");
  if (old) old.remove();
  if (!failedItems || !failedItems.length) return;
  const tb = document.getElementById(KGP_TOOLBAR_ID);
  if (!tb) return;
  const b = document.createElement("button");
  b.id = "kgp-tb-retry";
  b.className = "kgp-tb-btn";
  b.textContent = `실패 ${failedItems.length}건 재시도`;
  // v86 STEP2: 벌크바 내부(shadow) 요소 — 격리는 shadow 경계가 하므로 all:initial 불필요. 색만 자립 선언.
  b.setAttribute("style", "background:#f5821f;color:#fff;border:0;border-radius:8px;padding:6px 12px;font-weight:700;font-size:15px;cursor:pointer;min-height:40px;display:inline-flex;align-items:center");
  b.addEventListener("click", () => kgpRunBulk(failedItems));
  (_kgpTbRoot() || tb).appendChild(b);
}

function kgpBuildToolbar() {
  const bar = document.createElement("div");
  bar.id = KGP_TOOLBAR_ID;
  // v86 STEP2: 호스트에는 **위치 계열만**(+중립화). 실제 바(먹 알약·플렉스 행)는 shadow 안에서 그린다.
  //   v73 STEP1 회귀(top:auto로 정적 흐름 낙하)의 원인이 곧 all:initial 인라인 전개였으므로, 그 근원을 없애고
  //   위치는 !important로 유지한다. 사이트 상속 오염 차단은 shadow 경계가 담당(과대 차단 목적 달성).
  bar.style.cssText = [
    "position:fixed !important", "top:12px !important", "left:50% !important", "transform:translateX(-50%) !important",
    "z-index:2147483647 !important", "display:block !important", "max-width:96vw !important",
    "margin:0 !important", "padding:0 !important", "background:transparent !important",
    "border:0 !important", "outline:0 !important", "float:none !important",
  ].join(";");
  _kgpPinFixed(bar, { top: "12px", left: "50%", transform: "translateX(-50%)" });   // v84 STEP1: 위치 재확정
  // 버튼 위계: 전체 수집=청록 채움(Primary), 선택 수집=금 아웃라인(Secondary), 전체선택/해제=고스트. (+25% 확대)
  // v86 STEP2: shadow 안이라 사이트 button 규칙이 닿지 않는다 → all:initial·!important 도배 폐기, 평범한 CSS로.
  //   v74 STEP2가 막던 '색 유령화'(all:initial의 color:initial이 버튼색을 덮음)도 그 원인이 사라져 자연 해소.
  const autoOn = kgpLSget("kgp_bar_auto", "1") !== "0";
  const css = ".bar{box-sizing:border-box;display:flex;align-items:center;gap:12px;padding:10px 18px;"
    + "border-radius:999px;border:1px solid #c9a24b;background:#1a1714;color:#f5efe3;"
    + "font:16px/1.2 -apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;"
    + "box-shadow:0 8px 24px rgba(0,0,0,.45);max-width:96vw;flex-wrap:wrap}"
    + ".kgp-tb-btn,button{box-sizing:border-box;padding:7px 14px;border-radius:9px;cursor:pointer;font-weight:700;"
    + "font-size:15px;line-height:1;min-height:40px;display:inline-flex;align-items:center;font-family:inherit}"
    + ".ghost{background:transparent;color:#e7ddc9;border:1px solid #4a4234}"
    + ".gold{background:transparent;color:#e8d6a8;border:1.5px solid #c9a24b}"
    + ".teal{background:#119a8e;color:#fff;border:1px solid #0f8c80}"
    + "#kgp-tb-grip{display:flex;align-items:center;gap:7px;color:#f5efe3}"
    + "#kgp-tb-grip strong{color:#ecdcb0}"
    + ".mark{display:flex;align-items:center;justify-content:center;width:33px;height:33px;background:transparent;border:0}"
    + ".mark svg{display:block}"
    + "#kgp-tb-count{opacity:.85;color:#f5efe3}"
    + ".sep{width:1px;height:22px;background:#4a4234}"
    + "#kgp-tb-status{opacity:.95;font-size:15px;max-width:420px;color:#f5efe3}"
    + ".x{background:transparent;color:#c9bda6;border:none;font-size:19px}";
  const html =
    '<div class="bar">' +
    '<span id="kgp-tb-grip"><span class="mark">' + KGP_BRIDGE_SVG + '</span>' +
    '<strong>고가수집기</strong></span>' +
    '<span id="kgp-tb-count"></span>' +
    '<span class="sep"></span>' +
    '<button class="kgp-tb-btn ghost" data-act="all-sel">전체 선택</button>' +
    '<button class="kgp-tb-btn ghost" data-act="clear">선택 해제</button>' +
    '<button class="kgp-tb-btn gold" data-act="collect-sel">선택 수집</button>' +
    '<button class="kgp-tb-btn teal" data-act="collect-all">전체 수집</button>' +
    '<button class="kgp-tb-btn gold" data-act="recollect" title="선택 상품을 최신 추출기로 다시 수집(기존 항목 갱신·신규 생성 안 함) — 가격 ‘-’·구버전 잔재 세탁">다시 수집</button>' +
    '<button class="kgp-tb-btn ghost" data-act="incl-reco" title="전체선택·전체수집에 추천/캐러셀 상품을 포함할지">' + (_kgpInclReco() ? '추천 포함 ✓' : '추천 포함') + '</button>' +
    '<button class="kgp-tb-btn ghost" data-act="incl-ads" title="전체선택·전체수집에 광고(스폰서) 상품을 포함할지">' + (_kgpInclAds() ? '광고 포함 ✓' : '광고 포함') + '</button>' +
    '<span id="kgp-tb-status"></span>' +
    '<button class="kgp-tb-btn ghost" data-act="auto" title="새 목록 페이지에서 자동으로 열지 여부">' + (autoOn ? '자동' : '수동') + '</button>' +
    '<button class="kgp-tb-btn x" data-act="close" title="접기(구석 배지로)">✕</button>' +
    '</div>';
  if (!_kgpShadowHost(bar, css, html)) bar.innerHTML = html;   // 구형 폴백: 라이트 DOM(무스타일이라도 동작)
  (bar._kgpShadow || bar).addEventListener("click", (e) => {   // v86 STEP2: shadow 안에서 위임(retarget 회피)
    const t = e.target.closest("[data-act]");
    if (!t) return;
    const act = t.dataset.act;
    if (act === "all-sel") {
      // v64 STEP2: 전체선택 = 실상품 전체(광고 제외, '광고 포함' 켜면 전부).
      // F49-T 4부: 「전체 선택」 = **지금까지 탐지된 전부**(체크박스가 아직 안 붙은 카드 포함). 예전엔 DOM의
      //   체크박스만 돌아서 스크롤로 붙은 카드는 선택되지 않았다(오너 world.taobao 실측).
      const pick = _kgpSelectableUrls();
      pick.forEach((url) => {
        const c = _kgpCardByUrl[url];
        const b = (c && c.el && c.el.querySelector) ? c.el.querySelector(":scope > .kgp-card-chk") : null;
        kgpSetCardSelected(url, b, b ? (c && c.el) : null, true);
      });
      kgpUpdateToolbar();
    } else if (act === "incl-ads") {
      const next = _kgpInclAds() ? "0" : "1";
      kgpLSset("kgp_incl_ads", next);
      t.textContent = next === "1" ? "광고 포함 ✓" : "광고 포함";
      kgpUpdateToolbar();
    } else if (act === "incl-reco") {
      const next = _kgpInclReco() ? "0" : "1";
      kgpLSset("kgp_incl_reco", next);
      t.textContent = next === "1" ? "추천 포함 ✓" : "추천 포함";
      kgpUpdateToolbar();
    } else if (act === "clear") {
      document.querySelectorAll(".kgp-card-chk").forEach((b) => {
        const url = b.dataset.url;
        const c = _kgpCardByUrl[url];
        kgpSetCardSelected(url, b, c && c.el, false);
      });
      KGP_SELECTED.clear();
      _kgpSelKeys.clear();
      kgpUpdateToolbar();
    } else if (act === "collect-sel") {
      kgpCollect([...KGP_SELECTED]);
    } else if (act === "collect-all") {
      kgpCollect(_kgpSelectableUrls());          // v64 STEP2: 광고 제외(광고 포함 토글로 전부)
    } else if (act === "recollect") {
      // v72b STEP3: 선택 상품을 force로 다시 수집 → 서버가 기존 레코드 덮어씀(신규 생성 0).
      //   구버전 수집분('-' 가격·잔재)을 최신 추출기로 세탁하는 통로. 선택 없으면 안내.
      const sel = [...KGP_SELECTED];
      if (!sel.length) { kgpSetStatus("먼저 다시 수집할 상품의 ‘수집’ 배지를 눌러 선택하세요."); return; }
      kgpCollect(sel, { force: true });
    } else if (act === "auto") {
      // 팝업 자동표시 on/off(v7). 끄면 지금 접고, 이후 목록 페이지는 구석 배지로만 시작.
      const next = kgpLSget("kgp_bar_auto", "1") === "0" ? "1" : "0";
      kgpLSset("kgp_bar_auto", next);
      t.textContent = next === "0" ? "수동" : "자동";
      if (next === "0") {
        _kgpClosed = true;
        bar.remove();
        // v86-D: 바를 접어도 **호버 수집버튼은 남는다**(오너 확정 UX). chk만 걷는다.
        //   v86-C가 kgpInjectListing 경로만 고쳐서, 이 핸들러가 그 자리에서 버튼을 지우면
        //   재스캔이 뜨기 전까지(정적 페이지면 영영) 버튼이 사라진 채 남았다 — 라이브 tile_quick_n 0의 경로.
        document.querySelectorAll(".kgp-card-chk").forEach((b) => b.remove());
        _kgpReensureQuick();
        kgpShowReopenPill();
      } else {
        kgpSetStatus("이제 목록 페이지에서 자동으로 열려요.");
      }
    } else if (act === "close") {
      // 접으면 같은 페이지에서 자동으로 다시 뜨지 않게 한다(URL 변경 시 초기화).
      // 대신 구석에 작은 '고가수집기 열기' 배지(선택 개수·펄스)를 남긴다(선택은 유지).
      // v86-D: 여기서도 chk만 걷는다 — 호버 수집버튼은 바와 무관하게 살아 있어야 한다.
      _kgpClosed = true;
      bar.remove();
      document.querySelectorAll(".kgp-card-chk").forEach((b) => b.remove());
      _kgpReensureQuick();
      kgpShowReopenPill();
    }
  });
  _kgpMount(bar);                          // v45 P4: <html> 직속(상단중앙 고정, 좌상단 처박힘 방지)
  try { _kgpKeepBarPinned(); } catch (e) {}  // v64 STEP4: 마운트 즉시 뷰포트 상단 고정 보정(변형 조상 대응)
  // 드래그로 이동 + 위치 기억(grip 영역만 잡기, 버튼 클릭은 드래그 제외).
  kgpMakeDraggable(bar, "kgp_bar_pos", { handle: bar, ignore: "button,[data-act]" });
}

const KGP_REOPEN_ID = "kgp-listing-reopen";

// 접었을 때 구석에 작은 '고가수집기 열기' 배지 → 클릭 시 바를 다시 띄운다.
// 선택 개수 뱃지 + (선택 있으면) 청록 펄스. 드래그로 옮기면 위치 기억(kgp_bar_pos).
function kgpShowReopenPill() {
  let pill = document.getElementById(KGP_REOPEN_ID);
  const sel = KGP_SELECTED.size;
  if (pill) {   // 이미 있으면 개수/펄스만 갱신
    const cnt = pill.querySelector(".kgp-pill-count");
    if (cnt) cnt.textContent = sel ? String(sel) : "";
    if (cnt) cnt.style.display = sel ? "inline-block" : "none";
    pill.style.animation = (sel && !KGP_RM) ? "kgpPulse 1.6s ease-in-out infinite" : "none";
    return;
  }
  if (!document.body) return;
  kgpEnsureStyles();
  pill = document.createElement("button");
  pill.id = KGP_REOPEN_ID;
  pill.type = "button";
  pill.title = "고가수집기 바 열기";
  pill.innerHTML =
    '<span style="display:flex;align-items:center;justify-content:center;width:22px;height:22px;background:transparent;border:0">' + KGP_BRIDGE_SVG + '</span>' +
        // v86-D: 이 배지가 여는 건 벌크바다. 바 그립 타이틀이 '고가수집기'이므로 명칭을 그쪽에 맞춘다
    //   ('수집 열기'는 타일 호버 버튼과 혼동됐다 — 오너가 rest 노출 요소로 오인).
    '<span style="font-weight:700;font-size:12px">고가수집기 열기</span>' +
    '<span class="kgp-pill-count" style="display:' + (sel ? "inline-block" : "none") + ';background:#119a8e;color:#fff;border-radius:999px;padding:1px 7px;font-size:11px;font-weight:800">' + (sel || "") + '</span>';
  pill.style.cssText = [
    "position:fixed", "top:12px", "left:12px", "z-index:2147483647",
    "display:flex", "align-items:center", "gap:6px", "padding:5px 10px 5px 6px",
    "border:1px solid #c9a24b", "border-radius:999px",
    "background:#1a1714", "color:#f5efe3",
    "cursor:pointer", "box-shadow:0 4px 14px rgba(0,0,0,.45)",
    "font:12px/1 -apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif",
    (sel && !KGP_RM) ? "animation:kgpPulse 1.6s ease-in-out infinite" : "",
  ].join(";");
  pill.addEventListener("click", () => {
    if (pill._kgpDragged) return;     // 드래그였으면 클릭 무시
    pill.remove();
    _kgpClosed = false;
    kgpInjectListing();               // 바 + 배지 복원(선택 유지)
  });
  _kgpMount(pill);                         // v45 P5: <html> 직속(본문 재렌더에도 상시 표시)
  kgpMakeDraggable(pill, "kgp_bar_pos", {});
}

let _kgpAutoApplied = false;       // 이 페이지에서 '수동(auto off)' 초기 접힘을 한 번만 적용

// v86-D: 바를 접는 순간에도 호버 수집버튼을 즉시 되붙인다(재스캔을 기다리지 않는다).
//   정적 목록 페이지는 MutationObserver가 안 뜨므로, 기다리면 영영 버튼이 없는 상태가 된다.
function _kgpReensureQuick() {
  try {
    (_kgpCards || []).forEach(function (c) { if (c && c.el) _kgpEnsureTileQuick(c, null); });
  } catch (e) { /* noop */ }
}

// v86-C: 타일 호버 수집버튼 주입을 **벌크바 상태에서 분리**한다.
//   종전엔 바가 닫히면(_kgpClosed) .kgp-card-quick까지 같이 지우고 early return해서, 목록을 열어도
//   바를 열기 전엔 타일 버튼이 아예 없었다(오너 실측: 라쿠텐 검색 merged 37 · tile_quick_n 0 · bar false).
//   버튼은 목록이 감지되면 **항상** 붙는다. 벌크바 토글은 체크박스(chk) 표시/숨김만 관장한다.
//   badge는 바가 닫혀 있으면 null — _kgpBindQuickReveal이 null을 견딘다.
function _kgpEnsureTileQuick(c, badge) {
  try {
    // v42 E-3 / v65 STEP3: 호버 즉시 수집 버튼 — 카드 우측 허공이 아니라 **상품 이미지 요소 위**에 앵커.
    //   이미지를 못 찾으면 카드 좌상단 폴백(mode=corner, 허공 금지). 데스크톱=hover 노출/터치=우상단 상시.
    // v77 STEP1: 멱등 — 타일당 [수집] 최대 1개. 이중 감지 시 콘솔 경고 후 잉여 제거.
    let _quicks = c.el.querySelectorAll(":scope .kgp-card-quick");
    if (_quicks.length > 1) {
      console.warn("[고가수집기] 타일 중복 수집버튼 감지·정리", _quicks.length, c.url);
      for (let _i = 1; _i < _quicks.length; _i++) _quicks[_i].remove();
    }
    // v86 STEP3: **업그레이드 경로** — 이미 [수집] 버튼이 있으면 재생성하지 않는(멱등) 설계라,
    //   shadow 없이 만들어진 옛 버전(1.5.126 이하)의 버튼이 페이지에 남아 있으면 그대로 채택돼
    //   영영 유령(투명·무배경)으로 남는다. 확장 업데이트 직후 열려 있던 탭·SPA 복원·저장된 스냅샷이
    //   전부 이 경우다(오너 실측 스냅샷에서 quick 24개 in_shadow=false로 재현).
    //   → shadow가 없는 잔존 버튼은 **버리고 다시 만든다**(체크박스는 _kgpBuildCheckbox가 매번 보정).
    if (_quicks.length === 1 && !_quicks[0]._kgpShadow) {
      try { _quicks[0].remove(); } catch (e) {}
      _quicks = c.el.querySelectorAll(":scope .kgp-card-quick");
    }
    if (!_quicks.length) {
      const done = _kgpIsCollectedUrl(c.url);
      const imgEl = _kgpCardImage(c.el);
      // v80 STEP2: 알리 등 카드 내 캐러셀(호버 시 이미지 자동 슬라이드)은 img의 부모(슬라이드)가 매 전환마다
      //   교체됨 → img 부모 앵커는 좌표 재배치·버튼 증발. 이미지가 캐러셀 안이면 **안정 컨테이너**(가장 바깥
      //   캐러셀 조상 = 슬라이드 상위, 교체 안 됨)에 앵커해 좌표 고정. 아니면 이미지 래퍼(정밀 유지).
      //   ※ closest는 슬라이드(swiper-slide도 'swiper' 매치)를 잡으므로, c.el까지 올라가며 **최외곽 매치**를 유지.
      let host = c.el;
      if (imgEl && imgEl.parentElement) {
        let carousel = null, cur = imgEl.parentElement, depth = 0;
        const _carRe = /(carousel|swiper|slider|slick|gallery|magnifier)/i;
        while (cur && cur !== c.el && depth < 8) {
          let tok = "";
          try { tok = ((cur.className && cur.className.baseVal !== undefined ? cur.className.baseVal : (cur.className || "")) + " " + ((cur.getAttribute && cur.getAttribute("aria-roledescription")) || "")); } catch (e) {}
          if (_carRe.test(tok)) carousel = cur;   // 계속 올라가며 갱신 → 최종=최외곽(안정 컨테이너)
          cur = cur.parentElement; depth++;
        }
        host = carousel || imgEl.parentElement;
      }
      // v86 STEP4.1: **스태킹 컨텍스트 탈출.** 알리 실측(스냅샷)에서 버튼은 좌표·크기 모두 정상인데
      //   center_hit=false였다. 원인은 앵커 표류가 아니라 **가림**이었다 — 앵커 조상(DIV.nh_nj)에 transform이
      //   걸려 스태킹 컨텍스트가 생기고, 그 안에서는 우리 z-index(2147483644)가 **컨텍스트 내부로 갇힌다**.
      //   그래서 바깥의 카드 오버레이(z-index:1짜리)가 우리 위에 그려져 클릭을 가로챈다.
      //   → 앵커와 카드 사이에 컨텍스트 생성 조상이 있으면 **카드 요소로 올려 붙인다**(그 층에서 z가 다시 유효).
      host = _kgpEscapeStackingContext(host, c.el);
      const mode = imgEl ? "" : "corner";
      const q = document.createElement("div");
      q.className = "kgp-card-quick";
      q.dataset.url = c.url;
      q.dataset.anchorMode = mode;
      if (done) q.dataset.collected = "1";
      // v86 STEP2: 알약은 shadow 안에서 그린다(사이트 span{…!important} 오염은 shadow 경계가 차단).
      q.style.cssText = kgpQuickBtnStyle(done, mode);
      _kgpBuildQuick(q, done, done ? "수집됨 ✓" : _kgpQuickLabel());
      q.addEventListener("click", (e) => {
        e.preventDefault(); e.stopPropagation();
        // v86-C 터치: 아직 안 보이는 상태의 첫 탭은 **노출만** 한다(보이지 않는 버튼이 수집되면 사고).
        if (KGP_TOUCH && q.dataset.revealed !== "1") {
          q.dataset.revealed = "1";
          if (q._kgpReveal) q._kgpReveal(true);
          return;
        }
        kgpQuickCollect(c, q);
      });
      _kgpBindQuickReveal(c.el, q, badge);
      _kgpEnsureContainingBlock(host);
      host.appendChild(q);
      c.el.dataset.kgp = "done";   // v77 STEP1: 멱등 마킹(주입 완료 타일)
    }
  } catch (e) { /* noop */ }
}

// F49-T 4부: 스캔 한 번 = 탐지 + 부착. 시간·개수를 재서 page_diag(watch)에 싣는다(측정 없이 「된다」 금지).
function kgpInjectListing() {
  const t0 = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
  try { _kgpInjectListingInner(); } finally {
    try {
      const ms = ((typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now()) - t0;
      KGP_WATCH.scan_count += 1;
      KGP_WATCH.last_scan_ms = Math.round(ms * 10) / 10;
      KGP_WATCH.max_scan_ms = Math.max(KGP_WATCH.max_scan_ms, KGP_WATCH.last_scan_ms);
      KGP_WATCH.last_scan_at = new Date().toISOString();
      const keys = _kgpDetectedKeys();
      KGP_WATCH.cards_total = keys.size;
      if (_kgpInitialKeys === null && keys.size >= 3) _kgpInitialKeys = new Set(keys);
      KGP_WATCH.new_cards = _kgpInitialKeys ? Array.from(keys).filter((k) => !_kgpInitialKeys.has(k)).length : 0;
      KGP_WATCH.cards_tiled = document.querySelectorAll(".kgp-card-quick").length;
      KGP_WATCH.containers = _kgpWatchContainersEls.length;
      _kgpWatchObserveContainers();
      kgpUpdateToolbar();
    } catch (e) { /* noop */ }
  }
}

// F49-T 4부(성능): 타일 하나 붙이는 데 약 2.5ms(shadow·레이아웃 읽기 — 300장 합성 실측). 큰 목록에서 한 번에
//   붙이면 첫 스캔이 200ms+ 메인 스레드를 잡는다 → **12ms 조각**으로 나눠 다음 태스크로 넘긴다.
const _kgpAttachQ = { items: [], fn: null, timer: null };
function _kgpAttachBudgeted(list, fn) {
  _kgpAttachQ.items = _kgpAttachQ.items.concat(list || []);
  _kgpAttachQ.fn = fn;
  if (!_kgpAttachQ.timer) _kgpAttachQ.timer = setTimeout(_kgpAttachChunk, 0);   // 스캔 태스크 밖에서
}
function _kgpAttachChunk() {
  _kgpAttachQ.timer = null;
  const t0 = performance.now();
  while (_kgpAttachQ.items.length && performance.now() - t0 < 12) {
    const c = _kgpAttachQ.items.shift();
    try { if (c && c.el && c.el.isConnected) _kgpAttachQ.fn(c); } catch (e) { /* noop */ }
  }
  KGP_WATCH.max_chunk_ms = Math.max(KGP_WATCH.max_chunk_ms || 0, Math.round((performance.now() - t0) * 10) / 10);
  KGP_WATCH.cards_tiled = document.querySelectorAll(".kgp-card-quick").length;
  if (_kgpAttachQ.items.length) _kgpAttachQ.timer = setTimeout(_kgpAttachChunk, 0);
}
// 읽기(레이아웃) 먼저 전부 → 쓰기(지연 표식·옵저버) 나중. 카드마다 읽고 쓰면 매번 스타일 재계산이 돈다.
function _kgpPartitionNear(cards) {
  const lazyAfter = Number(_kgpRule("list_watch.lazy_after", 150)) || 150;
  const lazy = (cards.length > lazyAfter) && (typeof IntersectionObserver === "function");
  KGP_WATCH.lazy = lazy;
  if (!lazy) return cards.slice();
  const margin = Number(_kgpRule("list_watch.lazy_margin_px", 900)) || 900;
  const vh = window.innerHeight || 800;
  const near = [], far = [];
  cards.forEach((c) => {
    let r = null;
    try { r = c.el.getBoundingClientRect(); } catch (e) { r = null; }
    if (!r || (r.bottom > -margin && r.top < vh + margin)) near.push(c); else far.push(c);
  });
  far.forEach((c) => { _kgpShouldAttachNow(c, true); });
  return near;
}
const _kgpLazyIO = { io: null, margin: 0 };
function _kgpShouldAttachNow(c, knownFar) {
  const margin = Number(_kgpRule("list_watch.lazy_margin_px", 900)) || 900;
  if (!knownFar) {
    const lazyAfter = Number(_kgpRule("list_watch.lazy_after", 150)) || 150;
    const lazy = (_kgpCards.length > lazyAfter) && (typeof IntersectionObserver === "function");
    KGP_WATCH.lazy = lazy;
    if (!lazy) return true;
    try {
      const r = c.el.getBoundingClientRect();
      if (r.bottom > -margin && r.top < (window.innerHeight || 800) + margin) return true;
    } catch (e) { return true; }
  }
  if (!_kgpLazyIO.io || _kgpLazyIO.margin !== margin) {
    try { if (_kgpLazyIO.io) _kgpLazyIO.io.disconnect(); } catch (e) {}
    _kgpLazyIO.margin = margin;
    _kgpLazyIO.io = new IntersectionObserver((entries) => {
      entries.forEach((en) => {
        if (!en.isIntersecting) return;
        try { _kgpLazyIO.io.unobserve(en.target); } catch (e) {}
        const url = en.target.getAttribute("data-kgp-lazy") || "";
        en.target.removeAttribute("data-kgp-lazy");
        const card = _kgpCardByUrl[url];
        if (card && card.el === en.target) {
          _kgpAttachBudgeted([card], _kgpClosed ? ((c) => _kgpEnsureTileQuick(c, null)) : _kgpAttachCard);
        }
      });
      KGP_WATCH.lazy_pending = document.querySelectorAll("[data-kgp-lazy]").length;
      KGP_WATCH.cards_tiled = document.querySelectorAll(".kgp-card-quick").length;
    }, { rootMargin: margin + "px 0px" });
  }
  if (!c.el.hasAttribute("data-kgp-lazy")) {
    c.el.setAttribute("data-kgp-lazy", c.url);
    try { _kgpLazyIO.io.observe(c.el); } catch (e) { return true; }
    KGP_WATCH.lazy_pending = (KGP_WATCH.lazy_pending || 0) + 1;
  }
  return false;
}

function _kgpAttachCard(c) {
    try {
      const existing = c.el.querySelector(":scope > .kgp-card-chk");
      const sel = _kgpIsSel(c.url);
      if (sel && !KGP_SELECTED.has(c.url)) KGP_SELECTED.add(c.url);   // F49-T 4부: 키로 선택된 상품의 새 URL 형태
      if (existing) {
        // v71 STEP4: 가상화(재사용 노드) 대응 — 이 카드 요소가 스크롤로 다른 상품에 재사용됐으면 배지 url 갱신.
        existing.dataset.url = c.url;
        existing._kgpEl = c.el;
        existing.style.cssText = kgpCardBadgeStyle(sel);
        _kgpBuildCheckbox(existing, sel);   // v80 STEP1: shadow 체크박스 갱신(텍스트 배지 폐기)
        if (sel) { c.el.style.outline = "3px solid #119a8e"; c.el.style.outlineOffset = "-3px"; c.el.setAttribute("data-kgp-outline", "1"); }
        else { c.el.style.outline = ""; c.el.removeAttribute("data-kgp-outline"); }
        _kgpEnsureTileQuick(c, existing);   // v86-C: 사이트 재렌더로 버튼만 날아간 타일 복구(멱등)
        return;
      }
      _kgpEnsureContainingBlock(c.el);   // v86 STEP4: 아마존 전용이던 처리를 전 사이트 공통으로
      const badge = document.createElement("div");
      badge.className = "kgp-card-chk";
      badge.dataset.url = c.url;
      badge._kgpEl = c.el;
      badge.setAttribute("role", "checkbox");
      badge.setAttribute("aria-label", "상품 선택");
      badge.style.cssText = kgpCardBadgeStyle(sel);
      _kgpBuildCheckbox(badge, sel);   // v80 STEP1: shadow 체크박스(먹 원+금 체크)
      if (sel) { c.el.style.outline = "3px solid #119a8e"; c.el.style.outlineOffset = "-3px"; c.el.setAttribute("data-kgp-outline", "1"); }
      badge.addEventListener("click", (e) => {
        e.preventDefault(); e.stopPropagation();
        kgpToggleCard(badge.dataset.url, badge, badge._kgpEl || c.el);   // v71 STEP4: dataset.url(가상화 갱신 반영)
      });
      c.el.appendChild(badge);

      // v64 STEP2: 광고(스폰서) 카드는 우상단 'AD' 미니 배지로 시각화(오너가 분류 오판을 눈으로 검증).
      //   토큰 준수(먹 배경·금 테). 실상품이므로 카드는 살리되, 전체선택은 기본 제외(광고 포함 토글로 켬).
      if (c.sponsored && !c.el.querySelector(":scope > .kgp-card-ad")) {
        const ad = document.createElement("div");
        ad.className = "kgp-card-ad";
        ad.textContent = "AD";
        ad.style.cssText = [
          "position:absolute", "top:6px", "right:6px", "z-index:2147483640",
          "padding:2px 7px", "border-radius:6px", "pointer-events:none", "user-select:none",
          "font:800 10px/1.4 -apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif",
          "letter-spacing:.06em", "background:#1a1714", "color:#e8d6a8", "border:1px solid #c9a24b",
        ].join(";");
        c.el.appendChild(ad);
      }

      _kgpEnsureTileQuick(c, badge);
    } catch (e) { /* noop */ }
}

function _kgpInjectListingInner() {
  if (window.top !== window.self || !document.body) return;
  if (!kgpHostAllowed() && !kgpEntrySession()) { kgpTeardown(); return; }   // 지정 소싱처 또는 앱 진입(v10/v17)
  const cards = kgpFindCards();
  if (cards.length < 3) {                        // 리스팅 아님 → 정리(배지/바/배지펄스 제거)
    const ex = document.getElementById(KGP_TOOLBAR_ID);
    if (ex) { ex.remove(); document.querySelectorAll(".kgp-card-chk, .kgp-card-quick").forEach((b) => b.remove()); }
    const _pill = document.getElementById(KGP_REOPEN_ID);
    if (_pill) _pill.remove();
    return;
  }
  // '수동' 설정이면 새 목록 페이지를 접힌(배지) 상태로 시작(v7 팝업 on/off).
  if (!_kgpAutoApplied) {
    _kgpAutoApplied = true;
    if (kgpLSget("kgp_bar_auto", "1") === "0") _kgpClosed = true;
  }
  // 재스캔(무한스크롤/동적로딩)에도 선택을 지우지 않는다.
  // ★중요★ 카드맵을 비우지 않고 '병합'한다 — 비우면 선택된 url의 카드 데이터가 사라져
  //   '선택 수집/전체 수집'이 '선택된 상품 없음'으로 실패하던 버그(오너 리포트) 방지.
  _kgpCards = cards;
  cards.forEach((c) => { _kgpCardByUrl[c.url] = c; });
  if (_kgpClosed) {                              // 접힘 → 구석 배지(개수·펄스)만 유지
    const ex = document.getElementById(KGP_TOOLBAR_ID);
    // v86-C: 닫으면 **체크박스만** 걷는다. 호버 수집버튼은 바와 무관하게 살아 있어야 한다(오너 확정 UX).
    if (ex) ex.remove();
    document.querySelectorAll(".kgp-card-chk").forEach((b) => b.remove());
    const _nowQ = _kgpPartitionNear(cards);
    _kgpAttachBudgeted(_nowQ, (c) => _kgpEnsureTileQuick(c, null));
    kgpMarkExisting(cards);
    kgpShowReopenPill();
    return;
  }
  // F49-T 4부: 카드가 많으면(규칙 list_watch.lazy_after, 기본 150) **뷰포트 근처만** 지금 붙이고 나머지는
  //   IntersectionObserver로 들어올 때 붙인다(나간 카드는 상태만 — 선택·데이터는 _kgpCardByUrl에 남는다).
  const _now = _kgpPartitionNear(cards);
  _kgpAttachBudgeted(_now, _kgpAttachCard);   // 12ms 조각으로(메인 스레드 한 태스크 50ms 이하 — 전 사이트)
  kgpMarkExisting(cards);   // v42 E-3: 이미 수집된 카드 '수집됨 ✓' 선표시
  const _pill = document.getElementById(KGP_REOPEN_ID);
  if (_pill) _pill.remove();                     // 펼침 → 구석 배지 제거
  // F49-T 4부(성능): 코치마크는 위치를 읽느라(레이아웃 강제) 첫 스캔을 무겁게 한다 → 다음 태스크로.
  if (!document.getElementById(KGP_TOOLBAR_ID)) {
    if (KGP_WATCH.lazy) {                        // 큰 목록: 툴바 첫 생성(shadow·CSS)도 다음 태스크로
      setTimeout(() => { if (!document.getElementById(KGP_TOOLBAR_ID) && !_kgpClosed) { kgpBuildToolbar(); kgpUpdateToolbar(); kgpMaybeCoach(); } }, 0);
    } else { kgpBuildToolbar(); setTimeout(kgpMaybeCoach, 0); }
  }
  kgpUpdateToolbar();
}

// '전체 수집' 1회성 코치마크(처음 리스팅 바를 만났을 때만). reduced-motion이면 생략.
function kgpMaybeCoach() {
  if (KGP_RM || kgpLSget("kgp_coach_all", "") === "1") return;
  const target = _kgpTbQ('.kgp-tb-btn[data-act="collect-all"]');
  if (!target) return;
  kgpLSset("kgp_coach_all", "1");
  const r = target.getBoundingClientRect();
  const tip = document.createElement("div");
  tip.style.cssText = "position:fixed;z-index:2147483647;max-width:248px;padding:11px 14px;border-radius:12px;background:#119a8e;color:#fff;font:600 12.5px/1.45 -apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;box-shadow:0 10px 28px rgba(0,0,0,.45)";
  tip.style.top = (r.bottom + 12) + "px";
  tip.style.left = Math.max(8, Math.min(window.innerWidth - 256, r.left - 90)) + "px";
  tip.innerHTML = '<b>전체 수집</b>으로 이 페이지의 상품을 한 번에 담을 수 있어요.' +
    '<div style="margin-top:8px;text-align:right"><span id="kgp-coach-x" style="cursor:pointer;text-decoration:underline;opacity:.92">알겠어요</span></div>';
  document.body.appendChild(tip);
  const close = () => { try { tip.remove(); } catch (e) { /* noop */ } };
  tip.querySelector("#kgp-coach-x").addEventListener("click", close);
  setTimeout(close, 7000);
}

// 비-소싱처(또는 설정으로 꺼진 사이트)에선 모든 UI 제거(경량, DOM 손 안 댐).
function kgpTeardown() {
  try {
    const fab = document.getElementById(KGP_BTN_ID); if (fab) fab.remove();
    const bar = document.getElementById(KGP_TOOLBAR_ID); if (bar) bar.remove();
    const pill = document.getElementById(KGP_REOPEN_ID); if (pill) pill.remove();
    document.querySelectorAll(".kgp-card-chk, .kgp-card-quick").forEach((b) => b.remove());
    document.querySelectorAll('[data-kgp-outline="1"]').forEach((e) => { e.style.outline = ""; e.removeAttribute("data-kgp-outline"); });
  } catch (e) { /* noop */ }
}

// 상세 페이지로 보이는 URL 패턴(아마존 /dp//gp/product, 타오바오 item.htm, 1688 offer/detail, Temu g-, 일반 /product//goods/).
function kgpIsDetailUrl() {
  return /(\/dp\/|\/gp\/product\/|item\.htm|offer\/detail|\/g-?\d|\/goods\/|\/product\/)/i.test(location.href);
}

// FAB(우측)만 제거 / 리스팅(중앙 바·배지·구석배지)만 제거 — 모드 전환 시 상호배타.
function kgpRemoveFab() {
  const fab = document.getElementById(KGP_BTN_ID);
  if (fab) fab.remove();
}
function kgpRemoveListing() {
  const bar = document.getElementById(KGP_TOOLBAR_ID); if (bar) bar.remove();
  const pill = document.getElementById(KGP_REOPEN_ID); if (pill) pill.remove();
  document.querySelectorAll(".kgp-card-chk, .kgp-card-quick").forEach((b) => b.remove());
  document.querySelectorAll('[data-kgp-outline="1"]').forEach((e) => { e.style.outline = ""; e.removeAttribute("data-kgp-outline"); });
}

// v53 STEP1: 페이지 타입 점수제 감지기 — 단일 상품 vs 목록.
//   증상: 단일 상품 페이지에 중앙(벌크) 버튼이 떠 수집·선택 불가(옛 판정=카드 3개+면 무조건 목록).
//   URL 어댑터 매치 최우선, DOM 휴리스틱 보조. 동점/무신호=불능→우측 단건(안전 기본값).
const KGP_DETAIL_URL_RE = /(\/dp\/|\/gp\/product\/|\/vp\/products\/|item\.htm|aliexpress\.[^/]+\/item\/|[?&]goods_id=|[/-]g-\d{3,}|\/goods\/\d|\/product\/\d|\/products\/[\w-]+|\/itm\/)/i;
const KGP_LIST_URL_RE = /(\/s\?|\/s\/|\/search|\/sch\b|[?&](q|keyword|query|search|k)=|\/category|\/categories|\/c\/|\/list\b|\/best\b|\/ranking|\/plp|\/browse|\/deals)/i;

// v60 STEP5: 디폴트 소싱처(어댑터 등록 사이트) — 여기선 판정불능('unknown') 금지, URL로 결정적 판정.
// v70 STEP4: 정규식 fast-path — 레지스트리(KGP_DEFAULT_SOURCES) 전 도메인 포함(과거 누락분 yoshida·iherb·dhgate·qoo10 보강).
const KGP_DEFAULT_SRC_RE = /(^|\.)(amazon\.[a-z.]+|temu\.com|aliexpress\.[a-z.]+|taobao\.com|tmall\.com|1688\.com|(shopping\.)?yahoo\.co\.jp|paypaymall\.yahoo\.co\.jp|mercari\.com|rakuten\.(co\.jp|com)|yoshidakaban\.com|iherb\.com|dhgate\.com|qoo10\.[a-z.]+)$/i;
// v70 STEP4: 디폴트 소싱처 판정 = 레지스트리 단일 소스. 과거 정규식 단독이라 요시다/아이허브/DHgate/큐텐이
//   결정적 페이지 판정(상세=single·목록=list)에서 누락 → 해당 사이트 수집 버튼 회귀. 레지스트리 순회로 봉인.
function kgpIsDefaultSourcing() {
  try {
    const host = (location.hostname || "").toLowerCase();
    if (KGP_DEFAULT_SRC_RE.test(host)) return true;
    for (let i = 0; i < KGP_DEFAULT_SOURCES.length; i++) { if (KGP_DEFAULT_SOURCES[i].test(host)) return true; }   // 레지스트리 백스톱(드리프트 0)
  } catch (e) { return false; }
  return false;
}

function kgpDetectPageType() {
  // 수동 오버라이드 최우선(감지 실패 대비 탈출구) — 경로 단위 기억.
  try {
    const ov = sessionStorage.getItem("kgp_pt_ov:" + location.pathname);
    if (ov === "single" || ov === "list") return ov;
  } catch (e) {}
  // v86-V [크리티컬]: 라쿠텐 상품 상세는 **호스트 게이트가 제네릭 타일 수보다 우선**한다.
  //   item.rakuten.co.jp/{샵}/{코드}/ 는 상세 전용 서브도메인인데, 상세 페이지에 추천·사이드바 타일이
  //   수십 개(오너 실기기: 스캔 105·상품 68·제네릭 91) 깔려 KGPDetect가 cardCount로 'list' 오판정 →
  //   단품 수집 거부 + v86-H 억제(pageType==='list'에서만 발동)로 필드 전무였다. 상세 서브도메인+상품
  //   경로(_kgpIsRakutenItemHref: 세그먼트 2개↑)면 single로 못박아 (a)FAB/팝업 단품 게이트 활성 (b)v86-H
  //   억제 미발동. 목록=search.rakuten.co.jp은 이 판정 false라 불영향(벌크 34타일 계약 유지 — 상세 분기만).
  try { if (typeof _kgpIsRakutenItemHref === "function" && _kgpIsRakutenItemHref(location.href)) return "single"; } catch (e) {}
  // v73 STEP2: 페이지 타입 판정은 순수 모듈(KGPDetect)에 위임 — 단일 소스(하네스로 계약 검증). 미로드 시 인라인 폴백.
  if (typeof KGPDetect !== "undefined" && KGPDetect.pageType) {
    let _n = 0; try { _n = kgpFindCards().length; } catch (e) { _n = 0; }
    return KGPDetect.pageType(document, location.href, { cardCount: _n });
  }
  const href = location.href;
  const isDetail = KGP_DETAIL_URL_RE.test(href);
  const isList = KGP_LIST_URL_RE.test(href);
  // v71 STEP5: 디폴트 소싱처도 URL이 명확할 때만 URL로 판정하고, **애매하면 DOM 신호로 낙하**한다.
  //   (v60의 'isDetail?single:list' 기본값이 라쿠텐·야후재팬 상세 URL(상세 RE 불일치)을 'list'로 오판 →
  //    상세 버튼 미표시. 상세 상품이면 DOM(단일 h1·갤러리·JSON-LD Product)으로 single 판정 → FAB 노출.)
  // v55 STEP5: URL 규칙 하드매치 최우선(결정적). DOM 휴리스틱은 URL 애매할 때만(점멸 제거·판정 캐시).
  if (isDetail && !isList) return "single";
  if (isList && !isDetail) return "list";
  // URL 애매 → DOM 신호 1회 점수화(이후 kgpPageType 캐시로 세션 내 불변).
  let single = isDetail ? 3 : 0, list = isList ? 3 : 0;
  try { const h1 = document.querySelectorAll("h1"); if (h1.length === 1 && (h1[0].textContent || "").trim().length > 6) single += 1; } catch (e) {}
  try { if (document.querySelector('[class*="gallery" i],[class*="swiper" i],[class*="carousel" i],[aria-roledescription="carousel"]')) single += 1; } catch (e) {}
  try {
    document.querySelectorAll('script[type="application/ld+json"]').forEach((s) => {
      const t = s.textContent || "";
      if (/"@type"\s*:\s*"Product"/i.test(t)) single += 2;
      if (/"@type"\s*:\s*"ItemList"/i.test(t)) list += 2;
    });
  } catch (e) {}
  try { const n = kgpFindCards().length; if (n >= 6) list += 3; else if (n >= 3) list += 1; } catch (e) {}

  if (single === 0 && list === 0) return "unknown";
  if (list > single) return "list";
  if (single > list) return "single";
  return "unknown";                                   // 동점 → 불능(안전 기본값으로)
}

// v55 STEP5: URL별 판정 캐시(세션 내 불변 = 히스테리시스) — 같은 URL은 재판정 안 함(왔다갔다 금지).
//   오버라이드는 캐시 무시(즉시 반영). 'unknown'은 캐시 안 함(DOM 준비 후 재판정 여지).
const KGP_PT_CACHE = {};
function kgpPageType() {
  try {
    const ov = sessionStorage.getItem("kgp_pt_ov:" + location.pathname);
    if (ov === "single" || ov === "list") return ov;
  } catch (e) {}
  const key = location.pathname + location.search;
  if (KGP_PT_CACHE[key]) return KGP_PT_CACHE[key];
  const pt = kgpDetectPageType();
  if (pt !== "unknown") KGP_PT_CACHE[key] = pt;       // 결정된 판정만 고정(번복 금지)
  return pt;
}

// 수동 오버라이드: 버튼 롱프레스(≥600ms) → 이 페이지를 단일↔목록 강제 토글(감지 실패 대비).
function kgpAttachOverride(el) {
  if (!el || el._kgpOv) return; el._kgpOv = 1;
  let timer = null;
  const start = () => { timer = setTimeout(() => {
    let cur = "";
    try { cur = sessionStorage.getItem("kgp_pt_ov:" + location.pathname) || kgpDetectPageType(); } catch (e) { cur = "single"; }
    const next = cur === "list" ? "single" : "list";
    try { sessionStorage.setItem("kgp_pt_ov:" + location.pathname, next); } catch (e) {}
    try { kgpToast("이 페이지를 '" + (next === "list" ? "목록(벌크)" : "단일 상품") + "'으로 강제했어요", true); } catch (e) {}
    kgpRefresh();
  }, 600); };
  const cancel = () => { if (timer) { clearTimeout(timer); timer = null; } };
  el.addEventListener("mousedown", start); el.addEventListener("touchstart", start, { passive: true });
  ["mouseup", "mouseleave", "touchend", "touchcancel"].forEach((ev) => el.addEventListener(ev, cancel));
  el.addEventListener("contextmenu", (e) => { e.preventDefault(); cancel();
    let cur = ""; try { cur = sessionStorage.getItem("kgp_pt_ov:" + location.pathname) || kgpDetectPageType(); } catch (x) {}
    const next = cur === "list" ? "single" : "list";
    try { sessionStorage.setItem("kgp_pt_ov:" + location.pathname, next); } catch (x) {}
    try { kgpToast("이 페이지를 '" + (next === "list" ? "목록(벌크)" : "단일 상품") + "'으로 강제했어요", true); } catch (x) {}
    kgpRefresh();
  });
}

// SPA 대응 + v53 STEP1: 페이지 타입 감지로 버튼 자동 전환(목록=중앙 바만, 단일/불능=우측 FAB만 — 동시 노출 0).
function kgpRefresh() {
  if (!kgpHostAllowed() && !kgpEntrySession()) { kgpTeardown(); return; }   // 지정 소싱처 또는 앱 진입(v10/v17)
  // v86 STEP3: 시트 주입을 **경로 무관**으로. 종전엔 injectCollectButton(FAB)/kgpCelebrate/재오픈알약에서만 불러서,
  //   generic 목록(알리·요시다·라쿠텐검색)은 바만 뜨고 시트가 영영 안 붙었다(오너 진단 style_injected=false).
  //   여기는 list/detail 두 경로가 모두 지나가는 단일 지점이고, kgpEnsureStyles는 id 가드로 문서당 1회 멱등이다.
  //   ※ 시트는 keyframes(펄스·도장) 폴백일 뿐 — 가시성의 전제가 아니다(가시 UI는 shadow가 자립 렌더).
  kgpEnsureStyles();
  _kgpSweepStaleTiles();
  // v55 STEP5: URL별 캐시 판정 사용(재판정 안 함). inject*/remove*는 멱등(이미 마운트면 no-op) → 점멸 0.
  const pt = kgpPageType();
  if (pt === "list") {
    if (document.getElementById(KGP_BTN_ID)) kgpRemoveFab();   // 상호배타(있을 때만 제거)
    kgpInjectListing();                               // 중앙 바만(1.5배, 멱등)
    try { kgpAttachOverride(document.getElementById(KGP_TOOLBAR_ID)); } catch (e) {}
  } else {
    if (document.getElementById(KGP_TOOLBAR_ID) || document.getElementById(KGP_REOPEN_ID)) kgpRemoveListing();
    injectCollectButton();                            // 우측 단건 FAB만(멱등, 안전 기본값)
    try { kgpAttachOverride(document.getElementById(KGP_BTN_ID)); } catch (e) {}
  }
}

// 설정 로드 후 첫 렌더. 설정 바뀌면(소싱처 추가/삭제·토글·FAB on/off) 즉시 반영.
// v54 STEP2: 자가진단 모드 — ON이면 MAIN world(kgp-net 채점)에 진단 표를 콘솔 출력하도록 주기 요청.
let KGP_DIAG = false;
let _kgpDiagTimer = null;
function kgpDiagPing() { try { window.postMessage({ __kgpDiagReq: 1 }, "*"); } catch (e) {} }
function kgpDiagApply() {
  if (_kgpDiagTimer) { clearInterval(_kgpDiagTimer); _kgpDiagTimer = null; }
  if (KGP_DIAG) { setTimeout(kgpDiagPing, 1500); _kgpDiagTimer = setInterval(kgpDiagPing, 4000); }   // 응답이 들어오는 대로 표 갱신
}
function kgpLoadSourcesThen(cb) {
  try {
    chrome.storage.local.get(["kgp_sources", "kgp_fab_enabled", "kgp_diag", "kgp_hover_anchor", "kgp_translate"], (r) => {
      KGP_SOURCES = (r && r.kgp_sources) || {};
      KGP_FAB_ENABLED = !(r && r.kgp_fab_enabled === false);   // 기본 ON
      KGP_TRANSLATE = !(r && r.kgp_translate === false);       // v83.1 STEP1: 한국어 번역 기본 ON
      KGP_DIAG = !!(r && r.kgp_diag);                          // 진단 모드 기본 OFF
      KGP_HOVER_ANCHOR = (r && r.kgp_hover_anchor) || "center";  // v64 STEP3: 수집 버튼 위치
      kgpDiagApply();
      cb && cb();
    });
  } catch (e) { KGP_SOURCES = {}; cb && cb(); }
}
try {
  chrome.storage.onChanged.addListener((changes, area) => {
    let changed = false;
    if (changes && changes.kgp_sources) { KGP_SOURCES = changes.kgp_sources.newValue || {}; changed = true; }
    if (changes && changes.kgp_fab_enabled) {
      KGP_FAB_ENABLED = changes.kgp_fab_enabled.newValue !== false;
      if (!KGP_FAB_ENABLED) kgpRemoveFab();             // 끄면 즉시 제거
      changed = true;
    }
    if (changes && changes.kgp_translate) {          // v83.1 STEP1: 팝업↔카드 양방향 즉시 동기(문구 포함)
      KGP_TRANSLATE = changes.kgp_translate.newValue !== false;
      kgpApplyTranslateCopy();
      kgpRenderCardTranslate();
    }
    if (changes && changes.kgp_diag) { KGP_DIAG = !!changes.kgp_diag.newValue; kgpDiagApply(); }
    if (changes && changes.kgp_hover_anchor) {          // v64 STEP3: 위치 변경 즉시 반영
      KGP_HOVER_ANCHOR = changes.kgp_hover_anchor.newValue || "center";
      document.querySelectorAll(".kgp-card-quick").forEach((q) => {
        // v86 STEP4: cssText 재적용은 opacity를 기본값(0)으로 되돌린다 → 호버 중이면 노출 상태를 즉시 복원.
        var _wasOn = q.style.opacity === "1";   // 호버 중이었는지(=1)만 복원 대상
        q.style.cssText = kgpQuickBtnStyle(q.dataset.collected === "1", q.dataset.anchorMode || "");
        if (_wasOn && typeof q._kgpReveal === "function") q._kgpReveal(true);
      });
    }
    if (changed) kgpRefresh();                          // 런타임 즉시 반영
  });
} catch (e) { /* noop */ }

// v72b STEP4: 설치된 확장 버전을 페이지 DOM(documentElement[data-kgp-ext])에 각인 — 우리 셀러 콘솔이
//   이 값을 읽어 신선도 배너(최신/구버전 재로딩)를 판정한다. 호스트 게이팅과 무관하게 모든 페이지 무조건.
(function _kgpStampExtVersion() {
  try {
    const v = (chrome.runtime.getManifest && chrome.runtime.getManifest().version) || "";
    if (v && document.documentElement) document.documentElement.setAttribute("data-kgp-ext", v);
  } catch (e) { /* noop */ }
})();

kgpLoadSourcesThen(kgpRefresh);
let _kgpLastUrl = location.href;
setInterval(() => {
  if (location.href !== _kgpLastUrl) {
    _kgpLastUrl = location.href;
    // 새 페이지로 이동 → 닫음 상태/선택 초기화(다른 상품 목록이므로).
    _kgpClosed = false;
    _kgpAutoApplied = false;
    KGP_SELECTED.clear();
    _kgpSelKeys.clear();
    _kgpInitialKeys = null;
    KGP_WATCH.new_cards = 0;
    _kgpCardByUrl = {};
    const _pill = document.getElementById(KGP_REOPEN_ID);
    if (_pill) _pill.remove();
    setTimeout(kgpRefresh, 900);
  }
}, 1500);
// v55 STEP5: 주기적 always-refresh(4초) 제거 — 점멸의 원인(지속 재판정). 재판정은 URL 변경 시로 한정.

// v55 STEP5: 재주입 전용 옵저버 — 우리 오버레이가 사이트 재렌더로 사라졌을 때만 **캐시된 판정 그대로** 재마운트.
//   DOM 변이 기반 '재판정'은 제거(kgpRefresh는 kgpPageType 캐시 사용 → 판정 번복 0). URL 변경은 history 훅으로.
(function () {
  let _t = null;
  function _remountIfGone() {
    if (_t) return;
    _t = setTimeout(() => {
      _t = null;
      try {
        if (!(kgpHostAllowed() || kgpEntrySession())) return;
        const gone = !document.getElementById(KGP_BTN_ID) && !document.getElementById(KGP_TOOLBAR_ID) && !document.getElementById(KGP_REOPEN_ID);
        if (gone) kgpRefresh();          // 사라졌을 때만 재마운트(캐시 판정 사용, 재판정 아님)
      } catch (e) {}
    }, 400);
  }
  function _onUrlChange() {
    // URL 변경 = 새 페이지 → 판정 재평가(새 URL은 캐시 없음). 상태 초기화는 아래 URL 폴링과 공유.
    if (_t) { clearTimeout(_t); _t = null; }
    try { if (kgpHostAllowed() || kgpEntrySession()) setTimeout(kgpRefresh, 300); } catch (e) {}
  }
  try {
    const obs = new MutationObserver(() => { _remountIfGone(); });   // 오버레이 소실 감지 전용(재판정 아님)
    const _start = () => { if (document.body) obs.observe(document.body, { childList: true, subtree: true }); else setTimeout(_start, 300); };
    _start();
  } catch (e) { /* MutationObserver 미지원 환경 무시 */ }
  // SPA: history API 후킹(pushState/replaceState/popstate) → URL 변경 시에만 재판정.
  try {
    ["pushState", "replaceState"].forEach((fn) => {
      const orig = history[fn];
      if (typeof orig === "function") {
        history[fn] = function () { const r = orig.apply(this, arguments); _onUrlChange(); return r; };
      }
    });
    window.addEventListener("popstate", _onUrlChange, { passive: true });
  } catch (e) { /* noop */ }
})();

// v71 STEP4: 무한스크롤 신규 타일 배지 부착 — 목록 모드에서 신규 타일 유입(MutationObserver) + 스크롤
//   (가상화 리스트: childList 무변이로 노드 재사용)에 디바운스 300ms 재부착. kgpInjectListing은 멱등(배지 있는
//   카드 스킵 + 가상화 재사용 노드 url 갱신). kgpPageType 캐시 사용 = 재판정 아님(v55 점멸 방지 원칙 유지).
(function () {
  let _rt = null;
  // F49-T 4부: **진짜 디바운스**(마지막 변이 뒤 300ms — 규칙 list_watch.debounce_ms). 예전엔 첫 변이 뒤 300ms에
  //   한 번 돌고 끝나(스로틀) 그 뒤에 붙은 카드는 다음 변이가 올 때까지 기다렸다.
  function kgpRescanTiles() {
    if (_rt) clearTimeout(_rt);
    _rt = setTimeout(() => {
      _rt = null;
      try {
        if (!(kgpHostAllowed() || kgpEntrySession())) return;
        if (kgpPageType() !== "list") return;          // 목록 모드만(캐시 판정 — 번복 0)
        // v86-C: 바를 닫아도 **호버 수집버튼은 계속 붙어야** 한다 → 바 상태 게이트 제거.
        //   kgpInjectListing이 닫힘 상태를 알아서 처리한다(chk만 걷고 quick은 주입).
        if (window.top !== window.self) return;
        kgpInjectListing();                              // 멱등 재부착
      } catch (e) {}
    }, Number(_kgpRule("list_watch.debounce_ms", 300)) || 300);
  }
  _kgpRescanHook = kgpRescanTiles;
  try {
    const mo = new MutationObserver(kgpRescanTiles);
    const start = () => { if (document.body) { mo.observe(document.body, { childList: true, subtree: true }); _kgpBodyObserved = true; } else setTimeout(start, 300); };
    start();
    window.addEventListener("scroll", kgpRescanTiles, { passive: true });   // 가상화(childList 무변이) 대응
    window.addEventListener("resize", kgpRescanTiles, { passive: true });
  } catch (e) { /* IntersectionObserver/MutationObserver 미지원 무시 */ }
})();

// v74 STEP3: 알리 버튼 생존(대형 셀러툴 패리티) — 호버 오버레이가 카드 서브트리를 교체해 우리 배지/호버 버튼이
//   '증발'하면 즉시(100ms) 재부착. 신규-타일 재스캔(300ms)과 별개: **우리 오버레이 소실만** 빠르게 감지 → 재주입.
//   (앵커 안정 조상 방안도 검토했으나, v65 이미지-앵커 위치를 보존하면서 알리 SPA 재렌더까지 커버하려면
//    소실 즉시 재부착이 가장 견고 — 위치 회귀 0 + 증발 지속시간 최소화.)
(function () {
  let _reat = null;
  function kgpReattachOverlays() {
    if (_reat) return;
    _reat = setTimeout(() => {
      _reat = null;
      try {
        if (!(kgpHostAllowed() || kgpEntrySession())) return;
        if (_kgpClosed || window.top !== window.self) return;
        if (kgpPageType() !== "list") return;   // 목록 모드만(캐시 판정 — 번복 0)
        kgpInjectListing();                       // 멱등: 사라진 배지/호버 버튼만 다시 생성
      } catch (e) {}
    }, 100);   // 100ms 디바운스(호버 재렌더 폭주 완화 + 즉시성)
  }
  function _isOurOverlay(n) {
    if (!n || n.nodeType !== 1) return false;
    try {
      if (n.classList && (n.classList.contains("kgp-card-quick") || n.classList.contains("kgp-card-chk"))) return true;
      return !!(n.querySelector && n.querySelector(".kgp-card-quick, .kgp-card-chk"));
    } catch (e) { return false; }
  }
  function _onMut(muts) {
    for (let i = 0; i < muts.length; i++) {
      const rm = muts[i].removedNodes || [];
      for (let j = 0; j < rm.length; j++) {
        if (_isOurOverlay(rm[j])) { kgpReattachOverlays(); return; }   // 우리 오버레이가 제거됨 → 즉시 재부착
      }
    }
  }
  try {
    const mo = new MutationObserver(_onMut);
    const start = () => { if (document.body) mo.observe(document.body, { childList: true, subtree: true }); else setTimeout(start, 300); };
    start();
  } catch (e) { /* MutationObserver 미지원 무시 */ }
})();
